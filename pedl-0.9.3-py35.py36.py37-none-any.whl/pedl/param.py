from abc import ABCMeta, abstractmethod
from collections import OrderedDict
from typing import Any, Dict, List, Mapping

import numpy as np

from pedl.check import check_lt_eq


class Param(metaclass=ABCMeta):
    """Abstract class for a trial parameter."""

    def __eq__(self, other: object) -> bool:
        if type(self) is not type(other):
            return False

        return self.__dict__ == other.__dict__

    @abstractmethod
    def range(self, num_items: int, random_state: np.random.RandomState = None) -> List[Any]:
        """
        Returns `num_items` samples (with replacement) from the trial parameter
        space. `random_state` is used as the source of randomness if specified,
        `np.random` is used otherwise.
        """
        pass

    @abstractmethod
    def sample(self, random_state: np.random.RandomState = None) -> Any:
        """Returns a single sample from the trial parameter space.
        `random_state` is used as the source of randomness if specified,
        `np.random` is used otherwise."""
        pass


class Int(Param):
    """Uniformly distributed integers in an interval."""

    def __init__(self, minval: int, maxval: int) -> None:
        """
        Args:
            minval: Minimum integer, inclusive.
            maxval: Maximum integer, inclusive.
        """
        check_lt_eq(minval, maxval)

        self.minval = minval
        self.maxval = maxval

    def range(self, num_items: int, random_state: np.random.RandomState = None) -> List[int]:
        """See `Param.range`."""
        if random_state is None:
            return [int(i) for i in np.random.randint(self.minval, self.maxval, num_items)]
        else:
            return [int(i) for i in random_state.randint(self.minval, self.maxval, num_items)]

    def sample(self, random_state: np.random.RandomState = None) -> Any:
        """See `Param.sample`."""
        if random_state is None:
            return int(np.random.randint(self.minval, self.maxval + 1))
        else:
            return int(random_state.randint(self.minval, self.maxval + 1))


class Double(Param):
    """Uniformly distributed double precision floats in an interval."""

    def __init__(self, minval: float, maxval: float) -> None:
        """
        Args:
            minval: Minimum float, inclusive.
            maxval: Maximum float, inclusive.
        """
        check_lt_eq(minval, maxval)

        self.minval = minval
        self.maxval = maxval

    def range(self, num_items: int, random_state: np.random.RandomState = None) -> List[np.float64]:
        """See :func:`Param.range`."""
        if random_state is None:
            return list(np.random.uniform(self.minval, self.maxval, num_items))
        else:
            return list(random_state.uniform(self.minval, self.maxval, num_items))

    def sample(self, random_state: np.random.RandomState = None) -> np.float64:
        """See :func:`Param.sample`."""
        if random_state is None:
            return np.random.uniform(self.minval, self.maxval)
        else:
            return random_state.uniform(self.minval, self.maxval)


class Logarithmic(Param):
    """Log-uniformly distributed double precision floats in an interval."""

    def __init__(self, minval: float, maxval: float, base: float) -> None:
        """
        Args:
            minval: Minimum value is `base ^ minval`, inclusive.
            maxval: Maximum value is `base ^ maxval`, inclusive.
            base: Base of exponent.
        """
        self.minval = minval
        self.maxval = maxval
        self.base = float(base)

    def range(self, num_items: int, random_state: np.random.RandomState = None) -> List[int]:
        """See :func:`Param.range`."""
        if random_state is None:
            return list(np.power(self.base, np.random.uniform(self.minval, self.maxval, num_items)))
        else:
            return list(
                np.power(self.base, random_state.uniform(self.minval, self.maxval, num_items))
            )

    def sample(self, random_state: np.random.RandomState = None) -> np.float64:
        """See :func:`Param.sample`."""
        if random_state is None:
            return np.power(self.base, np.random.uniform(self.minval, self.maxval))
        else:
            return np.power(self.base, random_state.uniform(self.minval, self.maxval))


class Categorical(Param):
    def __init__(self, vals: List[Any]) -> None:
        """
        Args:
            vals: Collection of values (levels) of the category.
        """
        if isinstance(vals, str) or len(vals) == 0:
            raise ValueError(
                "'categorical' parameter must be a "
                "collection of 2 or more values: {}".format(vals)
            )
        self.items = vals

    def range(self, num_items: int, random_state: np.random.RandomState = None) -> List[int]:
        """See :func:`Param.range`.

        NB: If `num_items` is larger than `len(self.items)`, we over-sample.
        """
        return [self.sample(random_state) for _ in range(num_items)]

    def sample(self, random_state: np.random.RandomState = None) -> Any:
        """See :func:`Param.sample`."""
        if random_state is None:
            result = np.random.choice(self.items)
        else:
            result = random_state.choice(self.items)

        if isinstance(result, np.generic):
            return result.item()
        else:
            return result


class Constant(Param):
    def __init__(self, val: Any) -> None:
        """
        Args:
            val: The constant value this :class:`Param` takes.
        """
        self.val = val

    def range(self, num_items: int, random_state: np.random.RandomState = None) -> List[Any]:
        """See :func:`Param.range`."""
        return [self.val] * num_items

    def sample(self, random_state: np.random.RandomState = None) -> Any:
        """See :func:`Param.sample`."""
        return self.val


def make_param_from_dict(d: Dict[str, Any]) -> Param:
    """Construct a :class:`Param` from a deserialized JSON object.

    Args:
        d: Python dictionary of the form::

            {"type": t, "arg1": v1, "arg2": v2}

    Returns:
       A :class:`Param` object of the appropriate type.
    """
    try:
        param_type = d["type"]
    except KeyError:
        raise ValueError("Missing 'type': {}".format(d))

    try:
        if param_type == "double":
            return Double(d["minval"], d["maxval"])
        elif param_type == "log":
            return Logarithmic(d["minval"], d["maxval"], d["base"])
        elif param_type == "int":
            return Int(d["minval"], d["maxval"])
        elif param_type == "categorical":
            return Categorical(d["vals"])
        elif param_type == "const":
            return Constant(d["val"])
        else:
            raise ValueError("Unrecognized type: '{}'".format(param_type))
    except KeyError as e:
        raise ValueError("Missing config parameter '{}'".format(e.args[0]))


def make_param(d: Any) -> Param:
    """Construct a :class:`Param` from a deserialized JSON object or value.

    Args:
        d: A deserialized JSON value or object. If this argument is a JSON
           value, it is assumed to be a :class:`Constant` param.

    Returns:
       A :class:`Param` object of the appropriate type.
    """

    if isinstance(d, dict):
        return make_param_from_dict(d)
    else:
        return Constant(d)


def make_trial_space(hp_config: Dict[str, Any]) -> Mapping[str, Any]:
    result = OrderedDict()  # type: OrderedDict[str, Any]

    for k in sorted(hp_config.keys()):
        try:
            result[k] = make_param(hp_config[k])
        except ValueError as e:
            raise ValueError("Invalid hyperparameter '{}': {}".format(k, e))

    return result
