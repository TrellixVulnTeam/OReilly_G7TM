from abc import ABCMeta, abstractmethod
from typing import Any, Dict, Iterator, Sized, Union

import numpy as np

from pedl.check import check_eq_len, check_gt, check_gt_eq, check_len, check_lt, check_type

# Allow Batch to contain torch.Tensors in original_data if PyTorch is
# available.
try:
    import torch

    Array = Union[np.ndarray, torch.Tensor]
    has_torch = True

    def is_array(val: Any) -> bool:
        return isinstance(val, (np.ndarray, torch.Tensor))


except ImportError:
    Array = np.ndarray
    has_torch = False

    def is_array(val: Any) -> bool:
        return isinstance(val, np.ndarray)


class Batch(Sized):
    """
    A batch of data, represented as a pair of aligned `data` and `labels`
    arrays.
    """

    def _dict_init(self, data: Dict[str, np.ndarray], labels: Dict[str, np.ndarray]) -> None:
        check_type(data, dict)
        check_type(labels, dict)
        check_gt(len(data), 0)
        check_gt(len(labels), 0)

        # Use random data field to get the length. It doesn't matter which one
        # we choose because the lengths of every data and labels field should
        # be equivalent.
        self.length = len(next(iter(data.values())))

        for name, datum in data.items():
            check_type(name, str)
            check_type(datum, np.ndarray)
            check_len(
                datum,
                self.length,
                "All array values in Batch must be of "
                "the same length. Found inconsistent length at "
                "data: {}".format(name),
            )
        for name, label in labels.items():
            check_type(name, str)
            check_type(label, np.ndarray)
            check_len(
                label,
                self.length,
                "All array values in Batch must be of "
                "the same length. Found inconsistent length at "
                "label: {}".format(name),
            )

        self.data = data
        self.labels = labels

    def __init__(self, data: Union[dict, Array], labels: Union[dict, Array]) -> None:
        """
        Args:
            data: Either an array or a dictionary of data names
                  to arrays.
            labels: Either an array or a dictionary of label names
                     to arrays.

        The first dimension of each array is the number of instances in
        the batch. All supplied arrays must have the same number of
        instances: in other words, the sizes of their first dimensions must be
        equivalent.

        The input is saved as a dictionary. If the argument is a single
        array in_arr, it is saved as {"input": in_arr}. Similarly, the
        output is saved as a dictionary. If the argument is a single array
        out_arr, it is saved as {"output": out_arr}.
        """
        if not (
            (isinstance(data, dict) or is_array(data))
            and (isinstance(labels, dict) or is_array(labels))
        ):
            raise ValueError(
                "Invalid initialization function for Batch: "
                "arguments can be either arrays or "
                "dictionaries of string names to arrays"
            )

        # Store a reference to the data exactly as the user passed the data
        # in. This is primarily for PyTorch; the PEDL PyTorch API is structured
        # around callbacks, and it is odd for a user to create a Batch with
        # data of one format but then receive it in a different format.
        # Additionally, wrapping data and labels in a dictionary makes
        # single-input single-output PyTorch models non-intuitive.
        self.original_data = data
        self.original_labels = labels

        if isinstance(data, np.ndarray):
            data = {"input": data}
        elif has_torch and isinstance(data, torch.Tensor):
            data = {"input": data.cpu().detach().numpy()}

        if isinstance(labels, np.ndarray):
            labels = {"output": labels}
        elif has_torch and isinstance(labels, torch.Tensor):
            labels = {"output": labels.cpu().detach().numpy()}
        self._dict_init(data, labels)

    def __len__(self) -> int:
        """
        Returns:
            The number of records in the batch.
        """
        return self.length

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Batch):
            return False
        return self.data == other.data and self.labels == other.labels

    @property
    def plain_data(self) -> np.ndarray:
        check_len(
            self.data,
            1,
            "Expected a Batch with a single data input, but "
            "received a batch with multiple data inputs: "
            "{}".format(self.data.keys()),
        )
        return next(iter(self.data.values()))

    @property
    def plain_labels(self) -> np.ndarray:
        check_len(
            self.labels,
            1,
            "Expected a Batch with a single label output, but "
            "received a batch with multiple label outputs: "
            "{}".format(self.labels.keys()),
        )
        return next(iter(self.labels.values()))


class BatchLoader(Sized, metaclass=ABCMeta):
    """
    Loads batches; abstract base class.

    Concrete subclasses should implement :func:`__len__()` and
    :func:`get_batch()`.
    """

    @abstractmethod
    def __len__(self) -> int:
        """
        Returns:
            The number of records in the dataset.
        """
        pass

    @abstractmethod
    def get_batch(self, start: int, end: int) -> Batch:
        """Loads a batch of data.

        Args:
            start: Zero-indexed start of the batch.
            end: Zero-indexed end of the batch.

        Returns:
            A :class:`Batch`.
        """
        pass

    def get_batch_by_index(
        self, batch_size: int, ith: int, wrap: bool = True, drop_leftovers: bool = True
    ) -> Batch:
        """
        Chops data set into batches, and returns a batch at an index.

        Args:
            batch_size: The size of the batches to produce.
            ith: Which batch to return.
            wrap: If true, compute `ith` modulo the number of
                 batches. Otherwise, fail if `ith` is greater than the
                 number of batches.
            drop_leftovers: If true, omit the last batch if it is less than
                `batch_size`.

        Returns:
            A :class:`Batch`.
        """
        check_gt_eq(ith, 0)

        num_batches = len(self) // batch_size
        if num_batches * batch_size < len(self) and not drop_leftovers:
            num_batches += 1
        check_gt(num_batches, 0)

        if wrap:
            ith = ith % num_batches
        else:
            check_lt(ith, num_batches)

        return self.get_batch(batch_size * ith, min(batch_size * (ith + 1), len(self)))

    def iterbatches(self, batch_size: int, drop_leftovers: bool = True) -> Iterator[Batch]:
        """Iterate over batches.

        Args:
            batch_size: The size of the batches to produce.
            drop_leftovers: If true, omit the last batch if it is less than
                `batch_size`.

        Returns:
            Iterator that yields batches of `batch_size`.
        """
        end = 0
        for start, end in zip(
            range(0, len(self), batch_size), range(batch_size, len(self) + 1, batch_size)
        ):
            yield self.get_batch(start, end)
        if end < len(self) and not drop_leftovers:
            yield self.get_batch(end, len(self))


class ArrayBatchLoader(BatchLoader):
    """
    Convenience class for data loaders backed by in-memory arrays.
    """

    def __init__(self, dataset: np.ndarray, labels: np.ndarray) -> None:
        """
        Args:
            dataset: Feature data set.
            labels: Label data set.  Should be aligned with `dataset`.
        """
        check_eq_len(dataset, labels)
        check_type(dataset, np.ndarray)
        check_type(labels, np.ndarray)
        self.dataset = dataset
        self.labels = labels

    def __len__(self) -> int:
        """
        Returns:
            The number of records in the dataset.
        """
        return len(self.dataset)

    def get_batch(self, start: int, end: int) -> Batch:
        """See `BatchLoader.get_batch()`."""
        check_gt_eq(start, 0)
        check_gt(end, start)
        check_gt_eq(len(self), end)
        return Batch(self.dataset[start:end], self.labels[start:end])


class SliceBatchLoader(BatchLoader):
    """
    Convenience class that only exposes a contiguous slice of an
    underlying :class:`BatchLoader`.

    This can be used to make training/validation splits.
    """

    def __init__(self, loader: BatchLoader, start: int, length: int) -> None:
        """
        Args:
            loader: Underlying data set.
            start: Offset within `loader` to start from.
            length: Total length of the slice to expose.
        """
        check_gt_eq(len(loader), start + length)
        self.loader = loader
        self.start = start
        self.length = length

    def __len__(self) -> int:
        """
        Returns:
            The number of records in the slice.
        """
        return self.length

    def get_batch(self, start: int, end: int) -> Batch:
        """See :func:`BatchLoader.get_batch()`."""
        check_gt_eq(start, 0)
        check_gt(end, start)
        check_gt_eq(len(self), end)
        return self.loader.get_batch(start + self.start, end + self.start)
