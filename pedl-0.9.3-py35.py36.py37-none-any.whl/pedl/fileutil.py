import shutil
import tempfile
from pathlib import Path
from types import TracebackType
from typing import ContextManager, Dict, Optional, Type

import py


class FileTree(ContextManager[py.path.local]):
    """FileTree creates a set of files with their contents in their
    subdirectories and cleans them up later.
    """

    def __init__(self, tmpdir: py.path.local, files: Dict[str, str]) -> None:
        """Creates a file tree in tempdir with the given filenames and
        contents."""
        self.tmpdir = tmpdir
        self.files = files
        self.dir = None  # type: Optional[Path]

    def __enter__(self) -> Path:
        """Creates FileTree and returns the root directory of the FileTree."""
        self.dir = Path(tempfile.mkdtemp(dir=str(self.tmpdir)))
        try:
            for name, contents in self.files.items():
                p = self.dir.joinpath(name)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(contents)
        except OSError:
            shutil.rmtree(str(self.dir), ignore_errors=True)

        return self.dir

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> Optional[bool]:
        shutil.rmtree(str(self.dir), ignore_errors=True)
        return False
