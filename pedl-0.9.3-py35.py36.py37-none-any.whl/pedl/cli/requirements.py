import importlib
from typing import Any, Optional


def do_import(
    module_path: str, subimport: Optional[str] = None, old_path: Optional[str] = None
) -> Any:
    old_path = old_path or module_path
    prefixes = ["pip._internal", "pip"]
    paths = [module_path, old_path]
    search_order = ["{0}.{1}".format(p, pth) for p in prefixes for pth in paths if pth is not None]
    package = subimport if subimport else ""
    for to_import in search_order:
        if not subimport:
            to_import, _, package = to_import.rpartition(".")
        try:
            imported = importlib.import_module(to_import)
        except ImportError:
            continue
        else:
            return getattr(imported, package)


parse_requirements = do_import("req.req_file", "parse_requirements")
