import getpass
import sys

from argparse import Namespace
from typing import Any, Dict, List, Optional

from requests import Response
from termcolor import colored

from . import api
from .authentication import (
    Authentication,
    authentication_optional,
    authentication_required,
    AuthenticationFailedException,
    Credentials,
    salt_and_hash,
)
from .declarative_argparse import Arg, Cmd


def do_login(username: Optional[str] = None, ask_for_password: bool = True) -> None:
    if username is None:
        username = input("Username: ")

    message = "Password for user '{}': ".format(username)

    # In order to not send clear-text passwords, we hash the password.
    password = salt_and_hash(getpass.getpass(message) if ask_for_password else "")

    try:
        Authentication.instance().log_in_user(Credentials(username, password), True)
    except AuthenticationFailedException as e:
        if e.response.status_code == 403:
            message = "Login failed for user '{}': bad credentials".format(username)
        else:
            message = "Login failed for user '{}' with status {}".format(
                username, e.response.status_code
            )
        print(colored(message, "red"))
        sys.exit(1)


def update_user(
    username: str, master_ip: str, active: Optional[bool] = None, password: Optional[str] = None
) -> Response:
    if active is None and password is None:
        raise Exception("Internal error (must supply at least one kwarg to update_user).")

    request = {}  # type: Dict[str, Any]
    if active is not None:
        request["active"] = active

    if password is not None:
        request["password"] = password

    return api.patch(master_ip, "users/{}".format(username), request)


@authentication_required
def activate_user(parsed_args: Namespace) -> None:
    update_user(parsed_args.username, parsed_args.master, active=True)


@authentication_required
def deactivate_user(parsed_args: Namespace) -> None:
    update_user(parsed_args.username, parsed_args.master, active=False)


def log_in_user(parsed_args: Namespace) -> None:
    if parsed_args.username is None:
        username = input("Username: ")
    else:
        username = parsed_args.username
    do_login(username=username, ask_for_password=True)


@authentication_optional
def log_out_user(_: Namespace) -> None:
    Authentication.instance().log_out_session()


@authentication_required
def change_password(parsed_args: Namespace) -> None:
    auth = Authentication.instance()

    if parsed_args.target_user:
        username = parsed_args.target_user
    elif parsed_args.user:
        username = parsed_args.user
    else:
        username = auth.get_session_user()

    if not username:
        # The default user should have been set by now by autologin.
        print(colored("Please log in as an admin or user to change passwords", "red"))
        return

    # If the target user's password isn't being changed by another user, reauthenticate after
    # password change so that the user doesn't have to do so manually.
    reauthenticate = parsed_args.target_user is None

    password = getpass.getpass("New password for user '{}': ".format(username))
    check_password = getpass.getpass("Confirm password: ")

    if password != check_password:
        print(colored("Passwords do not match.", "red"))
        return

    # In order to not send clear-text passwords, we hash the password.
    password = salt_and_hash(password)

    update_user(username, parsed_args.master, password=password)

    if reauthenticate:
        set_active = auth.is_user_active(username)
        auth.log_in_user(Credentials(username, password), set_active)


@authentication_required
def create_user(parsed_args: Namespace) -> None:
    username = parsed_args.username
    admin = bool(parsed_args.admin)

    request = {"username": username, "admin": admin, "active": True}

    api.post(parsed_args.master, "users", request)


@authentication_required
def whoami(parsed_args: Namespace) -> None:
    response = api.get(parsed_args.master, "users/me")

    user = response.json()
    print("You are logged in as user '{}'".format(user["username"]))


# fmt: off

args_description = [
    Cmd("u|ser", None, "manage users", [
        Cmd("login", log_in_user, "Login user", [
            Arg("username", nargs="?", default=None)
        ]),
        Cmd("change-password", change_password, "Change password for user", [
            Arg("target_user", nargs="?", default=None)
        ]),
        Cmd("logout", log_out_user, "Logout user", []),
        Cmd("activate", activate_user, "Activate user", [
            Arg("username")
        ]),
        Cmd("deactivate", deactivate_user, "Deactivate user", [
            Arg("username")
        ]),
        Cmd("create", create_user, "Create and activate user", [
            Arg("username"),
            Arg("--admin", action="store_true", help="Give new user admin rights"),
        ]),
        Cmd("whoami", whoami, "Print the active user", [])
    ])
]  # type: List[Any]

# fmt: on
