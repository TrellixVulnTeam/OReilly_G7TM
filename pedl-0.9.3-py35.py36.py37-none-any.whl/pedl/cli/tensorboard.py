import sys

from argparse import Namespace, ONE_OR_MORE
from collections import namedtuple
from typing import Any, Dict, List

from termcolor import colored

from pedl.check import check_eq

from . import api, render
from .authentication import Authentication, authentication_required
from .command import Command, render_event_stream
from .declarative_argparse import Arg, Cmd

Tensorboard = namedtuple(
    "Tensorboard",
    ["id", "owner", "description", "state", "experiment_id", "trial_ids", "exit_status"],
)


def to_tensorboard(command: Command) -> Tensorboard:
    return Tensorboard(
        command.id,
        command.owner["username"],
        command.config["description"],
        command.state,
        command.misc.get("experiment_id"),
        command.misc.get("trial_ids"),
        command.exit_status,
    )


@authentication_required
def start_tensorboard(args: Namespace) -> None:
    if args.trial_ids is None and args.experiment_id is None:
        print("experiment id or trial_ids must be passed as parameters")
        print("see: pedl tensorboard start -h\nfor usage information")
        sys.exit(1)

    if args.trial_ids is not None:
        resp = api.post(args.master, "tensorboard", body={"trial_ids": args.trial_ids})
    else:
        resp = api.post(args.master, "tensorboard", body={"experiment_id": args.experiment_id})

    body = resp.json()

    if args.detach:
        print(body["id"])
        return

    url = "tensorboard/{}/events".format(body["id"])
    with api.ws(args.master, url) as ws:
        for msg in ws:
            if msg["log_event"] is not None:
                # TensorBoard will print a url by default. The URL is incorrect since
                # TensorBoard is not aware of the master proxy address it is assigned.
                if "http" in msg["log_event"].get("stream", ""):
                    continue

            if msg["service_ready_event"] and not args.no_browser:
                url = api.proxy(args.master, body["id"], "tensorboard-0", "/")
                print(colored("Tensorboard is running at: {}".format(url), "green"))
            render_event_stream(msg)


@authentication_required
def open_tensorboard(args: Namespace) -> None:
    tensorboard = render.unmarshal(
        Command, api.get(args.master, "tensorboard/{}".format(args.tensorboard_id)).json()
    )
    check_eq(tensorboard.state, "RUNNING", "Tensorboard must be in a running state")
    api.proxy(args.master, args.tensorboard_id, "tensorboard-0", "/")


@authentication_required
def tail_tensorboard_logs(args: Namespace) -> None:
    url = "tensorboard/{}/events?follow={}&tail={}".format(
        args.tensorboard_id, args.follow, args.tail
    )
    with api.ws(args.master, url) as ws:
        for msg in ws:
            render_event_stream(msg)


@authentication_required
def list_tensorboards(args: Namespace) -> None:
    if args.all:
        params = {}  # type: Dict[str, Any]
    else:
        params = {"user": Authentication.instance().get_session_user()}

    commands = [
        render.unmarshal(Command, command)
        for command in api.get(args.master, path="tensorboard", params=params).json().values()
    ]

    if args.quiet:
        for command in commands:
            print(command.id)
        return

    render.render_objects(Tensorboard, [to_tensorboard(command) for command in commands])


@authentication_required
def kill_tensorboard(args: Namespace) -> None:
    for i, tid in enumerate(args.tensorboard_id):
        try:
            api.delete(args.master, "tensorboard/{}".format(tid))
            print(colored("Killed tensorboard {}".format(tid), "green"))
        except api.APIException as e:
            if not args.force:
                for ignored in args.tensorboard_id[i + 1 :]:
                    print("Cowardly not killing {}".format(ignored))
                raise e
            print(colored("Skipping: {} ({})".format(e, type(e).__name__), "red"))


# fmt: off

args_description = [
    Cmd("tensorboard", None, "manage TensorBoard instances", [
        Cmd("list", list_tensorboards, "list TensorBoard instances", [
            Arg("-q", "--quiet", action="store_true",
                help="Only display the ids"),
            Arg("--all", "-a", action="store_true",
                help="Show all TensorBoards (including other users')")
        ], is_default=True),
        Cmd("start", start_tensorboard, "start a new TensorBoard instance", [
            Arg("experiment_id", type=int, nargs="?",
                help="Load the trials for the specified experiment. Up to 100 trials "
                     "from the specified experiment will be loaded in TensorBoard. If "
                     "more than 100 trials are in the experiment, the "
                     "100 best-performing trials will be used."),
            Arg("-t", "--trial-ids", nargs="+", type=int,
                help="list of trial ids to load into TensorBoard - "
                "experiment id will be ignored. A maximum of 100 trials are "
                "allowed per tensorboard instance."),
            Arg("--no-browser", action="store_true",
                help="don't open TensorBoard in a browser after startup"),
            Arg("-d", "--detach", action="store_true",
                help="run in the background and print the id")
        ]),
        Cmd("open", open_tensorboard,
            "open an existing TensorBoard instance", [
                Arg("tensorboard_id", help="TensorBoard ID")
            ]),
        Cmd("logs", tail_tensorboard_logs, "fetch TensorBoard instance logs", [
            Arg("tensorboard_id", help="TensorBoard ID"),
            Arg("-f", "--follow", action="store_true",
                help="follow the logs of a TensorBoard instance, "
                     "similar to tail -f"),
            Arg("--tail", type=int, default=10,
                help="number of lines to show, counting from the end "
                     "of the log")
        ]),
        Cmd("kill", kill_tensorboard, "kill a TensorBoard instance", [
            Arg("tensorboard_id", help="TensorBoard ID", nargs=ONE_OR_MORE),
            Arg("-f", "--force", action="store_true", help="ignore errors"),
        ]),
    ])
]  # type: List[Any]

# fmt: on
