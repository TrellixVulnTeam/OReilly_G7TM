from collections import namedtuple
from typing import Any, Dict, IO, Iterable, List, Optional, Tuple

from ruamel import yaml
from termcolor import colored

from . import api
from .util import read_context


CONFIG_DESC = """
Additional configuration arguments for setting up a command.
Arguments should be specified as 'key=value'. Nested configuration
keys can be specified by dot notation, e.g., 'resources.slots=4'.
List values can be specified by comma-separated values, e.g.,
'environment.runtime_packages=pandas==0.23.4,scikit-learn==0.20.1'.
"""

CONTEXT_DESC = """
The filepath to a directory that contains the set of files used to
execute the command. All files under this directory will be packaged,
maintaining the existing directory structure. The total byte contents
of the directory must not exceed 96 MB. By default, the context
directory will be empty.
"""

VOLUME_DESC = """
A mount specification in the form of <host path>:<container path>. The
given path on the host machine will be mounted under the given path in
the command container.
"""


_CONFIG_PATHS_COERCE_TO_LIST = {
    "environment.runtime_packages",
    "environment.runtime_commands",
    "bind_mounts",
}


Command = namedtuple(
    "Command", ["id", "owner", "registered_time", "config", "state", "ports", "exit_status", "misc"]
)

CommandDescription = namedtuple(
    "CommandDescription", ["id", "owner", "description", "state", "exit_status"]
)


def describe_command(command: Command) -> CommandDescription:
    return CommandDescription(
        command.id,
        command.owner["username"],
        command.config["description"],
        command.state,
        command.exit_status,
    )


def _set_nested_config(config: Dict[str, Any], key_path: List[str], value: Any) -> Dict[str, Any]:
    current = config
    for key in key_path[:-1]:
        current = current.setdefault(key, {})
    current[key_path[-1]] = value
    return config


def parse_config(
    config_file: Optional[IO],
    entrypoint: Optional[List[str]],
    overrides: Iterable[str],
    volumes: Iterable[str],
) -> Dict[str, Any]:
    config = {}  # type: Dict[str, Any]
    if config_file:
        with config_file:
            config = yaml.safe_load(config_file)

    for config_arg in overrides:
        if "=" not in config_arg:
            raise ValueError(
                "Could not read configuration option '{}'\n\n"
                "Expecting:\n{}".format(config_arg, CONFIG_DESC)
            )

        key, value = config_arg.split("=", maxsplit=1)  # type: Tuple[str, Any]

        # Separate values if a comma exists. Use yaml.safe_load() to cast
        # the value(s) to the type YAML would use, e.g., "4" -> 4.
        if "," in value:
            value = [yaml.safe_load(v) for v in value.split(",")]
        else:
            value = yaml.safe_load(value)

            # Certain configurations keys are expected to have list values.
            # Convert a single value to a singleton list if needed.
            if key in _CONFIG_PATHS_COERCE_TO_LIST:
                value = [value]

        # TODO(#2703): Consider using full JSONPath spec instead of dot
        # notation.
        config = _set_nested_config(config, key.split("."), value)

    for volume_arg in volumes:
        if ":" not in volume_arg:
            raise ValueError(
                "Could not read volume option '{}'\n\n"
                "Expecting:\n{}".format(volume_arg, VOLUME_DESC)
            )

        host_path, container_path = volume_arg.split(":", maxsplit=1)
        bind_mounts = config.setdefault("bind_mounts", [])
        bind_mounts.append({"host_path": host_path, "container_path": container_path})

    # Use the entrypoint command line argument if an entrypoint has not already
    # defined by previous settings.
    if not config.get("entrypoint") and entrypoint:
        config["entrypoint"] = entrypoint

    return config


def launch_command(
    master: str,
    endpoint: str,
    config: Dict[str, Any],
    context_path: Optional[str] = None,
    data: Optional[Dict[str, Any]] = None,
) -> Any:
    context = {}  # type: Dict[str, Dict[str, Any]]
    if context_path:
        # TODO: Read model def should return file info of files.
        ctx, size = read_context(context_path, use_parent_directory_in_name=False)
        for name, file in ctx.items():
            context[name] = {"content": file, "mode": 0o600}

    return api.post(
        master, endpoint, body={"config": config, "context": context, "data": data}
    ).json()


def render_event_stream(event: Any) -> None:
    description = event["snapshot"]["config"]["description"]
    if event["scheduled_event"] is not None:
        print(
            colored("Scheduling {} (id: {})...".format(description, event["parent_id"]), "yellow")
        )
    elif event["assigned_event"] is not None:
        print(colored("{} was assigned to an agent...".format(description), "green"))
    elif event["container_started_event"] is not None:
        print(colored("Container of {} has started...".format(description), "green"))
    elif event["service_ready_event"] is not None:
        pass  # Ignore this message.
    elif event["terminate_request_event"] is not None:
        print(colored("{} was requested to terminate...".format(description), "red"))
    elif event["container_terminated_event"] is not None:
        # TODO: Non-success exit statuses should be red
        stat = event["container_terminated_event"]["container"]["exit_status"]
        print(colored("{} was terminated: {}".format(description, stat), "green"))
        pass
    elif event["log_event"] is not None:
        render_log_stream(event["log_event"])
    else:
        raise ValueError("unexpected event: {}".format(event))


def render_log_stream(event: Dict[str, Any]) -> None:
    if event["type"] == "BUILD":
        prefix = colored("[DOCKER BUILD 🔨] ", "yellow")
        msg = event.get("stream", "")
        if msg and not msg.endswith("\n"):
            msg += "\n"
    elif event["type"] == "PULL":
        prefix = colored("[DOCKER PULL ⬇] ", "magenta")
        if "progress" in event:
            msg = event["progress"]
        elif "status" in event and "id" in event:
            msg = "({}) {}\n".format(event["id"], event["status"])
        else:
            msg = ""
        if msg and not msg.endswith("\n"):
            msg += "\n"
    else:
        prefix = colored("[PEDL] ", "green")
        msg = event.get("stream", "")

    if msg == "":
        return

    print("{}{}".format(prefix, msg), end="", flush=True)
