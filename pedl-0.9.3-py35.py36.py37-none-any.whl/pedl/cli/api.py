import webbrowser
from types import TracebackType
from typing import Any, Dict, Iterator, Optional
from urllib.parse import urljoin, urlparse

import lomond
import requests
import simplejson
from requests import Response

from pedl.cli.authentication import Authentication
from pedl.cli.util import add_token_to_headers


class APIException(Exception):
    """
    Raised when an API operation has failed. The status code is provided in
    the failure.
    """

    def __init__(self, response: Optional[Response] = None, message: Optional[str] = None) -> None:
        if response is None:
            if not message:
                raise ValueError("response and message cannot both be empty")
            super().__init__(message)
            return

        if response.ok:
            raise ValueError(
                "operation failure but response was valid ({}): "
                "{}".format(response.status_code, response.text)
            )
        try:
            message = response.json()["message"]
        except ValueError:
            message = response.text
        except KeyError:
            message = "Illegally formatted error message: {}".format(response.text)
        message = "Error {}: {}".format(response.status_code, message)
        super().__init__(message)


def _check_response(response: requests.Response) -> requests.Response:
    if response.ok:
        return response
    raise APIException(response=response)


def make_url(host: str, path: str) -> str:
    if not host.startswith("http"):
        host = "http://{}".format(host)
    parsed = urlparse(host)
    if not parsed.port:
        parsed = parsed._replace(netloc="{}:{}".format(parsed.netloc, 8080))
    return urljoin(parsed.geturl(), path)


def get(
    host: str, path: str, params: Optional[Dict[str, Any]] = None, authenticated: bool = True
) -> Response:
    """
    Send a GET request to the remote API.
    """
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    url = make_url(host, path)
    return _check_response(response=requests.get(url, params=params, headers=headers))


def post(
    host: str,
    path: str,
    body: Any,
    params: Optional[Dict[str, Any]] = None,
    authenticated: bool = True,
) -> Response:
    """
    Send a POST request to the remote API.
    """
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    url = make_url(host, path)
    return _check_response(response=requests.post(url, params=params, json=body, headers=headers))


def patch(
    host: str,
    path: str,
    body: Any,
    params: Optional[Dict[str, Any]] = None,
    authenticated: bool = True,
) -> Response:
    """
    Send a PATCH request to the remote API.
    """
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)
    url = make_url(host, path)

    return _check_response(response=requests.patch(url, params=params, json=body, headers=headers))


def put(
    host: str,
    path: str,
    body: Any,
    params: Optional[Dict[str, Any]] = None,
    authenticated: bool = True,
) -> Response:
    """
    Send a PUT request to the remote API.
    """
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    url = make_url(host, path)
    return _check_response(response=requests.put(url, params=params, json=body, headers=headers))


def delete(
    host: str, path: str, params: Optional[Dict[str, Any]] = None, authenticated: bool = True
) -> Response:
    """
    Send a DELETE request to the remote API.
    """
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    url = make_url(host, path)
    return _check_response(requests.delete(url, params=params, headers=headers))


def proxy(host: str, task_id: str, service: str, path: str) -> str:
    path = "proxy/{}-{}/{}".format(task_id, service, path)
    url = make_url(host, path)
    _check_response(requests.get(url))
    webbrowser.open(url)
    return url


class WebSocket:
    def __init__(self, socket: lomond.WebSocket) -> None:
        self.socket = socket

    def __enter__(self) -> "WebSocket":
        return self

    def __iter__(self) -> Iterator[Any]:
        for event in self.socket.connect(ping_rate=0):
            if isinstance(event, lomond.events.Connected):
                # Ignore the initial connection event.
                pass
            elif isinstance(event, lomond.events.Closing) or isinstance(
                event, lomond.events.Disconnected
            ):
                # The socket was successfully closed so we just return.
                return
            elif (
                isinstance(event, lomond.events.ConnectFail)
                or isinstance(event, lomond.events.Rejected)
                or isinstance(event, lomond.events.ProtocolError)
            ):
                # Any unexpected failures raise the standard API exception.
                raise APIException(message="WebSocket failure: {}".format(event.name))
            elif isinstance(event, lomond.events.Text):
                # All web socket connections are expected to be in a JSON
                # format.
                yield simplejson.loads(event.text)

    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> bool:
        if not self.socket.is_closed:
            self.socket.close()
        return False


def ws(host: str, path: str) -> WebSocket:
    """
    Connect to a web socket at the remote API.
    """
    websocket = lomond.WebSocket(make_url(host, path))
    token = Authentication.instance().get_session_token()
    websocket.add_header("Authorization".encode(), "Bearer {}".format(token).encode())
    return WebSocket(websocket)
