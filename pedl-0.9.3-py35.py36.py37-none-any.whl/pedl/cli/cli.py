import base64
import csv
import io
import json
import numbers
import os
import sys
import tarfile
import time
import uuid
import zipfile
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser, FileType, Namespace
from datetime import timezone
from pprint import pformat
from typing import Any, Dict, List, Optional, Set, Tuple, Union

import argcomplete
import argcomplete.completers
import dateutil.parser
import requests
import tabulate
from requests.models import Response
from ruamel import yaml
from termcolor import colored

import pedl
from pedl._types import ExperimentID
from pedl.check import check_eq, check_false, check_gt
from pedl.cli.authentication import (
    Authentication,
    authentication_required,
    CorruptTokenCacheException,
    UnauthenticatedException,
)
from pedl.constants import MAX_CONTEXT_SIZE
from pedl.storage import build as build_storage_manager
from pedl.storage import S3StorageManager, StorageMetadata

from .declarative_argparse import add_args, Arg, Cmd, Group
from .notebook import args_description as notebook_args_description
from .remote import args_description as remote_args_description
from .requirements import parse_requirements
from .shell import args_description as shell_args_description
from .template import args_description as template_args_description
from .tensorboard import args_description as tensorboard_args_description
from .user import args_description as user_args_description
from .util import (
    abort_on_bad_response,
    add_token_to_headers,
    do_delete,
    do_get,
    do_patch,
    do_post,
    make_url,
    read_context,
    sizeof_fmt,
)

# Avoid reporting BrokenPipeError when piping `tabulate` output through
# a filter like `head`.
FLUSH = False


def patch_experiment(args: Namespace, verb: str, patch_doc: Dict[str, Any]) -> None:
    path = "experiments/{}".format(args.experiment_id)
    headers = {"Content-Type": "application/merge-patch+json"}

    try:
        r = do_patch(args.master, path, patch_doc, headers=headers)
    except requests.exceptions.RequestException as e:
        print("Failed to {} experiment {}: {}".format(verb, args.experiment_id, e))
        sys.exit(1)

    if r.status_code != requests.codes.no_content:
        abort_on_bad_response(r, "Failed to {} experiment {}".format(verb, args.experiment_id))


def patch_agent_enabled(master_ip: str, agent_id: str, enabled: bool) -> None:
    verb = "enable" if enabled else "disable"
    path = "agents/{}".format(agent_id)
    headers = {"Content-Type": "application/merge-patch+json"}
    payload = {"enabled": enabled}

    try:
        r = do_patch(master_ip, path, payload, headers=headers)
    except requests.exceptions.RequestException as e:
        print("Failed to {} agent {}: {}".format(verb, agent_id, e))
        sys.exit(1)

    if r.status_code != requests.codes.no_content:
        abort_on_bad_response(r, "Failed to {} agent {}".format(verb, agent_id))


def patch_slot_enabled(args: Namespace, enabled: bool) -> None:
    verb = "enable" if enabled else "disable"
    path = "agents/{}/slots/{}".format(args.agent_id, args.slot_id)
    headers = {"Content-Type": "application/merge-patch+json"}
    add_token_to_headers(headers)
    payload = {"enabled": enabled}

    try:
        r = do_patch(args.master, path, payload, headers)
    except requests.exceptions.RequestException as e:
        print("Failed to {} slot {} of agent {}: {}".format(verb, args.slot_id, args.agent_id, e))
        sys.exit(1)

    if r.status_code != requests.codes.no_content:
        abort_on_bad_response(
            r, "Failed to {} slot {}, agent {}".format(verb, args.slot_id, args.agent_id)
        )


@authentication_required
def activate(args: Namespace) -> None:
    patch_experiment(args, "activate", {"state": "ACTIVE"})
    print("Activated experiment {}".format(args.experiment_id))


@authentication_required
def archive(args: Namespace) -> None:
    patch_experiment(args, "archive", {"archived": True})
    print("Archived experiment {}".format(args.experiment_id))


@authentication_required
def cancel(args: Namespace) -> None:
    patch_experiment(args, "cancel", {"state": "STOPPING_CANCELED"})
    print("Canceled experiment {}".format(args.experiment_id))


def read_model_packages(packages: List[str]) -> Tuple[bytes, int]:
    """
    Given a list of packages paths, return a 2-tuple:
    (1) A base64 encoded tarfile of all packages.
    (2) The total pre-encoded byte size of all packages.
    """
    tarstream = io.BytesIO()
    with tarfile.open(fileobj=tarstream, mode="w") as tar:
        for package in packages:
            if not os.path.isfile(package):
                print("Error: Package must be a file: {}".format(package))
                sys.exit(1)

            if not (zipfile.is_zipfile(package) or tarfile.is_tarfile(package)):
                print(
                    "Error: Package must be a wheel (.whl) or source "
                    "distribution (e.g., .tar.gz or .zip): {}".format(package)
                )
                sys.exit(1)

            tar.add(package, arcname=os.path.basename(package))

    model_packages_size = tarstream.tell()
    tarstream.seek(0)

    return base64.b64encode(tarstream.read()), model_packages_size


def test_mode(create_req_args: Dict[str, Any], master_ip: str) -> None:
    """
    Test mode validates that an experiment configuration and model definition
    associated with an experiment creation request are valid without starting
    the full experiment.

    To do this, it first checks that the experiment configuration passes master
    validation by sending the create request with the "validate_only" flag
    enabled.  Next, it modifies the experiment configuration to schedule a very
    short experiment and monitors it's progress for success. The test
    experiment is created as archived so that it is not user-visible as an
    active experiment by default in the Web UI.

    TODO(yoavz): Consider adding logic to verify that checkpoints can be
    restored in addition to verifying that checkpoints can be saved.
    """

    # First validate the unmodified experiment configuration.
    print(colored("Validating experiment configuration...", "yellow"), end="\r")
    validate_req = do_post(master_ip, "experiments", {**create_req_args, "validate_only": True})
    if validate_req.status_code != requests.codes.no_content:
        abort_on_bad_response(
            validate_req, colored("Experiment configuration validation failed", "red")
        )
    else:
        print(colored("Experiment configuration validation succeeded! 🎉", "green"))

    # Next, modify the experiment configuration such that:
    # 1. The training step takes a minimum amount of time.
    # 2. All checkpoints are GC'd after experiment finishes.
    # 3. The experiment does not attempt restarts on failure.
    experiment_config = yaml.safe_load(create_req_args["experiment_config"])
    experiment_config.update(
        {
            "description": "[test-mode] {}".format(
                experiment_config.get("description", str(uuid.uuid4()))
            ),
            "batches_per_step": 1,
            "checkpoint_storage": {
                **experiment_config["checkpoint_storage"],
                "save_experiment_best": 0,
                "save_trial_best": 0,
                "save_trial_latest": 0,
            },
            "searcher": {
                "name": "single",
                "metric": experiment_config["searcher"]["metric"],
                "max_steps": 1,
            },
            "resources": {**experiment_config.get("resources", {})},
            "max_restarts": 0,
        }
    )
    create_req_args["experiment_config"] = yaml.safe_dump(experiment_config)

    create_req = do_post(master_ip, "experiments", {**create_req_args, "archived": True})
    if create_req.status_code != requests.codes.created:
        abort_on_bad_response(create_req, "Failed to create experiment")

    new_resource = create_req.headers["Location"]
    experiment_id = new_resource.split("/")[-1]
    patch_experiment(
        Namespace(experiment_id=experiment_id, master=master_ip), "activate", {"state": "ACTIVE"}
    )
    print(colored("Test experiment ID: {}".format(experiment_id), "green"))

    def print_progress(active_stage: int, ended: bool) -> None:
        # There are four sequential stages of verification. Track the
        # current stage with an index into this list.
        stages = [
            "Scheduling task",
            "Testing training",
            "Testing validation",
            "Testing checkpointing",
        ]

        for idx, stage in enumerate(stages):
            if active_stage > idx:
                color = "green"
                checkbox = "✔"
            elif active_stage == idx:
                color = "red" if ended else "yellow"
                checkbox = "✗" if ended else " "
            else:
                color = "white"
                checkbox = " "
            print(colored(stage + (25 - len(stage)) * ".", color), end="")
            print(colored(" [" + checkbox + "]", color), end="")

            if idx == len(stages) - 1:
                print("\n" if ended else "\r", end="")
            else:
                print(", ", end="")

    url = make_url(master_ip, "experiments/{}".format(experiment_id))
    while True:
        r = do_get(url, "list trials for create --test-mode").json()

        # Wait for experiment to start and initialize a trial and step.
        if len(r["trials"]) < 1 or len(r["trials"][0]["steps"]) < 1:
            step = {}  # type: Dict
        else:
            step = r["trials"][0]["steps"][0]

        # Update the active_stage by examining the result from master
        # /experiments/<experiment-id> endpoint.
        if r["state"] == "COMPLETED":
            active_stage = 4
        elif step.get("checkpoint"):
            active_stage = 3
        elif step.get("validation"):
            active_stage = 2
        elif step:
            active_stage = 1
        else:
            active_stage = 0

        # If the experiment is in a terminal state, output the appropriate
        # message and exit. Otherwise, sleep and repeat.
        if r["state"] == "COMPLETED":
            print_progress(active_stage, ended=True)
            print(colored("Model definition test succeeded! 🎉", "green"))
            return
        elif r["state"] == "CANCELED":
            print_progress(active_stage, ended=True)
            print(
                colored(
                    "Model definition test (ID: {}) canceled before "
                    "model test could complete. Please re-run the "
                    "command.".format(experiment_id),
                    "yellow",
                )
            )
            sys.exit(1)
        elif r["state"] == "ERROR":
            print_progress(active_stage, ended=True)
            trial_id = r["trials"][0]["id"]
            logs_args = Namespace(trial_id=trial_id, master=master_ip, tail=None, follow=False)
            logs(logs_args)
            sys.exit(1)
        else:
            print_progress(active_stage, ended=False)
            time.sleep(0.2)


def read_git_metadata(args: Namespace) -> Tuple[str, str, str, str]:
    """
    Attempt to read the git metadata from the model definition directory. If
    unsuccessful, print a descriptive error statement and exit.
    """
    try:
        from git import Repo
    except ImportError as e:
        print("Error: Please verify that git is installed correctly: {}".format(e))
        sys.exit(1)

    if os.path.isdir(args.model_def):
        repo_path = os.path.abspath(args.model_def)
    else:
        repo_path = os.path.abspath(os.path.dirname(args.model_def))

    if not os.path.isdir(os.path.join(repo_path, ".git")):
        print(
            "Error: No git directory found at {}. Please "
            "initialize a git repository or refrain from "
            "using the --git feature.".format(repo_path)
        )
        sys.exit(1)

    try:
        repo = Repo(repo_path)
    except Exception as e:
        print("Failed to initialize git repository at ", "{}: {}".format(repo_path, e))
        sys.exit(1)

    if repo.is_dirty():
        print(
            "Git working directory is dirty. Please commit the "
            "following changes before creating an experiment "
            "with the --git feature:\n"
        )
        print(repo.git.status())
        sys.exit(1)

    commit = repo.commit()
    commit_hash = commit.hexsha
    committer = "{} <{}>".format(commit.committer.name, commit.committer.email)
    commit_date = commit.committed_datetime.isoformat()

    # To get the upstream remote URL:
    #
    # (1) Get the current upstream branch name
    #     (https://stackoverflow.com/a/9753364/2596715)
    # (2) Parse the git remote name from the upstream branch name.
    # (3) Retrieve the URL of the remote from the git configuration.
    try:
        upstream_branch = repo.git.rev_parse("@{u}", abbrev_ref=True, symbolic_full_name=True)
        remote_name = upstream_branch.split("/", 1)[0]
        remote_url = repo.git.config("remote.{}.url".format(remote_name), get=True)
        print("Using remote URL '{}' from upstream branch '{}'".format(remote_url, upstream_branch))
    except Exception as e:
        print("Failed to find the upstream branch: ", e)
        sys.exit(1)

    return (remote_url, commit_hash, committer, commit_date)


@authentication_required
def create(args: Namespace) -> None:
    experiment_config = yaml.safe_load(args.config_file.read())
    if not experiment_config:
        experiment_config = {}
    args.config_file.close()

    packages = experiment_config.setdefault("environment", {}).setdefault("runtime_packages", {})
    if isinstance(packages, list):
        packages = {"cpu": packages, "gpu": packages}
    else:
        packages = {"cpu": packages.get("cpu", []), "gpu": packages.get("gpu", [])}

    for requirement in args.requirement:
        additions = [str(req.req) for req in parse_requirements(requirement, session=True)]
        for key in packages.keys():
            packages[key].extend(additions)

    experiment_config["environment"]["runtime_packages"] = packages

    msg = {"experiment_config": yaml.safe_dump(experiment_config)}

    model_def, model_size = read_context(args.model_def)
    model_packages, model_packages_size = read_model_packages(args.package)

    if (model_size + model_packages_size) > MAX_CONTEXT_SIZE:
        print(
            "Error: Model definition and provided packages "
            "are size {}, which exceeds the maximum size "
            "{}.".format(sizeof_fmt(model_size + model_packages_size), sizeof_fmt(MAX_CONTEXT_SIZE))
        )
        sys.exit(1)

    msg["model_definition"] = model_def
    if len(model_packages) > 0:
        msg["model_packages"] = model_packages

    if args.template:
        msg["template"] = args.template

    if args.git:
        (
            msg["git_remote"],
            msg["git_commit"],
            msg["git_committer"],
            msg["git_commit_date"],
        ) = read_git_metadata(args)

    if args.test_mode:
        test_mode(msg, args.master)
        return

    r = do_post(args.master, "experiments", msg)
    if r.status_code != requests.codes.created:
        abort_on_bad_response(r, "Failed to create experiment")

    new_resource = r.headers["Location"]
    experiment_id = new_resource.split("/")[-1]
    print("Created experiment {}".format(experiment_id))

    # Activate the new experiment unless "--paused" is given.
    if not args.paused:
        activate_args = Namespace(experiment_id=experiment_id, master=args.master)
        activate(activate_args)

        if args.follow_first_trial:
            # Poll the master until the first trial has begun.
            print("Waiting for first trial to begin...")
            url = make_url(args.master, "experiments/{}".format(experiment_id))
            while True:
                r = do_get(url, "list trials for create --follow-first-trial")
                if len(r.json()["trials"]) > 0:
                    break
                else:
                    time.sleep(0.1)

            # If there is more than one trial, use the one with the lowest ID.
            first_trial_id = sorted(t_id["id"] for t_id in r.json()["trials"])[0]
            print("Following first trial with ID {}".format(first_trial_id))

            # Call `logs --follow` on the new trial.
            logs_args = Namespace(
                trial_id=first_trial_id, follow=True, master=args.master, tail=None
            )
            logs(logs_args)


def tabulate_or_csv(
    headers: List[str], values: List[List[str]], as_csv: bool, outfile: Optional[str] = None
) -> None:
    out = open(outfile, "w") if outfile else sys.stdout
    if as_csv or outfile:
        writer = csv.writer(out)
        writer.writerow(headers)
        writer.writerows(values)
    else:
        print(tabulate.tabulate(values, headers, tablefmt="presto"), file=out, flush=FLUSH)


@authentication_required
def delete_experiment(args: Namespace) -> None:
    if args.yes or yes_or_no(
        "Deleting an experiment will result in the unrecoverable \n"
        "deletion of all associated logs, checkpoints, and other \n"
        "metadata associated with the experiment. For a recoverable \n"
        "alternative, see the 'pedl archive' command. Do you still \n"
        "wish to proceed?"
    ):
        url = make_url(args.master, "experiments/{}".format(args.experiment_id))
        try:
            r = do_delete(url, "delete experiment")
        except requests.exceptions.RequestException as e:
            print("Failed to delete experiment {}: {}".format(args.experiment_id, e))
            sys.exit(1)

        if r.status_code != requests.codes.no_content:
            abort_on_bad_response(r, "Failed to delete experiment {}".format(args.experiment_id))
        else:
            print("Successfully deleted experiment {}".format(args.experiment_id))

    else:
        print("Aborting experiment deletion.")


@authentication_required
def describe(args: Namespace) -> None:
    docs = []
    for experiment_id in args.experiment_id.split(","):
        if args.metrics:
            url = make_url(args.master, "experiments/{}/metrics/summary".format(experiment_id))
        else:
            url = make_url(args.master, "experiments/{}".format(experiment_id))
        r = do_get(url, "describe experiment")
        docs.append(r.json())

    if args.json:
        print(json.dumps(docs, indent=4))
        return

    headers = [
        "Experiment ID",
        "State",
        "Progress",
        "Start Time",
        "End Time",
        "Description",
        "Archived",
        "Labels",
    ]
    values = [
        [
            doc["id"],
            doc["state"],
            format_percent(doc["progress"]),
            format_time(doc.get("start_time")),
            format_time(doc.get("end_time")),
            doc["config"].get("description"),
            doc["archived"],
            ", ".join(sorted(doc["config"].get("labels", []))),
        ]
        for doc in docs
    ]
    if not args.outdir:
        outfile = None
        print("Experiment:")
    else:
        outfile = os.path.join(args.outdir, "experiments.csv")
    tabulate_or_csv(headers, values, args.csv, outfile)

    headers = ["Trial ID", "Experiment ID", "State", "Start Time", "End Time", "H-Params"]
    values = [
        [
            trial["id"],
            doc["id"],
            trial["state"],
            format_time(trial.get("start_time")),
            format_time(trial.get("end_time")),
            json.dumps(trial["hparams"], indent=4),
        ]
        for doc in docs
        for trial in doc["trials"]
    ]
    if not args.outdir:
        outfile = None
        print("\nTrials:")
    else:
        outfile = os.path.join(args.outdir, "trials.csv")
    tabulate_or_csv(headers, values, args.csv, outfile)

    if args.metrics:
        # Accumulate the scalar training and validation metric names
        # from all provided experiments.
        t_metrics_names = sorted(
            list({n for doc in docs for n in scalar_training_metrics_names(doc)})
        )
        t_metrics_headers = ["Training Metric: {}".format(name) for name in t_metrics_names]

        v_metrics_names = sorted(
            list({n for doc in docs for n in scalar_validation_metrics_names(doc)})
        )

        v_metrics_headers = ["Validation Metric: {}".format(name) for name in v_metrics_names]
    else:
        t_metrics_headers = []
        v_metrics_headers = []

    headers = (
        ["Trial ID", "Step ID", "State", "Start Time", "End Time"]
        + t_metrics_headers
        + [
            "Checkpoint State",
            "Checkpoint Start Time",
            "Checkpoint End Time",
            "Validation State",
            "Validation Start Time",
            "Validation End Time",
        ]
        + v_metrics_headers
    )

    values = []
    for doc in docs:
        for trial in doc["trials"]:
            for step in trial["steps"]:
                t_metrics_fields = []
                if step.get("metrics"):
                    avg_metrics = step["metrics"]["avg_metrics"]
                    for name in t_metrics_names:
                        if name in avg_metrics:
                            t_metrics_fields.append(avg_metrics[name])
                        else:
                            t_metrics_fields.append(None)

                checkpoint = step.get("checkpoint")
                if checkpoint:
                    checkpoint_state = checkpoint["state"]
                    checkpoint_start_time = checkpoint.get("start_time")
                    checkpoint_end_time = checkpoint.get("end_time")
                else:
                    checkpoint_state = None
                    checkpoint_start_time = None
                    checkpoint_end_time = None

                validation = step.get("validation")
                if validation:
                    validation_state = validation["state"]
                    validation_start_time = validation.get("start_time")
                    validation_end_time = validation.get("end_time")

                else:
                    validation_state = None
                    validation_start_time = None
                    validation_end_time = None

                if args.metrics:
                    v_metrics_fields = [
                        get_validation_metric(name, validation) for name in v_metrics_names
                    ]
                else:
                    v_metrics_fields = []

                row = (
                    [
                        step["trial_id"],
                        step["id"],
                        step["state"],
                        format_time(step.get("start_time")),
                        format_time(step.get("end_time")),
                    ]
                    + t_metrics_fields
                    + [
                        checkpoint_state,
                        format_time(checkpoint_start_time),
                        format_time(checkpoint_end_time),
                        validation_state,
                        format_time(validation_start_time),
                        format_time(validation_end_time),
                    ]
                    + v_metrics_fields
                )
                values.append(row)

    if not args.outdir:
        outfile = None
        print("\nSteps:")
    else:
        outfile = os.path.join(args.outdir, "steps.csv")
    tabulate_or_csv(headers, values, args.csv, outfile)


@authentication_required
def config(args: Namespace) -> None:
    url = make_url(args.master, "experiments/{}/config".format(args.experiment_id))
    result = do_get(url, "experiment config")
    yaml.safe_dump(result.json(), stream=sys.stdout, default_flow_style=False)


def download_model_zip(master: str, experiment_id: ExperimentID) -> zipfile.ZipFile:
    url = make_url(master, "experiments/{}/model_def".format(experiment_id))
    res = do_get(url, "model definition")
    return zipfile.ZipFile(io.BytesIO(res.content))


@authentication_required
def download_model_def(args: Namespace) -> None:
    zf = download_model_zip(args.master, args.experiment_id)
    zf.extractall(path=args.output_dir)


# TODO(neilc): Report more info about checkpoints and validations.
def format_checkpoint(checkpoint: Dict[str, Any]) -> List[Any]:
    if checkpoint is None:
        return [None, None]

    if checkpoint["state"] in ("COMPLETED", "DELETED"):
        return [checkpoint["state"], checkpoint["uuid"]]
    elif checkpoint["state"] in ("ACTIVE", "ERROR"):
        return [checkpoint["state"], None]
    else:
        raise AssertionError("Invalid checkpoint state: {}".format(checkpoint["state"]))


def format_validation(validation: Dict[str, Any]) -> List[Any]:
    if validation is None:
        return [None, None]

    if validation["state"] == "COMPLETED":
        return ["COMPLETED", json.dumps(validation["metrics"], indent=4)]
    elif validation["state"] in ("ACTIVE", "ERROR"):
        return [validation["state"], None]
    else:
        raise AssertionError("Invalid validation state: {}".format(validation["state"]))


@authentication_required
def describe_trial(args: Namespace) -> None:
    if args.metrics:
        url = make_url(args.master, "trials/{}/metrics".format(args.trial_id))
    else:
        url = make_url(args.master, "trials/{}".format(args.trial_id))

    r = do_get(url, "describe trial")
    trial = r.json()

    if args.json:
        print(json.dumps(trial, indent=4))
        return

    # Print information about the trial itself.
    headers = ["Experiment ID", "State", "H-Params", "Start Time", "End Time"]
    values = [
        [
            trial["experiment_id"],
            trial["state"],
            json.dumps(trial["hparams"], indent=4),
            format_time(trial["start_time"]),
            format_time(trial["end_time"]),
        ]
    ]
    tabulate_or_csv(headers, values, args.csv)

    # Print information about individual steps.
    headers = [
        "Step #",
        "State",
        "Start Time",
        "End Time",
        "Checkpoint",
        "Checkpoint UUID",
        "Validation",
        "Validation Metrics",
    ]
    if args.metrics:
        headers.append("Step Metrics")

    values = [
        [
            s["id"],
            s["state"],
            format_time(s["start_time"]),
            format_time(s["end_time"]),
            *format_checkpoint(s["checkpoint"]),
            *format_validation(s["validation"]),
            *([json.dumps(s["metrics"], indent=4)] if args.metrics else []),
        ]
        for s in trial["steps"]
    ]

    print()
    print("Steps:")
    tabulate_or_csv(headers, values, args.csv)


def find_all_agent_ids(args: Namespace) -> List[str]:
    r = do_get(make_url(args.master, "agents"), "list agents")
    return [a["id"] for a in r.json().values()]


@authentication_required
def disable_agent(args: Namespace) -> None:
    check_false(args.all and args.agent_id)

    if not (args.all or args.agent_id):
        print("Error: must specify exactly one of `--all` or agent_id")
        sys.exit(1)

    if args.agent_id:
        agent_ids = [args.agent_id]
    else:
        agent_ids = sorted(find_all_agent_ids(args))
        print("Disabling {} agents".format(len(agent_ids)))

    for agent_id in agent_ids:
        patch_agent_enabled(args.master, agent_id, False)
        print("Disabled agent {}".format(agent_id))


@authentication_required
def disable_slot(args: Namespace) -> None:
    patch_slot_enabled(args, False)
    print("Disabled slot {} of agent {}".format(args.slot_id, args.agent_id))


@authentication_required
def enable_agent(args: Namespace) -> None:
    check_false(args.all and args.agent_id)

    if not (args.all or args.agent_id):
        print("Error: must specify exactly one of `--all` or agent_id")
        sys.exit(1)

    if args.agent_id:
        agent_ids = [args.agent_id]
    else:
        agent_ids = sorted(find_all_agent_ids(args))
        print("Enabling {} agents".format(len(agent_ids)))

    for agent_id in agent_ids:
        patch_agent_enabled(args.master, agent_id, True)
        print("Enabled agent {}".format(agent_id))


@authentication_required
def enable_slot(args: Namespace) -> None:
    patch_slot_enabled(args, True)
    print("Enabled slot {} of agent {}".format(args.slot_id, args.agent_id))


@authentication_required
def kill_trial(args: Namespace) -> None:
    r = do_post(args.master, "trials/{}/kill".format(args.trial_id), {})
    if r.status_code != requests.codes.no_content:
        print("Failed to kill trial {}: {}".format(args.trial_id, r.json().get("message")))
        sys.exit(1)

    print("Killed trial {}".format(args.trial_id))


@authentication_required
def kill_experiment(args: Namespace) -> None:
    r = do_post(args.master, "experiments/{}/kill".format(args.experiment_id), {})
    if r.status_code != requests.codes.no_content:
        print(
            "Failed to kill experiment {}: {}".format(args.experiment_id, r.json().get("message"))
        )
        sys.exit(1)

    print("Killed experiment {}".format(args.experiment_id))


def format_time(datetime_str: Optional[str]) -> Optional[str]:
    if datetime_str is None:
        return None
    dt = dateutil.parser.parse(datetime_str)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S%z")


def format_percent(f: Optional[float]) -> Optional[str]:
    if f is None:
        return None

    return "{:.1%}".format(f)


def format_resource_sizes(resources: Optional[Dict[str, int]]) -> str:
    if resources is None:
        return ""
    else:
        return sizeof_fmt(sum(resources.values()))


def format_resources(resources: Optional[List[str]]) -> str:
    if resources is None:
        return ""
    else:
        return "\n".join(sorted(resources))


@authentication_required
def list_experiments(args: Namespace) -> None:
    params = {}
    if args.all:
        params["filter"] = "all"
    else:
        params["user"] = Authentication.instance().get_session_user()

    r = do_get(make_url(args.master, "experiments"), "list experiments", params=params)

    def format_experiment(e: Dict[str, Any]) -> List[Any]:
        result = [
            e["id"],
            e["owner"]["username"],
            e["config"]["description"],
            e["state"],
            format_percent(e["progress"]),
            format_time(e["start_time"]),
            format_time(e["end_time"]),
        ]
        if args.all:
            result.append(e["archived"])
        return result

    headers = ["ID", "Owner", "Description", "State", "Progress", "Start Time", "End Time"]
    if args.all:
        headers.append("Archived")

    values = [format_experiment(e) for e in r.json()]
    tabulate_or_csv(headers, values, args.csv)


@authentication_required
def list_agents(args: Namespace) -> None:
    r = do_get(make_url(args.master, "agents"), "list agents")

    # Sort agents by ID to ensure predictable output order.
    agents = r.json()
    headers = ["Agent Name", "Registered Time", "Enabled", "Slots"]
    values = [
        [agent["name"], format_time(agent["registered_time"]), agent["enabled"], agent["num_slots"]]
        for _, agent in sorted(agents.items())
    ]

    tabulate_or_csv(headers, values, args.csv)


def get_validation_metric(metric_name: str, validation: Optional[Dict[str, Any]]) -> Optional[Any]:
    if validation is None:
        return None

    try:
        return validation["metrics"]["validation_metrics"][metric_name]
    except (KeyError, TypeError):
        return None


def is_number(value: Any) -> bool:
    return isinstance(value, numbers.Number)


def scalar_training_metrics_names(exp: Dict[str, Any]) -> Set[str]:
    """
    Given an experiment history, return the names of training metrics
    that are associated with scalar, numeric values.

    This function assumes that all batches in an experiment return
    consistent training metric names and types. Therefore, the first
    non-null batch metrics dictionary is used to extract names.
    """
    for trial in exp["trials"]:
        for step in trial["steps"]:
            metrics = step.get("metrics")
            if not metrics:
                continue
            return {name for name in metrics.get("avg_metrics", {}).keys()}

    return set()


def scalar_validation_metrics_names(exp: Dict[str, Any]) -> Set[str]:
    for trial in exp["trials"]:
        for step in trial["steps"]:
            try:
                v_metrics = step["validation"]["metrics"]["validation_metrics"]
                return {metric for metric, value in v_metrics.items() if is_number(value)}
            except Exception:
                pass

    return set()


@authentication_required
def list_checkpoints(args: Namespace) -> None:
    params = {}
    if args.best is not None:
        assert args.best >= 0, "--best must be a non-negative integer"
        params["best"] = args.best

    url = make_url(args.master, "experiments/{}/checkpoints".format(args.experiment_id))
    r = do_get(url, "describe experiment", params=params).json()
    searcher_metric = r["metric_name"]

    headers = ["Trial ID", "Step ID", "State", "Validation Metric", "UUID", "Resources", "Size"]
    values = [
        [
            c["trial_id"],
            c["step_id"],
            c["state"],
            get_validation_metric(searcher_metric, c["step"]["validation"]),
            c["uuid"],
            format_resources(c["resources"]),
            format_resource_sizes(c["resources"]),
        ]
        for c in r["checkpoints"]
    ]

    tabulate_or_csv(headers, values, args.csv)

    if args.download_dir is not None:
        url = make_url(args.master, "experiments/{}/config".format(args.experiment_id))
        cfg = do_get(url, "experiment config for checkpoint download").json()
        manager = build_storage_manager(cfg["checkpoint_storage"])
        if not isinstance(manager, S3StorageManager):
            print(
                "--download-dir requires an experiment to be configured "
                "with S3 checkpointing, {} found instead".format(cfg["checkpoint_storage"]["type"])
            )
            sys.exit(1)

        for checkpoint in r["checkpoints"]:
            metadata = StorageMetadata.from_json(checkpoint)
            ckpt_dir = os.path.join(
                args.download_dir,
                "exp-{}-trial-{}-step-{}".format(
                    args.experiment_id, checkpoint["trial_id"], checkpoint["step_id"]
                ),
            )
            print("Downloading checkpoint {} to {}".format(checkpoint["uuid"], ckpt_dir))
            manager.download(metadata, ckpt_dir)


@authentication_required
def download_s3_checkpoint_cmd(args: Namespace) -> None:
    download_s3_checkpoint(args.master, args.trial_id, args.step_id, args.output_dir)


def download_s3_checkpoint(master: str, trial_id: int, step_id: int, output_dir: str) -> None:
    url = make_url(master, "trials/{}".format(trial_id))
    r = do_get(url, "describe trial")
    trial = r.json()

    url = make_url(master, "experiments/{}".format(trial["experiment_id"]))
    r = do_get(url, "describe experiment")
    experiment = r.json()

    step = trial["steps"][step_id - 1]
    check_eq(step_id, step["id"])

    assert step["checkpoint"] is not None, "Trial {} step {} has no checkpoint!".format(
        trial_id, step_id
    )

    checkpoint = step["checkpoint"]

    manager = build_storage_manager(experiment["config"]["checkpoint_storage"])
    assert isinstance(manager, S3StorageManager), (
        "Downloading from S3 requires the experiment to be configured with "
        "S3 checkpointing, {} found instead".format(
            experiment["config"]["checkpoint_storage"]["type"]
        )
    )
    metadata = StorageMetadata.from_json(checkpoint)
    manager.download(metadata, output_dir)


def find_disabled_agents(master_ip: str) -> Set[str]:
    r = do_get(make_url(master_ip, "agents"), "list agents")
    agents = r.json()
    return {agent_id for agent_id, agent in agents.items() if not agent["enabled"]}


@authentication_required
def list_slots(args: Namespace) -> None:
    disabled_agents = find_disabled_agents(args.master)
    r = do_get(make_url(args.master, "slots"), "list slots")

    def enabled_str(agent_id: str, slot_enabled: bool) -> str:
        if not slot_enabled:
            return "False"
        if agent_id in disabled_agents:
            return "True (agent disabled)"

        return "True"

    # Sort agents by ID to ensure predictable output order.
    agents = r.json()
    headers = ["Agent Name", "Slot ID", "Enabled", "Task", "Task ID", "Type", "Device"]
    values = [
        [
            s["agent_name"],
            s["id"],
            enabled_str(agent_id, s["enabled"]),
            s["task"]["name"] if s["task"] else "FREE",
            s["task"]["id"] if s["task"] else "N/A",
            s["device"]["type"],
            s["device_name"],
        ]
        for agent_id in sorted(agents.keys())
        for s in agents[agent_id]
    ]

    tabulate_or_csv(headers, values, args.csv)


@authentication_required
def list_tasks(args: Namespace) -> None:
    r = do_get(make_url(args.master, "tasks"), "list tasks")

    def agent_info(t: Dict[str, Any]) -> Union[str, List[str]]:
        containers = t.get("containers", [])
        if not containers:
            return "unassigned"
        if len(containers) == 1:
            agent = containers[0]["agent"]  # type: str
            return agent
        return [c["agent"] for c in containers]

    def get_state_rank(state: str) -> int:
        if state == "PENDING":
            return 0
        if state == "RUNNING":
            return 1
        if state == "TERMINATING":
            return 2
        if state == "TERMINATED":
            return 3
        return 4

    tasks = r.json()
    headers = ["ID", "Name", "Slots Needed", "Registered Time", "State", "Agent", "Exit Status"]
    values = [
        [
            task_id,
            task["name"],
            task["slots_needed"],
            format_time(task["registered_time"]),
            task["state"],
            agent_info(task),
            task["exit_status"] if task.get("exit_status", None) else "N/A",
        ]
        for task_id, task in sorted(
            tasks.items(),
            key=lambda tup: (
                get_state_rank(tup[1]["state"]),
                format_time(tup[1]["registered_time"]),
            ),
        )
    ]

    tabulate_or_csv(headers, values, args.csv)


@authentication_required
def list_trials(args: Namespace) -> None:
    url = make_url(args.master, "experiments/{}/summary".format(args.experiment_id))
    r = do_get(url, "list trials")
    experiment = r.json()

    headers = ["Trial ID", "State", "H-Params", "Start Time", "End Time", "# of Steps"]
    values = [
        [
            t["id"],
            t["state"],
            json.dumps(t["hparams"], indent=4),
            format_time(t["start_time"]),
            format_time(t["end_time"]),
            t["num_steps"],
        ]
        for t in experiment["trials"]
    ]

    tabulate_or_csv(headers, values, args.csv)


@authentication_required
def logs(args: Namespace) -> None:
    def process_response(r: Response, latest_log_id: int) -> Tuple[int, bool]:
        changes = False
        for log in r.json():
            check_gt(log["id"], latest_log_id)
            latest_log_id = log["id"]
            print(log["message"], end="")
            changes = True

        return latest_log_id, changes

    url = make_url(args.master, "trials/{}/logs".format(args.trial_id))
    params = {}
    if args.tail:
        params["tail"] = args.tail

    r = do_get(url, "fetch trial logs", params)
    latest_log_id, _ = process_response(r, -1)

    # "Follow" mode is implemented as a loop in the CLI. We assume that
    # newer log messages have a numerically larger ID than older log
    # messages, so we keep track of the max ID seen so far.
    if args.follow:
        no_change_count = 0
        while True:
            try:
                # Poll for new logs every 100 ms.
                time.sleep(0.1)

                # The `tail` parameter only makes sense the first time we
                # fetch logs.
                r = do_get(url, "fetch trial logs", {"greater_than_id": latest_log_id})
                latest_log_id, changes = process_response(r, latest_log_id)
                no_change_count = 0 if changes else no_change_count + 1

                # Wait for 10 poll requests before checking that the experiment is in a stopped
                # state.
                if no_change_count >= 10:
                    no_change_count = 0
                    state_url = make_url(args.master, "trials/{}".format(args.trial_id))
                    r = do_get(state_url, "fetch trial state")
                    if r.json()["state"] in ("COMPLETED", "CANCELED", "ERROR"):
                        raise KeyboardInterrupt()
            except KeyboardInterrupt:
                url = make_url(args.master, "trials/{}".format(args.trial_id))
                r = do_get(url, "describe trial")
                trial = r.json()
                print(
                    colored(
                        "Trial is in a(n) {} state. To reopen log stream, run: "
                        "pedl trial logs -f {}".format(trial["state"], args.trial_id),
                        "green",
                    )
                )
                break


@authentication_required
def pause(args: Namespace) -> None:
    patch_experiment(args, "pause", {"state": "PAUSED"})
    print("Paused experiment {}".format(args.experiment_id))


@authentication_required
def preview_search(args: Namespace) -> None:
    experiment_config = yaml.safe_load(args.config_file.read())
    args.config_file.close()

    if "searcher" not in experiment_config:
        print("Experiment configuration must have 'searcher' section")
        sys.exit(1)
    r = do_post(args.master, "searcher/preview", body=experiment_config)
    if r.status_code != requests.codes.ok:
        raise Exception(r.json()["message"])
    j = r.json()

    def count_steps(sequence: str) -> int:
        return sum(1 for k in sequence if k == "S")

    def to_full_name(kind: str) -> str:
        if kind == "S":
            return "step"
        elif kind == "V":
            return "validation"
        elif kind == "C":
            return "checkpoint"
        else:
            raise ValueError("unexpected kind: {}".format(kind))

    def render_sequence(sequence: str) -> str:
        if not sequence:
            return "N/A"
        instructions = []
        current = sequence[0]
        count = 0
        for k in sequence:
            if k != current:
                instructions.append("{} x {}".format(count, to_full_name(current)))
                current = k
                count = 1
            else:
                count += 1
        instructions.append("{} x {}".format(count, to_full_name(current)))
        return ", ".join(instructions)

    headers = ["Trials", "Steps", "Breakdown"]
    values = [
        (count, count_steps(workloads), render_sequence(workloads))
        for workloads, count in j["results"].items()
    ]

    print(colored("Using search configuration:", "green"))
    yml = yaml.YAML()
    yml.indent(mapping=2, sequence=4, offset=2)
    yml.dump(experiment_config["searcher"], sys.stdout)
    print()
    print(
        "This search will create a total of {} trial(s) and run {} steps".format(
            sum(j["results"].values()),
            sum(count_steps(workloads) * cnt for workloads, cnt in j["results"].items()),
        )
    )
    print(tabulate.tabulate(values, headers, tablefmt="presto"), flush=FLUSH)


@authentication_required
def set_description(args: Namespace) -> None:
    patch_experiment(args, "change description of", {"description": args.description})
    print("Set description of experiment {} to '{}'".format(args.experiment_id, args.description))


@authentication_required
def add_label(args: Namespace) -> None:
    patch_experiment(args, "add label to", {"labels": {args.label: True}})
    print("Added label '{}' to experiment {}".format(args.label, args.experiment_id))


@authentication_required
def remove_label(args: Namespace) -> None:
    patch_experiment(args, "remove label from", {"labels": {args.label: None}})
    print("Removed label '{}' from experiment {}".format(args.label, args.experiment_id))


@authentication_required
def set_max_slots(args: Namespace) -> None:
    patch_experiment(args, "change `max_slots` of", {"resources": {"max_slots": args.max_slots}})
    print("Set `max_slots` of experiment {} to {}".format(args.experiment_id, args.max_slots))


@authentication_required
def set_weight(args: Namespace) -> None:
    patch_experiment(args, "change `weight` of", {"resources": {"weight": args.weight}})
    print("Set `weight` of experiment {} to {}".format(args.experiment_id, args.weight))


@authentication_required
def set_gc_policy(args: Namespace) -> None:
    policy = {
        "save_experiment_best": args.save_experiment_best,
        "save_trial_best": args.save_trial_best,
        "save_trial_latest": args.save_trial_latest,
    }

    if not args.yes:
        url = make_url(args.master, "experiments/{}/preview_gc".format(args.experiment_id))
        r = do_get(url, "get checkpoints", params=policy)
        response = r.json()
        checkpoints = response["checkpoints"]
        metric_name = response["metric_name"]

        headers = [
            "Trial ID",
            "Step ID",
            "State",
            "Validation Metric\n({})".format(metric_name),
            "UUID",
            "Resources",
        ]
        values = [
            [
                c["trial_id"],
                c["step_id"],
                c["state"],
                get_validation_metric(metric_name, c["step"]["validation"]),
                c["uuid"],
                format_resources(c["resources"]),
            ]
            for c in sorted(checkpoints, key=lambda c: (c["trial_id"], c["step_id"]))
            if "step" in c and c["step"].get("validation") is not None
        ]

        if len(values) != 0:
            print(
                "The following checkpoints with validation will be deleted "
                "by applying this GC Policy:"
            )
            print(tabulate.tabulate(values, headers, tablefmt="presto"), flush=FLUSH)
        print(
            "This policy will delete {} checkpoints with "
            "validations and {} checkpoints without validations.".format(
                len(values), len(checkpoints) - len(values)
            )
        )

    if args.yes or yes_or_no(
        "Changing the checkpoint garbage collection policy of an "
        "experiment may result\n"
        "in the unrecoverable deletion of checkpoints.  Do you wish to "
        "proceed?"
    ):
        patch_experiment(args, "change gc policy of", {"checkpoint_storage": policy})
        print("Set GC policy of experiment {} to\n{}".format(args.experiment_id, pformat(policy)))
    else:
        print("Aborting operations.")


@authentication_required
def unarchive(args: Namespace) -> None:
    patch_experiment(args, "archive", {"archived": False})
    print("Unarchived experiment {}".format(args.experiment_id))


def yes_or_no(prompt: str) -> bool:
    """Get a yes or no answer from the CLI user."""
    yes = ("y", "yes")
    no = ("n", "no")
    try:
        while True:
            choice = input(prompt + " [{}/{}]: ".format(yes[0], no[0])).strip().lower()
            if choice in yes:
                return True
            if choice in no:
                return False
            print(
                "Please respond with {} or {}".format(
                    "/".join("'{}'".format(y) for y in yes), "/".join("'{}'".format(n) for n in no)
                )
            )
    except KeyboardInterrupt:
        # Add a newline to mimic a return when sending normal inputs.
        print()
        return False


def none_or_int(string: str) -> Optional[int]:
    if string.lower().strip() in ("null", "none"):
        return None
    return int(string)


def experiment_id_completer(prefix: str, parsed_args: Namespace, **kwargs: Any) -> List[str]:
    params = {"filter": "all"}
    r = do_get(make_url(parsed_args.master, "experiment-list"), "list experiments", params=params)
    return [str(e["id"]) for e in r.json()]


def experiment_id_arg(help: str) -> Arg:
    return Arg("experiment_id", type=int, help=help, completer=experiment_id_completer)


def agent_id_completer(prefix: str, parsed_args: Namespace, **kwargs: Any) -> List[str]:
    r = do_get(make_url(parsed_args.master, "agents"), "list agents")
    return list(r.json().keys())


def agent_id_arg(nargs: Optional[str] = None) -> Arg:
    if nargs is None:
        return Arg("agent_id", help="agent ID", completer=agent_id_completer)
    else:
        return Arg("agent_id", help="agent ID", nargs=nargs, completer=agent_id_completer)


# fmt: off

experiment_args_description = \
    Cmd("e|xperiment", None, "manage experiments", [
        # Inspection commands.
        Cmd("list", list_experiments, "list experiments", [
            Arg("--all", "-a", action="store_true",
                help="show all experiments (including archived and other users')"),
            Arg("--csv", action="store_true", help="print as CSV")
        ], is_default=True),
        Cmd("config", config, "display experiment config", [
            experiment_id_arg("experiment ID"),
        ]),
        Cmd("describe", describe, "describe experiment", [
            Arg("experiment_id",
                help="comma-separated list of experiment IDs to describe"),
            Arg("--metrics", action="store_true", help="display full metrics"),
            Group(
                Arg("--csv", action="store_true", help="print as CSV"),
                Arg("--json", action="store_true", help="print as JSON"),
                Arg("--outdir", help="directory to save output")
            )
        ]),
        Cmd("download-model-def", download_model_def,
            "download model definition",
            [
                experiment_id_arg("experiment ID"),
                Arg("--output-dir", help="output directory", default="."),
            ]),
        Cmd("list-trials lt", list_trials, "list trials of experiment", [
            experiment_id_arg("experiment ID"),
            Arg("--csv", action="store_true", help="print as CSV"),
        ]),
        Cmd("list-checkpoints lc", list_checkpoints,
            "list checkpoints of experiment", [
                experiment_id_arg("experiment ID"),
                Arg("--best", type=int,
                    help="Return the best N checkpoints for this experiment. "
                    "If this flag is used, only checkpoints with an associated "
                    "validation metric will be considered."),
                Arg("-d", "--download-dir", type=str,
                    help="download the listed checkpoints to this directory. "
                    "The resources of each checkpoint will be saved in a "
                    "subdirectory labeled with the experiment ID, trial ID, "
                    "and step ID. This flag is only supported for experiments "
                    "configured to use S3 checkpoint storage."),
                Arg("--csv", action="store_true", help="print as CSV"),
            ]),

        # Create command.
        Cmd("create", create, "create experiment", [
            Arg("config_file", type=FileType("r"),
                help="experiment config file (.yaml)"),
            Arg("model_def", type=str,
                help="file or directory containing model definition"),
            Arg("-g", "--git", action="store_true",
                help="Associate git metadata with this experiment. This "
                "flag assumes that git is installed, a .git repository "
                "exists in the model definition directory, and that the "
                "git working tree of that repository is empty."),
            Arg("--package", action="append", default=[],
                help="Python package that is a model dependency. Packages "
                "should be provided as a Python source distribution or a "
                "Python wheel file that supports installation into a "
                "'linux_x68_64' and 'py3' environment."),
            Arg("-r", "--requirement", action="append", default=[], type=str,
                help="Include packages from the given requirements file. This "
                     "option can be used multiple times."),
            Arg("--template", type=str,
                help="name of template to apply to the experiment configuration"),
            Group(
                Arg("-f", "--follow-first-trial", action="store_true",
                    help="follow the logs of the first trial that is created"),
                Arg("--paused", action="store_true",
                    help="do not activate the experiment"),
                Arg("-t", "--test-mode", action="store_true",
                    help="Test the experiment configuration and model "
                    "definition by creating and scheduling a very small "
                    "experiment. This command will verify that a training "
                    "step runs successfully, a validation step runs "
                    "successfully, and that checkpoints can be saved. The "
                    "test experiment will be archived on creation.")
            )

        ]),

        # Lifecycle management commands.
        Cmd("activate", activate, "activate experiment", [
            experiment_id_arg("experiment ID to activate"),
        ]),
        Cmd("cancel", cancel, "cancel experiment", [
            experiment_id_arg("experiment ID to cancel"),
        ]),
        Cmd("pause", pause, "pause experiment", [
            experiment_id_arg("experiment ID to pause")
        ]),
        Cmd("archive", archive, "archive experiment", [
            experiment_id_arg("experiment ID to archive")
        ]),
        Cmd("unarchive", unarchive, "unarchive experiment", [
            experiment_id_arg("experiment ID to unarchive")
        ]),
        Cmd("kill", kill_experiment, "kill experiment", [
            Arg("experiment_id", help="experiment ID")
        ]),

        # Attribute setting commands.
        Cmd("label", None, "manage experiment labels", [
            Cmd("add", add_label, "add label", [
                experiment_id_arg("experiment ID"),
                Arg("label", help="label")
            ]),
            Cmd("remove", remove_label, "remove label", [
                experiment_id_arg("experiment ID"),
                Arg("label", help="label")
            ])
        ]),

        Cmd("set", None, "set experiment attributes", [
            Cmd("description", set_description, "set experiment description", [
                experiment_id_arg("experiment ID to modify"),
                Arg("description", help="experiment description")
            ]),
            Cmd("gc-policy", set_gc_policy,
                "set experiment GC policy and run GC",
                [
                    experiment_id_arg("experiment ID to modify"),
                    Arg("--save-experiment-best", type=int, required=True,
                        help="number of best checkpoints per experiment "
                        "to save"),
                    Arg("--save-trial-best", type=int, required=True,
                        help="number of best checkpoints per trial to save"),
                    Arg("--save-trial-latest", type=int, required=True,
                        help="number of latest checkpoints per trial to save"),
                    Arg("--yes", action="store_true", default=False,
                        help="automatically answer yes to prompts")
                ]),
            Cmd("max-slots", set_max_slots, "set `max_slots` of experiment", [
                experiment_id_arg("experiment ID to modify"),
                Arg("max_slots", type=none_or_int, help="max slots")
            ]),
            Cmd("weight", set_weight, "set `weight` of experiment", [
                experiment_id_arg("experiment ID to modify"),
                Arg("weight", type=float, help="weight")
            ])
        ])
    ])

args_description = [
    Arg("-u", "--user",
        help="Run as user",
        default=None),
    Arg("-m", "--master",
        help="master address",
        default=os.environ.get("PEDL_MASTER", os.environ.get("PEDL_MASTER_ADDR",
                                                             "localhost:8080"))),
    Arg("-v", "--version",
        action="version",
        version="%(prog)s " + pedl.__version__),

    experiment_args_description,

    Cmd("a|gent", None, "manage agents", [
        Cmd("list", list_agents, "list agents", [
            Arg("--csv", action="store_true", help="print as CSV"),
        ], is_default=True),
        Cmd("enable", enable_agent, "enable agent", [
            Group(
                agent_id_arg("?"),
                Arg("--all", action="store_true", help="enable all agents"),
            ),
        ]),
        Cmd("disable", disable_agent, "disable agent", [
            Group(
                agent_id_arg("?"),
                Arg("--all", action="store_true", help="disable all agents"),
            ),
        ]),
    ]),

    Cmd("s|lot", None, "manage slots", [
        Cmd("list", list_slots, "list slots in cluster", [
            Arg("--csv", action="store_true", help="print as CSV"),
        ], is_default=True),
        Cmd("enable", enable_slot, "enable slot on agent", [
            agent_id_arg(),
            Arg("slot_id", type=int, help="slot ID")
        ]),
        Cmd("disable", disable_slot, "disable slot on agent", [
            agent_id_arg(),
            Arg("slot_id", type=int, help="slot ID")
        ]),
    ]),

    Cmd("t|rial", None, "manage trials", [
        Cmd("describe", describe_trial, "describe trial", [
            Arg("trial_id", type=int, help="trial ID"),
            Arg("--metrics", action="store_true", help="display full metrics"),
            Group(
                Arg("--csv", action="store_true", help="print as CSV"),
                Arg("--json", action="store_true", help="print JSON")
            ),
        ]),
        Cmd("logs", logs, "fetch trial logs", [
            Arg("trial_id", type=int, help="trial ID"),
            Arg("-f", "--follow", action="store_true",
                help="follow the logs of a running trial, similar to tail -f"),
            Arg("--tail", type=int,
                help="number of lines to show, counting from the end "
                "of the log (default is all)")
        ]),
        Cmd("kill", kill_trial, "forcibly terminate a trial", [
            Arg("trial_id", help="trial ID")
        ])
    ]),

    Cmd("c|heckpoint", None, "manage checkpoints", [
        Cmd("download-s3", download_s3_checkpoint_cmd,
            "download checkpoint from S3",
            [
                Arg("trial_id", help="trial ID", type=int),
                Arg("step_id", help="step ID", type=int),
                Arg("output_dir", help="output directory", default=".")
            ])
    ]),

    Cmd("task", None, "manage tasks", [
        Cmd("list", list_tasks, "list tasks in cluster", [
            Arg("--csv", action="store_true", help="print as CSV"),
        ], is_default=True),
    ]),

    Cmd("preview-search", preview_search, "preview search", [
        Arg("config_file", type=FileType("r"),
            help="experiment config file (.yaml)")
    ]),
]  # type: List[object]

# fmt: on


def main(args: List[str] = sys.argv[1:]) -> None:
    # TODO(#1690): Refactor admin command(s) to a separate CLI tool.
    if "PEDL_ADMIN" in os.environ:
        experiment_args_description.subs.append(
            Cmd(
                "delete",
                delete_experiment,
                "delete experiment",
                [
                    Arg("experiment_id", help="delete experiment"),
                    Arg(
                        "--yes",
                        action="store_true",
                        default=False,
                        help="automatically answer yes to prompts",
                    ),
                ],
            )
        )

    parser = ArgumentParser(
        description="PEDL command-line client", formatter_class=ArgumentDefaultsHelpFormatter
    )
    try:
        add_args(
            parser,
            args_description
            + notebook_args_description
            + shell_args_description
            + template_args_description
            + tensorboard_args_description
            + remote_args_description
            + user_args_description,
        )
        argcomplete.autocomplete(parser)

        parsed_args = parser.parse_args(args)

        try:
            Authentication.initialize(
                parsed_args.user,
                make_url(parsed_args.master, "login"),
                make_url(parsed_args.master, "logout"),
                make_url(parsed_args.master, "users/me"),
            )
        except CorruptTokenCacheException:
            parser.exit(
                1,
                colored(
                    "Attempted to read a corrupted token cache.  The store has been deleted; "
                    "please try again.\n"
                ),
            )

        # Dispatch to subcommand handler.
        if hasattr(parsed_args, "func"):
            try:
                parsed_args.func(parsed_args)
            except UnauthenticatedException:
                print("Unauthenticated: Please use 'pedl user login <username>' to log in")
                parser.exit(1)
            except KeyboardInterrupt as e:
                raise e
            except Exception as e:
                if os.getenv("PEDL_DEBUG", "").lower() in ("true", "1", "yes"):
                    import traceback

                    traceback.print_exc()
                parser.exit(
                    1,
                    colored(
                        "Failed to {}: {} ({})\n".format(
                            parsed_args.func.__name__, e, type(e).__name__
                        ),
                        "red",
                    ),
                )
        else:
            parser.print_usage()
            parser.exit(2, "{}: no subcommand specified\n".format(parser.prog))
    except KeyboardInterrupt:
        parser.exit(3, colored("Interrupting...\n", "red"))
