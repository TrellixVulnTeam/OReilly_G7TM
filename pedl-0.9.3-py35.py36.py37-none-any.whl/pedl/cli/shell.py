import getpass
import os
import tempfile
from argparse import FileType, Namespace, ONE_OR_MORE
from typing import Any, Dict, List

from termcolor import colored

from pedl.check import check_eq

from . import api, render
from .authentication import Authentication, authentication_required
from .command import (
    Command,
    CommandDescription,
    CONFIG_DESC,
    CONTEXT_DESC,
    describe_command,
    launch_command,
    parse_config,
    render_event_stream,
    VOLUME_DESC,
)
from .declarative_argparse import Arg, Cmd


@authentication_required
def start_shell(args: Namespace) -> None:
    data = {}
    if args.passphrase:
        data["passphrase"] = getpass.getpass("Enter new passphrase: ")
    config = parse_config(args.config_file, None, args.config, args.volume)
    resp = launch_command(args.master, "shells", config, context_path=args.context, data=data)

    if args.detach:
        print(resp["id"])
        return

    command = None
    with api.ws(args.master, "shells/{}/events".format(resp["id"])) as ws:
        for msg in ws:
            if msg["container_started_event"]:
                command = render.unmarshal(Command, msg["snapshot"])
                break
            render_event_stream(msg)
    if command:
        _open_shell(command, args.ssh_opts)


@authentication_required
def open_shell(args: Namespace) -> None:
    shell = render.unmarshal(
        Command, api.get(args.master, "shells/{}".format(args.shell_id)).json()
    )
    check_eq(shell.state, "RUNNING", "Shell must be in a running state")
    _open_shell(shell, args.ssh_opts)


def _open_shell(shell: Command, additional_opts: str) -> None:
    with tempfile.NamedTemporaryFile("w") as fp:
        fp.write(shell.misc["privateKey"])
        fp.flush()
        host, port = shell.ports["shell-0"]["Host"].split(":")
        if host == "host.docker.internal":
            host = "localhost"
        os.system(
            "ssh -o StrictHostKeyChecking=no -o IdentitiesOnly=yes -i {} -p {} {} root@{}".format(
                fp.name, port, additional_opts, host
            )
        )
        print(colored("To reconnect, run: pedl shell open {}".format(shell.id), "green"))


@authentication_required
def tail_shell_logs(args: Namespace) -> None:
    url = "shells/{}/events?follow={}&tail={}".format(args.shell_id, args.follow, args.tail)
    with api.ws(args.master, url) as ws:
        for msg in ws:
            render_event_stream(msg)


@authentication_required
def list_shells(args: Namespace) -> None:
    if args.all:
        params = {}  # type: Dict[str, Any]
    else:
        params = {"user": Authentication.instance().get_session_user()}
    commands = [
        render.unmarshal(Command, command)
        for command in api.get(args.master, path="shells", params=params).json().values()
    ]

    if args.quiet:
        for command in commands:
            print(command.id)
        return

    render.render_objects(CommandDescription, [describe_command(command) for command in commands])


@authentication_required
def kill_shell(args: Namespace) -> None:
    for i, nid in enumerate(args.shell_id):
        try:
            api.delete(args.master, "shells/{}".format(nid))
            print(colored("Killed shell {}".format(nid), "green"))
        except api.APIException as e:
            if not args.force:
                for ignored in args.shell_id[i + 1 :]:
                    print("Cowardly not killing {}".format(ignored))
                raise e
            print(colored("Skipping: {} ({})".format(e, type(e).__name__), "red"))


# fmt: off

args_description = [
    Cmd("shell", None, "manage shells", [
        Cmd("list", list_shells, "list shells", [
            Arg("-q", "--quiet", action="store_true",
                help="Only display the ids"),
            Arg("--all", "-a", action="store_true",
                help="Show all shells (including other users')")
        ], is_default=True),
        Cmd("start", start_shell, "start a new shell", [
            Arg("--config-file", default=None, type=FileType("r"),
                help="command config file (.yaml)"),
            Arg("-v", "--volume", action="append", default=[],
                help=VOLUME_DESC),
            Arg("-c", "--context", default="", type=str, help=CONTEXT_DESC),
            Arg("-o", "--ssh-opts", default="", type=str,
                help="additional ssh options when connecting to the shell"),
            Arg("--config", action="append", default=[], help=CONFIG_DESC),
            Arg("-p", "--passphrase", action="store_true",
                help="passphrase to encrypt the shell private key"),
            Arg("-d", "--detach", action="store_true",
                help="run in the background and print the id")
        ]),
        Cmd("open", open_shell, "open an existing shell", [
            Arg("shell_id", help="shell ID"),
            Arg("-o", "--ssh-opts", default="", type=str,
                help="additional ssh options when connecting to the shell")
        ]),
        Cmd("logs", tail_shell_logs, "fetch shell logs", [
            Arg("shell_id", help="shell ID"),
            Arg("-f", "--follow", action="store_true",
                help="follow the logs of a shell, similar to tail -f"),
            Arg("--tail", type=int, default=10,
                help="number of lines to show, counting from the end "
                     "of the log")
        ]),
        Cmd("kill", kill_shell, "kill a shell", [
            Arg("shell_id", help="shell ID", nargs=ONE_OR_MORE),
            Arg("-f", "--force", action="store_true", help="ignore errors"),
        ]),
    ])
]  # type: List[Any]

# fmt: on
