import base64
import os
import sys
from typing import Any, Dict, Optional, Tuple, Union
from urllib.parse import urljoin, urlparse

import pathspec
import requests
import urllib3
from requests.models import Response
from termcolor import colored

from pedl.cli.authentication import Authentication
from pedl.constants import MAX_CONTEXT_SIZE

Context = Dict[str, bytes]


def _print_pedl_master_addr_help() -> None:
    print(
        colored(
            "Hint: Remember to set the PEDL_MASTER environment "
            "variable to the correct PEDL master IP or use the '-m' "
            "flag.",
            "yellow",
        )
    )


def abort_on_bad_response(r: Response, msg: str) -> None:
    try:
        print("{}: {}".format(msg, r.json()["message"]))
    except ValueError:
        print("Error: {}.\nResponse: {}".format(msg, r.text))
    except KeyError:
        print("Illegally formatted error message: {}".format(r.text))

    sys.exit(1)


def make_url(master_address: str, suffix: str) -> str:
    if not master_address.startswith("http"):
        master_address = "http://{}".format(master_address)
    parsed = urlparse(master_address)
    if not parsed.port:
        parsed = parsed._replace(netloc="{}:{}".format(parsed.netloc, 8080))
    return urljoin(parsed.geturl(), suffix)


def add_token_to_headers(headers: Dict[str, str]) -> None:
    token = Authentication.instance().get_session_token()

    headers["Authorization"] = "Bearer {}".format(token)


def do_get(
    url: str, action: str, params: Optional[Dict[str, Any]] = None, authenticated: bool = True
) -> Response:
    if params is None:
        params = {}

    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    try:
        r = requests.get(url, params=params, headers=headers)
    except Exception as e:
        if isinstance(
            e, (urllib3.exceptions.NewConnectionError, requests.exceptions.ConnectionError)
        ):
            _print_pedl_master_addr_help()
        print("Failed to {}: {}".format(action, e))
        sys.exit(1)

    if r.status_code != requests.codes.ok:
        abort_on_bad_response(r, "Failed to {}".format(action))

    return r


def do_delete(url: str, action: str, authenticated: bool = True) -> Response:
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    try:
        r = requests.delete(url, headers=headers)
    except requests.exceptions.RequestException as e:
        print("Failed to {}: {}".format(action, e))
        sys.exit(1)

    if r.status_code not in (requests.codes.ok, requests.codes.no_content):
        abort_on_bad_response(r, "Failed to {}".format(action))

    return r


def do_post(
    master_ip: str, url_suffix: str, body: Dict[str, Any], authenticated: bool = True
) -> Response:
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    try:
        return requests.post(make_url(master_ip, url_suffix), json=body, headers=headers)
    except requests.exceptions.RequestException as e:
        print("POST failed: {}".format(e))
        sys.exit(1)


def do_patch(
    master_ip: str,
    url_suffix: str,
    body: Dict[str, Any],
    headers: Optional[Dict[Any, Any]] = None,
    authenticated: bool = True,
) -> Response:
    if headers is None:
        headers = {}

    if authenticated:
        add_token_to_headers(headers)

    try:
        return requests.patch(make_url(master_ip, url_suffix), json=body, headers=headers)
    except requests.exceptions.RequestException as e:
        print("POST failed: {}".format(e))
        sys.exit(1)


def do_put(
    master_ip: str, url_suffix: str, body: Dict[str, Any], authenticated: bool = True
) -> Response:
    headers = {}  # type: Dict[str, str]
    if authenticated:
        add_token_to_headers(headers)

    try:
        return requests.put(make_url(master_ip, url_suffix), json=body, headers=headers)
    except requests.exceptions.RequestException as e:
        print("PUT failed: {}".format(e))
        sys.exit(1)


def read_context(
    context_path: str, use_parent_directory_in_name: bool = True, limit: int = MAX_CONTEXT_SIZE
) -> Tuple[Context, int]:
    """
    Given the path to a context file or directory, return a 2-tuple:
    (1) A dictionary of file paths to base64-encoded file contents.
    (2) The total pre-encoded byte size of the context file(s).

    A .pedlignore file in the context directory, if specified,
    indicates the wildcard paths that should be ignored.

    File paths are represented as relative paths (relative to the root context
    directory).
    """
    context_def = {}
    context_size = 0
    if os.path.isdir(context_path):
        if use_parent_directory_in_name:
            parent_directory_prefix = os.path.basename(os.path.abspath(context_path))
        else:
            parent_directory_prefix = ""

        spec = None
        pedlignore_path = os.path.join(context_path, ".pedlignore")
        if os.path.isfile(pedlignore_path):
            with open(pedlignore_path, "r") as pedlignore_file:
                spec = pathspec.PathSpec.from_lines(
                    pathspec.patterns.GitWildMatchPattern, pedlignore_file
                )

        msg = ""
        for root, _, files in os.walk(context_path):
            for file in files:
                relpath = os.path.relpath(os.path.join(root, file), context_path)
                # If the file is the .pedlignore file or matches one of the
                # paths specified in .pedlignore, then ignore it.
                if relpath == ".pedlignore":
                    continue
                if spec and spec.match_file(relpath):
                    continue

                name = os.path.join(parent_directory_prefix, relpath)
                filepath = os.path.join(root, file)
                with open(filepath, "rb") as f:
                    try:
                        content = f.read()
                    except OSError:
                        print("Error reading '{}', skipping this file.".format(filepath))
                        continue
                    context_size += len(content)
                    if context_size > limit:
                        print()
                        raise ValueError(
                            "Context directory '{}' exceeds the maximum allowed size {}.\n"
                            "Consider using a .pedlignore file to specify that certain files "
                            "or directories should be omitted from the model.".format(
                                context_path, sizeof_fmt(MAX_CONTEXT_SIZE)
                            )
                        )

                    context_def[name] = base64.b64encode(content)
                    print(" " * len(msg), end="\r")
                    msg = "Preparing files ({}) to send to master... {} and {} files".format(
                        context_path, sizeof_fmt(context_size), len(context_def)
                    )
                    print(msg, end="\r", flush=True)
        print()
    else:
        with open(context_path, "rb") as f:
            content = f.read()
            context_size += len(content)
            if context_size > limit:
                raise ValueError(
                    "Context file '{}' exceeds the maximum allowed size {}".format(
                        context_path, sizeof_fmt(MAX_CONTEXT_SIZE)
                    )
                )

        # Normalize file name; include only the name of the context def
        # file itself, for consistency with the directory case above.
        filename = os.path.basename(context_path)
        context_def[filename] = base64.b64encode(content)

    return context_def, context_size


def sizeof_fmt(val: Union[int, float]) -> str:
    val = float(val)
    for unit in ("", "K", "M", "G", "T", "P", "E", "Z"):
        if abs(val) < 1024.0:
            return "%3.1f%sB" % (val, unit)
        val /= 1024.0
    return "%.1f%sB" % (val, "Y")
