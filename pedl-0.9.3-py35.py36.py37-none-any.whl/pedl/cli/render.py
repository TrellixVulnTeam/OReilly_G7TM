import base64
import inspect

from typing import Any, Dict, Iterable

import tabulate
from ruamel import yaml


# Avoid reporting BrokenPipeError when piping `tabulate` output through
# a filter like `head`.
_FLUSH = False
_FORMAT = "presto"


def unmarshal(class_: Any, data: Dict[str, Any]) -> Any:
    spec = inspect.getfullargspec(class_)
    init_args = {}
    for arg in spec.args[1:]:
        init_args[arg] = data[arg]
    return class_(**init_args)


def render_objects(
    generic: Any, values: Iterable[Any], default_value: str = "N/A", table_fmt: str = _FORMAT
) -> None:
    keys = inspect.getfullargspec(generic).args[1:]
    headers = [key.replace("_", " ").title() for key in keys]
    if len(headers) == 0:
        raise ValueError("must have at least one header to display")

    def _coerce(r: Any) -> Iterable[Any]:
        for key in keys:
            value = getattr(r, key)
            if value is None:
                yield default_value
            else:
                yield value

    values = [_coerce(renderable) for renderable in values]
    print(tabulate.tabulate(values, headers, tablefmt=table_fmt), flush=_FLUSH)


def render_dicts(
    generic: Any,
    values: Iterable[Dict[str, Any]],
    default_value: str = "N/A",
    table_fmt: str = _FORMAT,
) -> None:
    objects = [unmarshal(generic, value) for value in values]
    render_objects(generic, objects, default_value=default_value, table_fmt=table_fmt)


def format_dict_by_yaml(source: str) -> str:
    s = yaml.safe_dump(yaml.safe_load(base64.b64decode(source)), default_flow_style=False)
    if isinstance(s, str):
        return s
    return ""
