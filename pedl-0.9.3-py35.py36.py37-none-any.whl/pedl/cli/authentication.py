import getpass
import hashlib
import json
import os
import platform
import sys
import typing

from argparse import Namespace
from functools import wraps
from typing import Any, Callable, Dict, NamedTuple, Optional, Tuple

import requests


DEFAULT_PEDL_USER = "pedl"
DEFAULT_PEDL_PASSWORD = ""

Credentials = NamedTuple("Credentials", [("username", str), ("password", str)])

PASSWORD_SALT = "GubPEmmotfiK9TMD6Zdw"


def salt_and_hash(password: str) -> str:
    if password:
        return hashlib.sha512((PASSWORD_SALT + password).encode()).hexdigest()
    else:
        return password


class UnauthenticatedException(Exception):
    pass


class AuthenticationFailedException(Exception):
    def __init__(self, username: str, response: requests.Response, msg: Optional[str] = None):
        super().__init__(msg)
        self.username = username
        self.response = response


class CorruptTokenCacheException(Exception):
    pass


class LogoutFailedException(Exception):
    def __init__(self, response: requests.Response, msg: Optional[str] = None):
        super().__init__(msg)
        self.response = response


def authentication_optional(func: Callable[[Namespace], Any]) -> Callable[[Namespace], Any]:
    @wraps(func)
    def f(namespace: Namespace) -> Any:
        try:
            Authentication.instance().initialize_session(try_reauth=False)
        except UnauthenticatedException:
            pass

        return func(namespace)

    return f


def authentication_required(func: Callable[[Namespace], Any]) -> Callable[[Namespace], Any]:
    @wraps(func)
    def f(namespace: Namespace) -> Any:
        try:
            Authentication.instance().initialize_session(try_reauth=True)
        except AuthenticationFailedException as e:
            if e.username == DEFAULT_PEDL_USER:
                print("Unauthenticated.")
            else:
                print("Authentication failed for user '{}'.".format(e.username))
            sys.exit(1)
        return func(namespace)

    return f


class _Session:
    def __init__(self, username: str, token: str):
        self.username = username
        self.token = token


class Authentication:
    _instance = None

    @classmethod
    def initialize(
        cls,
        session_user: Optional[str],
        login_endpoint: str,
        logout_endpoint: str,
        get_me_endpoint: str,
    ) -> None:
        if cls._instance is not None:
            return

        cls._instance = _Authentication(
            session_user, login_endpoint, logout_endpoint, get_me_endpoint
        )

    @classmethod
    def instance(cls) -> "_Authentication":
        if cls._instance is None:
            raise Exception("Must call initialize() method before attempting to get an instance")
        return cls._instance


class _Authentication:
    def __init__(
        self,
        requested_user: Optional[str],
        login_endpoint: str,
        logout_endpoint: str,
        get_me_endpoint: str,
    ):
        self.token_store = TokenStore()
        self.requested_user = requested_user
        self.login_endpoint = login_endpoint
        self.logout_endpoint = logout_endpoint
        self.get_me_endpoint = get_me_endpoint

        self.session = None  # type: Optional[_Session]

    def initialize_session(self, try_reauth: bool) -> None:
        session_user = self._determine_session_user(self.requested_user)

        token, is_new = self._get_token(session_user, try_reauth)

        if is_new:
            self.token_store.set_token(session_user, token)

            # If the user wasn't set with the '-u' option and the session_user
            # is the default user, tag them as being the active user.
            if self.requested_user is None and session_user == DEFAULT_PEDL_USER:
                self.token_store.set_active(session_user, True)

        self.session = _Session(session_user, token)

    def is_user_active(self, username: str) -> bool:
        return self.token_store.get_active_user() == username

    def _get_token(self, user: str, try_reauth: bool) -> Tuple[str, bool]:
        token = self.token_store.get_token(user)
        # Check that the token is valid.
        is_new = False
        if token is not None and not self._is_token_valid(token):
            self.token_store.drop_user(user)
            token = None

        if token is None:
            if try_reauth:
                token = self._do_login(self._get_credentials(user))
                is_new = True
            else:
                raise UnauthenticatedException()

        return token, is_new

    @staticmethod
    def _get_credentials(username: str) -> Credentials:
        if username == DEFAULT_PEDL_USER:
            return Credentials(username, DEFAULT_PEDL_PASSWORD)

        if username is None:
            username = input("Username: ")

        password = salt_and_hash(getpass.getpass("Password for user '{}': ".format(username)))

        return Credentials(username, password)

    def _determine_session_user(self, session_user: Optional[str]) -> str:
        if session_user is not None:
            return session_user

        session_user = self.token_store.get_active_user()
        if session_user is not None:
            return session_user

        return DEFAULT_PEDL_USER

    def _do_login(self, credentials: Credentials) -> str:
        username, password = credentials
        response = requests.post(
            self.login_endpoint, json={"username": username, "password": password}
        )

        if response.status_code != 200:
            raise AuthenticationFailedException(username, response)

        try:
            token = typing.cast(str, response.json()["token"])
        except KeyError:
            raise AuthenticationFailedException(
                username, response, "Failed to parse successful login response"
            )
        return token

    def log_in_user(self, credentials: Credentials, active: bool) -> None:
        token = self._do_login(credentials)
        self.token_store.set_token(credentials.username, token)
        self.token_store.set_active(credentials.username, active)

    def log_out_session(self) -> None:
        # If we have no session, assume there is nothing to do.
        if self.session is None:
            return

        response = requests.get(
            self.logout_endpoint,
            headers={"Authorization": "Bearer {}".format(self.get_session_token())},
        )
        if response.status_code not in {200, 401}:
            raise LogoutFailedException(response)

        self.token_store.drop_user(self.get_session_user())

    def _is_token_valid(self, token: str) -> bool:
        """
        Find out whether the given token is valid by attempting to use it
        on the "/users/me" endpoint.
        """
        headers = {"Authorization": "Bearer {}".format(token)}
        try:
            r = requests.get(self.get_me_endpoint, headers=headers)
        except Exception as e:
            print("Error while verifying token: {}", format(e))
            return False

        return r.status_code == 200

    def get_session_user(self) -> str:
        """
        Returns the session user for the current session.  If there is no active session, then
        an UnauthenticatedException will be raised.
        """
        if self.session is None:
            raise UnauthenticatedException()
        return self.session.username

    def get_session_token(self) -> str:
        """
        Returns the authentication token for the session user.
        """
        if self.session is None:
            raise UnauthenticatedException()
        return self.session.token


class TokenStore:
    def __init__(self) -> None:
        try:
            store = self._load_store()
        except CorruptTokenCacheException as e:
            self.delete_token_cache()
            raise e
        self._tokens = store.get("tokens", {})
        self._active_user = typing.cast(Optional[str], store.get("active_user", None))

    @classmethod
    def delete_token_cache(cls) -> None:
        path = cls._get_token_cache_path()
        if os.path.exists(path):
            os.remove(path)

    @staticmethod
    def _get_token_cache_path() -> str:
        return os.path.join(TokenStore._get_config_path(), "auth.json")

    @staticmethod
    def _get_config_path() -> str:
        system = platform.system()
        if "Linux" in system:
            config_path = os.getenv("XDG_CONFIG_HOME")
        elif "Darwin" in system:
            config_path = os.path.expanduser("~/Library/Application Support/")
        elif "Windows" in system:
            config_path = os.getenv("LOCALAPPDATA")
        else:
            config_path = None

        if config_path is None:
            config_path = os.path.expanduser("~/.config")

        return os.path.join(config_path, "pedl")

    def get_active_user(self) -> Optional[str]:
        """
        Gets the active user from the token cache.

        Returns: Optional[str] which is either the user if there is an active user or None
        otherwise.
        """
        return self._active_user

    @classmethod
    def _load_store(cls) -> Dict[str, Any]:
        path = cls._get_token_cache_path()
        if os.path.exists(path):
            with open(path) as fin:
                try:
                    store = typing.cast(Dict[str, Any], json.loads(fin.read()))

                    if not cls._validate_token_store(store):
                        raise CorruptTokenCacheException

                    return store

                except json.JSONDecodeError:
                    raise CorruptTokenCacheException
        else:
            return {}

    @staticmethod
    def _validate_token_store(store: Dict[str, Any]) -> bool:
        """
        _validate_token_store makes sure that the data in the token store makes sense
        (in the sense that the key/value types are what they should be).

        """
        if "active_user" in store:
            active_user = typing.cast(str, store["active_user"])
            if not isinstance(active_user, str):
                return False

        if "tokens" in store:
            tokens = typing.cast(Dict[str, str], store["tokens"])
            if not isinstance(tokens, dict):
                return False
            for k, v in tokens.items():
                if not isinstance(k, str):
                    return False
                if not isinstance(v, str):
                    return False
        return True

    @staticmethod
    def _create_pedl_path_if_necessary() -> None:
        path = TokenStore._get_config_path()
        if not os.path.exists(path):
            os.makedirs(path)
            os.chmod(path, 0o700)

    def get_token(self, user: str) -> Optional[str]:
        if user in self._tokens:
            return typing.cast(str, self._tokens[user])
        return None

    def _write_store(self) -> None:
        self._create_pedl_path_if_necessary()
        cache_path = self._get_token_cache_path()
        store = {}
        if self._tokens is not None and len(self._tokens):
            store["tokens"] = self._tokens

        if self._active_user is not None:
            store["active_user"] = self._active_user

        with open(cache_path, "w") as file_out:
            json.dump(store, file_out, indent=4, sort_keys=True)

    def drop_user(self, username: str) -> None:
        if username not in self._tokens:
            raise UnauthenticatedException()

        del self._tokens[username]
        if self.get_active_user() == username:
            self._active_user = None
        self._write_store()

    def set_token(self, username: str, token: str) -> None:
        self._tokens[username] = token
        self._write_store()

    def set_active(self, username: str, active: bool) -> None:
        if username not in self._tokens:
            raise UnauthenticatedException()

        self._active_user = username if active else None
        self._write_store()
