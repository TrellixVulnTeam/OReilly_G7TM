import urllib.parse

from argparse import FileType, Namespace, ONE_OR_MORE, REMAINDER
from typing import Any, Dict, List

from termcolor import colored

from . import api, render
from .authentication import Authentication, authentication_required
from .command import (
    Command,
    CommandDescription,
    CONFIG_DESC,
    CONTEXT_DESC,
    describe_command,
    launch_command,
    parse_config,
    render_event_stream,
    VOLUME_DESC,
)
from .declarative_argparse import Arg, Cmd


@authentication_required
def run_command(args: Namespace) -> None:
    config = parse_config(args.config_file, args.entrypoint, args.config, args.volume)
    resp = launch_command(args.master, "commands", config, context_path=args.context)

    url = "commands/{}/events".format(resp["id"])

    with api.ws(args.master, url) as ws:
        for msg in ws:
            render_event_stream(msg)


@authentication_required
def list_commands(args: Namespace) -> None:
    if args.all:
        params = {}  # type: Dict[str, Any]
    else:
        params = {"user": Authentication.instance().get_session_user()}
    commands = [
        render.unmarshal(Command, command)
        for command in api.get(args.master, path="commands", params=params).json().values()
    ]

    if args.quiet:
        for command in commands:
            print(command.id)
        return

    render.render_objects(CommandDescription, [describe_command(command) for command in commands])


@authentication_required
def tail_command_logs(args: Namespace) -> None:
    token = Authentication.instance().get_session_token()
    params = {"follow": args.follow, "tail": args.tail, "_auth": token}

    url = "commands/{}/events?{}".format(args.command_id, urllib.parse.urlencode(params))

    with api.ws(args.master, url) as ws:
        for msg in ws:
            render_event_stream(msg)


@authentication_required
def kill_command(args: Namespace) -> None:
    for i, cid in enumerate(args.command_id):
        try:
            api.delete(args.master, "commands/{}".format(cid))
            print(colored("Killed command {}".format(cid), "green"))
        except api.APIException as e:
            if not args.force:
                for ignored in args.command_id[i + 1 :]:
                    print("Cowardly not killing {}".format(ignored))
                raise e
            print(colored("Skipping: {} ({})".format(e, type(e).__name__), "red"))


# fmt: off

args_description = [
    Cmd("command cmd", None, "manage commands", [
        Cmd("list", list_commands, "list commands", [
            Arg("-q", "--quiet", action="store_true",
                help="Only display the ids"),
            Arg("--all", "-a", action="store_true",
                help="Show all commands (including other users')"),
        ], is_default=True),
        Cmd("run", run_command, "create command", [
            Arg("entrypoint", type=str, nargs=REMAINDER,
                help="entrypoint command and arguments to execute"),
            Arg("--config-file", default=None, type=FileType("r"),
                help="command config file (.yaml)"),
            Arg("-v", "--volume", action="append", default=[],
                help=VOLUME_DESC),
            Arg("-c", "--context", default="", type=str, help=CONTEXT_DESC),
            Arg("--config", action="append", default=[], help=CONFIG_DESC)
        ]),
        Cmd("logs", tail_command_logs, "fetch command logs", [
            Arg("command_id", help="command ID"),
            Arg("-f", "--follow", action="store_true",
                help="follow the logs of a command, similar to tail -f"),
            Arg("--tail", type=int, default=10,
                help="number of lines to show, counting from the end "
                     "of the log")
        ]),
        Cmd("kill", kill_command, "forcibly terminate a command", [
            Arg("command_id", help="command ID", nargs=ONE_OR_MORE),
            Arg("-f", "--force", action="store_true", help="ignore errors"),
        ]),
    ])
]  # type: List[Any]

# fmt: on
