import logging
import os
import tempfile
from typing import Optional

import boto3

import pedl.util
from pedl.storage.base import Storable, StorageManager, StorageMetadata


class S3StorageManager(StorageManager):
    """
    Store and load checkpoints from S3.
    """

    def __init__(
        self,
        bucket: str,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        temp_dir: Optional[str] = None,
    ) -> None:
        super().__init__(temp_dir if temp_dir is not None else tempfile.gettempdir())
        self.bucket = bucket
        self.client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
        )

    def store(self, store_data: Storable, storage_id: str = "") -> StorageMetadata:
        metadata = super().store(store_data, storage_id)

        logging.info("Uploading checkpoint {} to s3".format(metadata.storage_id))

        storage_dir = os.path.join(self._base_path, metadata.storage_id)
        self.upload(metadata, storage_dir)
        # Call to super's delete to remove the temporary directory
        super().delete(metadata)
        return metadata

    def restore(self, checkpoint: Storable, metadata: StorageMetadata) -> None:
        logging.info("Downloading checkpoint {} from s3".format(metadata.storage_id))

        storage_dir = os.path.join(self._base_path, metadata.storage_id)
        os.makedirs(storage_dir, exist_ok=True)

        self.download(metadata, storage_dir)
        # TODO: Check that all metadata resources are downloaded

        super().restore(checkpoint, metadata)
        # Call to super's delete to remove the temporary directory
        super().delete(metadata)

    def upload(self, metadata: StorageMetadata, storage_dir: str) -> None:
        for rel_path in metadata.resources:
            key_name = "{}/{}".format(metadata.storage_id, rel_path)

            url = "s3://{}/{}".format(self.bucket, key_name)
            logging.debug("Uploading {} to {}".format(rel_path, url))

            if rel_path.endswith("/"):
                # Create empty S3 keys for each subdirectory.
                self.client.put_object(Bucket=self.bucket, Key=key_name, Body=b"")
            else:
                abs_path = os.path.join(storage_dir, rel_path)
                self.client.upload_file(abs_path, self.bucket, key_name)

    def download(self, metadata: StorageMetadata, storage_dir: str) -> None:
        for rel_path in metadata.resources:
            # Ignore keys that denote directories.
            if rel_path.endswith("/"):
                continue

            key_name = "{}/{}".format(metadata.storage_id, rel_path)
            url = "s3://{}/{}".format(self.bucket, key_name)
            logging.debug("Downloading {} from {}".format(url, rel_path))

            abs_path = os.path.join(storage_dir, rel_path)
            os.makedirs(os.path.dirname(abs_path), exist_ok=True)
            self.client.download_file(self.bucket, key_name, abs_path)

    def delete(self, metadata: StorageMetadata) -> None:
        logging.info("Deleting checkpoint {} from s3".format(metadata.storage_id))

        objects = [
            {"Key": "{}/{}".format(metadata.storage_id, rel_path)}
            for rel_path in metadata.resources
        ]

        # S3 delete_objects has a limit of 1000 objects.
        for chunk in pedl.util.chunks(objects, 1000):
            logging.debug("Deleting {} objects from S3".format(len(chunk)))
            self.client.delete_objects(Bucket=self.bucket, Delete={"Objects": chunk})
