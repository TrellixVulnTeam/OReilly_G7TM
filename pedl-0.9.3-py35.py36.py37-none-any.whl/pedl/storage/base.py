import os
import shutil
import uuid
from abc import ABCMeta, abstractmethod
from typing import Any, Dict, Iterable, Optional

from pedl.check import check_gt, check_not_eq, check_true, check_type


class StorageMetadata:
    def __init__(
        self, storage_id: str, resources: Iterable[str], labels: Optional[Dict[str, str]] = None
    ) -> None:
        check_gt(len(storage_id), 0, "Invalid storage ID")
        if labels is None:
            labels = {}
        self.storage_id = storage_id
        self.resources = resources
        self.labels = labels

    def __json__(self) -> Dict[str, Any]:
        return {"uuid": self.storage_id, "resources": self.resources, "labels": self.labels}

    def __str__(self) -> str:
        return "<storage {}, labels {}>".format(self.storage_id, self.labels)

    def __repr__(self) -> str:
        return "<storage {}, labels {}, resources {}>".format(
            self.storage_id, self.labels, self.resources
        )

    @staticmethod
    def from_json(record: Dict[str, Any]) -> "StorageMetadata":
        check_not_eq(record["uuid"], None, "Storage ID is undefined")
        check_not_eq(record["resources"], None, "Resources are undefined")
        return StorageMetadata(record["uuid"], record["resources"], record.get("labels"))


class Storable(metaclass=ABCMeta):
    """
    An interface for objects (like trials) that support being stored.
    This interface can be passed to a `CheckpointManager` to be saved to or
    loaded from persistent storage.
    """

    @abstractmethod
    def save(self, storage_dir: str) -> None:
        """
        Persist the object to the storage directory. The storage
        directory is not created prior to saving the storage.
        """
        raise NotImplementedError()

    @abstractmethod
    def load(self, storage_dir: str) -> None:
        """
        Load the object from the storage directory.
        """
        raise NotImplementedError()


class StorageManager:
    """
    Abstract base class for storage managers. Storage managers need to
    support three operations: creating, loading, and deleting storages.

    Configuration for storage managers is represented as a dictionary of key
    value pairs. The primary key in the dictionary is the `type` defining
    which storage backend to use. Additional keys may be required to
    instantiate some implementations of the storage manager.
    """

    def __init__(self, base_path: str) -> None:
        check_type(base_path, str)
        check_gt(len(base_path), 0)
        self._base_path = base_path

    def store(self, store_data: Storable, storage_id: str = "") -> StorageMetadata:
        """
        Save the object to the backing persistent storage.
        """
        if storage_id == "":
            storage_id = str(uuid.uuid4())

        os.makedirs(self._base_path, exist_ok=True)

        storage_dir = os.path.join(self._base_path, storage_id)

        store_data.save(storage_dir)
        check_true(os.path.exists(storage_dir), "Checkpoint did not create a storage directory")

        return StorageMetadata(storage_id, StorageManager._list_directory(storage_dir))

    def restore(self, storage_data: Storable, metadata: StorageMetadata) -> None:
        """
        Load the object from the backing persistent storage.
        """
        storage_dir = os.path.join(self._base_path, metadata.storage_id)

        check_true(
            os.path.exists(storage_dir),
            "Storage directory does not exist: {}. Please verify "
            "that you are using the correct configuration value for "
            "checkpoint_storage.host_path and "
            "tensorboard_storage.host_path.".format(storage_dir),
        )
        check_true(
            os.path.isdir(storage_dir), "Checkpoint path is not a directory: {}".format(storage_dir)
        )

        storage_data.load(storage_dir)

    def delete(self, metadata: StorageMetadata) -> None:
        """
        Delete the stored data from persistent storage.
        """
        storage_dir = os.path.join(self._base_path, metadata.storage_id)

        check_true(
            os.path.exists(storage_dir), "Storage directory does not exist: {}".format(storage_dir)
        )
        check_true(
            os.path.isdir(storage_dir), "Storage path is not a directory: {}".format(storage_dir)
        )

        shutil.rmtree(storage_dir)

    @staticmethod
    def _list_directory(root: str) -> Iterable[str]:
        """
        Returns a list of all the files and subdirectories in the directory
        `root`. Directories are signified by a trailing "/". Returned path
        names are relative to `root`.
        """
        check_true(os.path.isdir(root), "{} must be an extant directory".format(root))
        result = {}
        for cur_path, sub_dirs, files in os.walk(root):
            for d in sub_dirs:
                abs_path = os.path.join(cur_path, d)
                rel_path = os.path.relpath(abs_path, root) + "/"
                result[rel_path] = 0

            for f in files:
                abs_path = os.path.join(cur_path, f)
                rel_path = os.path.relpath(abs_path, root)
                result[rel_path] = os.path.getsize(abs_path)

        return result
