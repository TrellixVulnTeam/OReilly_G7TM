import logging
import os
import tempfile
from typing import Optional

from hdfs.client import Client, InsecureClient

from pedl.check import check_none
from pedl.storage.base import Storable, StorageManager, StorageMetadata


class HDFSStorageManager(StorageManager):
    """
    Store and load storages from HDFS.
    """

    def __init__(
        self,
        hdfs_url: str,
        hdfs_path: str,
        kerberos: Optional[bool] = False,
        user: Optional[str] = None,
        temp_dir: Optional[str] = None,
    ) -> None:
        super().__init__(temp_dir if temp_dir is not None else tempfile.gettempdir())

        self.hdfs_url = hdfs_url
        self.hdfs_path = hdfs_path
        self.kerberos = kerberos
        self.user = user

        # We lazy-load the client so that callers that just instanciate
        # a StorageManager don't need the Kerberos dependencies.
        self.client = None  # type: Optional[Client]

    def _load_client(self) -> Client:
        check_none(self.client)

        if self.kerberos is True:
            check_none(self.user, "Cannot specify both 'user' and 'kerberos'")
            from hdfs.ext.kerberos import KerberosClient

            return KerberosClient(self.hdfs_url, root=self.hdfs_path)
        else:
            return InsecureClient(self.hdfs_url, root=self.hdfs_path, user=self.user)

    def store(self, store_data: Storable, storage_id: str = "") -> StorageMetadata:
        if self.client is None:
            self.client = self._load_client()

        metadata = super().store(store_data, storage_id)

        logging.info("Uploading storage {} to HDFS".format(metadata.storage_id))

        storage_dir = os.path.join(self._base_path, metadata.storage_id)
        result = self.client.upload(metadata.storage_id, storage_dir)

        logging.info("Uploaded storage {} to HDFS path {}".format(metadata.storage_id, result))

        # Call to super's delete to remove the temporary directory
        super().delete(metadata)
        return metadata

    def restore(self, storage_data: Storable, metadata: StorageMetadata) -> None:
        if self.client is None:
            self.client = self._load_client()

        logging.info("Downloading storage {} from HDFS".format(metadata.storage_id))

        self.client.download(metadata.storage_id, self._base_path, overwrite=True)

        super().restore(storage_data, metadata)

        # Call to super's delete to remove the temporary directory
        super().delete(metadata)

    def delete(self, metadata: StorageMetadata) -> None:
        if self.client is None:
            self.client = self._load_client()

        logging.info("Deleting storage {} from HDFS".format(metadata.storage_id))
        self.client.delete(metadata.storage_id, recursive=True)
