import copy
import hashlib
import logging
import tarfile
import tempfile
from io import BytesIO
from typing import Any, Awaitable, Callable, Dict, IO, List, Optional

import aiodocker
import aiodocker.utils
from aiodocker.exceptions import DockerError
from packaging import version

import pedl
from pedl.check import check_eq, check_in
from pedl.constants import TASK_ENV_REPO
from pedl.env import Environment, RuntimeEnv, VersionNone


_IMAGE_MANAGED_LABEL_KEY = "ai.determined.pedl-image-type"
_IMAGE_MANAGED_LABEL_VALUE = "runtime-image"


LogHandler = Callable[[Dict[str, Any], str], Awaitable[None]]


def mktar_from_dockerfile(dockerfile: bytes, host_paths: List[str]) -> IO:
    """
    Create a zipped tar archive from a Dockerfile, similar to
    aiodocker.utils.mktar_from_dockerfile. In addition, add any paths
    on the host to the context of the docker file.
    """

    f = tempfile.NamedTemporaryFile()
    t = tarfile.open(mode="w:gz", fileobj=f)

    fileobj = BytesIO(dockerfile)
    dfinfo = tarfile.TarInfo("Dockerfile")
    dfinfo.size = len(fileobj.getvalue())
    fileobj.seek(0)
    t.addfile(dfinfo, fileobj)

    for p in host_paths:
        t.add(p)

    t.close()
    f.seek(0)
    return f


def _generate_dockerfile(image_name: str, build_directives: List[str]) -> str:
    """
    Generate a dockerfile compatible string from an image and list of
    build_directives.
    """
    return "\n".join(["FROM {}".format(image_name)] + build_directives)


def generate_prebuilt_name(env: Dict[str, Any], image_type: RuntimeEnv, git_commit: str) -> str:
    """
    Generate the hash used for a prebuilt image. The hash is determined by the fields of the
    environment, the git commit, and whether the image is CPU or GPU.
    """
    h = hashlib.sha256()

    h.update(git_commit.encode("utf8"))

    for key in ("os", "cuda", "python", "tensorflow", "pytorch", "keras", "debug"):
        h.update(env[key].encode("utf8"))

    h.update(str(env["internal"]["inject_harness"]).encode("utf8"))

    # Also important: image type (which affects some details of the constructed image).
    h.update(str(image_type).encode("utf8"))

    return "{}:{}".format(TASK_ENV_REPO, h.hexdigest())


class ImageBuildError(Exception):
    """
    An error has occurred while trying to build an image. Provides both the
    error code and message of the failure that occurred during the build time.
    """

    def __init__(self, error_code: Optional[int], msg: Optional[str]) -> None:
        super().__init__(
            "Failed with error code {}{}".format(
                error_code if error_code is not None else "unknown",
                ": {}".format(msg) if msg is not None else "",
            )
        )
        self.error_code = error_code


class EnvironmentBuilder:
    """
    Constructs docker configuration for an Environment.
    """

    def __init__(
        self, env: Environment, image_type: RuntimeEnv, container_config: Optional[Dict[str, Any]]
    ) -> None:
        self.env = env
        self.image_type = image_type
        self.base_image = ""
        self.directives = []  # type: List[str]
        self.host_paths = []  # type: List[str]

        self.config = {}  # type: Dict[str, Any]
        if container_config:
            self.config = copy.deepcopy(container_config)

        self._initialize()

    def _initialize(self) -> None:
        self._base_image()
        self._python_directives()
        self._tensorflow_directives()
        self._keras_directives()
        self._pytorch_directives()
        self._debug_directives()
        self._inject_harness()

    def _base_image(self) -> None:
        """
        Determine base image custom_image or from OS and CUDA version tags.
        """
        if self.env.custom_image:
            self.base_image = self.env.custom_image
            logging.info(
                "Building runtime image from custom base image "
                "{} on PEDL version {}".format(self.base_image, pedl.__version__)
            )
            return

        os_cuda = (self.env.os, self.env.cuda)
        os_cuda_version_to_base_images = {
            ("ubuntu16.04", "9.0"): "nvidia/cuda:9.0-cudnn7-runtime-ubuntu16.04",
            ("ubuntu16.04", "10.0"): "nvidia/cuda:10.0-cudnn7-runtime-ubuntu16.04",
            ("ubuntu16.04", VersionNone): "ubuntu:16.04",
        }
        check_in(
            os_cuda,
            os_cuda_version_to_base_images,
            "Did not recognize (OS, CUDA) version tags: {}".format(os_cuda),
        )
        self.base_image = os_cuda_version_to_base_images[os_cuda]

        # NVIDIA APT repositories have been flaky in the past. Remove them so
        # that Docker builds don't hang on `apt-get update`.
        self.directives.append("RUN rm -f /etc/apt/sources.list.d/*")

    def _python_directives(self) -> None:
        if self.env.python == VersionNone:
            return
        # Except in the case of custom images, only python version 3.6.9 is
        # supported. Install the required libraries along with Python 3.6 and
        # pip.
        check_eq(self.env.python, "3.6.9")

        apt_libraries = [
            "build-essential",
            "ca-certificates",
            "curl",
            "libkrb5-dev",
            "libssl-dev",
            "git",
            "krb5-user",
            "python3.6=3.6.9-1+xenial1",
            "python3.6-dev=3.6.9-1+xenial1",
        ]
        self.directives.append(
            "RUN "
            + " && ".join(
                [
                    # Install Python 3.6.9
                    "apt-get update",
                    "apt-get -y --no-install-recommends install software-properties-common",
                    "add-apt-repository ppa:deadsnakes/ppa",
                    "apt-get update",
                    "DEBIAN_FRONTEND=noninteractive apt-get install -y {}".format(
                        " ".join(apt_libraries)
                    ),
                    "apt-get clean",
                    # Install pip configured to Python 3.6.9
                    "curl -O https://bootstrap.pypa.io/get-pip.py",
                    "python3.6 get-pip.py",
                    "rm get-pip.py",
                    # Add symlinks so that "python" and "python3" are both
                    # valid alternatives for executing Python scripts.
                    "ln -sf /usr/bin/python3.6 /usr/bin/python3",
                    "ln -sf /usr/bin/python3.6 /usr/bin/python",
                ]
            )
        )

        # Ensure that Python outputs everything from the application rather
        # than buffering it.
        self.directives.append("ENV PYTHONUNBUFFERED 1")
        # Cause Python to print a stack trace when it receives a SIGSEGV,
        # SIGFPE, SIGABRT, SIGBUS or SIGILL signal.
        self.directives.append("ENV PYTHONFAULTHANDLER 1")
        self.directives.append("ENV PYTHONHASHSEED 0")

    def _tensorflow_directives(self) -> None:
        if self.env.tensorflow == VersionNone:
            return

        package = "tensorflow"
        if self.image_type is RuntimeEnv.GPU:
            package = "tensorflow-gpu"

        self.directives.append("RUN pip install {}=={}".format(package, self.env.tensorflow))

        if version.parse(self.env.tensorflow) >= version.parse("1.14.0"):
            self.host_paths.append("/patches")
            self.directives.append("COPY patches/. /patches/.")
            self.directives.append(
                "RUN cd /usr/local/lib/python3.6/dist-packages/tensorflow && "
                "find /patches -name 'tf1.14*' -print0 | xargs -0 -n 1 patch -p1 -i"
            )

    def _pytorch_directives(self) -> None:
        if self.env.pytorch == VersionNone:
            return

        if self.image_type is RuntimeEnv.CPU:
            processor_type = "cpu"
        else:
            try:
                processor_type = {"9.0": "cu90", "10.0": "cu100"}[self.env.cuda]
            except KeyError:
                raise ValueError("Invalid CUDA version for PyTorch: {}".format(self.env.cuda))

        base_url = "https://download.pytorch.org/whl/{}".format(processor_type)
        self.directives.append(
            "RUN pip install {}/torch-{}-cp36-cp36m-linux_x86_64.whl".format(
                base_url, self.env.pytorch
            )
        )
        self.directives.append("RUN pip install torchvision==0.2.2.post3")

    def _keras_directives(self) -> None:
        if self.env.keras == VersionNone:
            return

        self.directives.append("RUN pip install keras=={}".format(self.env.keras))

    def _debug_directives(self) -> None:
        if self.env.debug == VersionNone:
            return

        # Insert our own management layer via the docker entrypoint.
        check_eq(self.env.debug, "0.1.0")
        caps = self.config.get("HostConfig", {}).get("CapAdd", [])
        if "SYS_PTRACE" not in caps:
            caps += ["SYS_PTRACE"]
            self.config.setdefault("HostConfig", {})["CapAdd"] = caps
        self.config["EntryPoint"] = ["/profiler/profiler"]
        self.directives.append("COPY profiler/. /profiler/.")
        self.host_paths.append("/profiler")

    def _inject_harness(self) -> None:
        if not self.env.internal["inject_harness"]:
            return

        self.directives += [
            "COPY base-tr-requirements.txt /",
            "RUN pip install --no-cache-dir -r /base-tr-requirements.txt",
            "COPY pedl/. /pedl/.",
            "RUN mkdir -p /model_packages",
            "WORKDIR /",
            "ENV PYTHONPATH /",
            "COPY entrypoint.sh /",
        ]
        # Inject files from the agent filesystem which will be used by COPY directives when
        # building an image.
        self.host_paths += ["/pedl", "/base-tr-requirements.txt", "/entrypoint.sh"]


class ImageManager:
    """
    Manages the lifecycle of images built by the agent at runtime.
    """

    def __init__(self, docker: aiodocker.Docker) -> None:
        self._docker = docker

    async def image_present(self, image_name: str) -> bool:
        try:
            await self._docker.images.get(image_name)
            return True
        except DockerError as e:
            if e.status != 404:
                raise e
            return False

    async def ensure_image_pulled(
        self,
        image_name: str,
        force_pull_image: bool = False,
        auth: Optional[Dict[str, Any]] = None,
        log_handler: Optional[LogHandler] = None,
    ) -> None:
        """
        Ensure the image is stored locally by the docker daemon, pulling
        the image if needed.
        """
        if not force_pull_image and await self.image_present(image_name):
            logging.info("Found image {} locally".format(image_name))
            return

        repo, has_repo, path = image_name.partition("/")
        if not has_repo or "/" not in path:
            path = image_name
            repo = "docker.io"
        from_image, has_tag, tag = path.partition(":")
        if not has_tag:
            tag = "latest"

        logs = await self._docker.images.pull(
            from_image, auth=auth, repo=repo, tag=tag, stream=True
        )

        async for log in logs:
            if log_handler:
                await log_handler(log, "PULL")

        logging.info("Pulled image {}".format(image_name))

    async def build(
        self,
        base_image: str,
        directives: List[str],
        container_config: Dict[str, Any],
        host_paths: List[str],
        log_handler: Optional[LogHandler] = None,
        tag: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Build an image by starting with the provided base image name and
        executing the given list of directives.

        Return a container config suitable for running the image.

        host_paths is an optional list of files to add to the image.
        """

        if not directives:
            container_config["Image"] = base_image
            return container_config

        dockerfile = _generate_dockerfile(base_image, directives).encode("utf-8")
        logging.debug("Building dockerfile:\n{}".format(dockerfile.decode("utf-8")))

        if tag is None:
            hash = hashlib.md5(dockerfile).hexdigest()
            tag = "{}-{}-{}".format(base_image, pedl.__version__, hash)

        labels = {_IMAGE_MANAGED_LABEL_KEY: _IMAGE_MANAGED_LABEL_VALUE}

        with mktar_from_dockerfile(dockerfile, host_paths) as fileobj:
            logs = await self._docker.images.build(
                fileobj=fileobj, encoding="gzip", tag=tag, labels=labels, stream=True
            )

            async for log in logs:
                if log_handler:
                    await log_handler(log, "BUILD")
                if "errorDetail" in log:
                    raise ImageBuildError(
                        log["errorDetail"].get("code"), log["errorDetail"].get("message")
                    )

        container_config["Image"] = tag
        return container_config

    async def build_from_environment(
        self,
        environment: Dict[str, Any],
        image_type: RuntimeEnv,
        user_directives: List[str],
        container_config: Optional[Dict[str, Any]],
        auth: Optional[Dict[str, Any]],
        log_handler: Optional[LogHandler],
        git_commit: Optional[str],
        force_pull_image: bool = False,
        tag: Optional[str] = None,
        ignore_prebuilt: bool = False,
    ) -> Dict[str, Any]:
        """
        Build an image conforming to the environment configuration, image type,
        and list of user-specified directives (may be empty).

        Return a container config suitable for running the image.
        """
        logging.debug("Building docker image from environment: {}".format(environment))

        # Construct the directives and settings for building a docker image based on the portion of
        # the environment which may exist as a prebuilt image.
        env = Environment.from_dict(environment)
        builder = EnvironmentBuilder(env, image_type, container_config)
        base_image = builder.base_image
        directives = builder.directives
        config = builder.config
        host_paths = builder.host_paths

        # If a matching prebuilt exists locally, use the prebuilt image as the base_image and
        # reset the directives.
        have_image = False
        if not env.custom_image and git_commit is not None and not ignore_prebuilt:
            prebuilt_name = generate_prebuilt_name(environment, image_type, git_commit)
            try:
                await self.ensure_image_pulled(prebuilt_name, auth=auth, log_handler=log_handler)
            except DockerError as e:
                if e.status != 404:
                    raise e
            else:
                # Ignore the user's "force_pull_image" option for existing prebuilts.
                have_image = True
                force_pull_image = False
                base_image = prebuilt_name
                directives = []

        # Ensure that the base image is pulled. This call will be a no-op in the docker daemon if
        # the image already exists in it's cache (uness force_pull_image is true).
        if not have_image:
            await self.ensure_image_pulled(
                base_image, force_pull_image=force_pull_image, auth=auth, log_handler=log_handler
            )

        return await self.build(
            base_image=base_image,
            directives=directives + user_directives,
            container_config=config,
            host_paths=host_paths,
            log_handler=log_handler,
            tag=tag,
        )
