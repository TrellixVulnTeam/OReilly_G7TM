from abc import ABCMeta, abstractmethod
from typing import Any, Dict, List

from aiodocker.containers import DockerContainer


class TrialNetworking(metaclass=ABCMeta):
    def __init__(self) -> None:
        return

    @abstractmethod
    async def get_ports(self, container: DockerContainer) -> Dict[str, List[Dict[str, Any]]]:
        pass

    @abstractmethod
    async def get_network(self) -> str:
        pass


class BridgeNetworking(TrialNetworking):
    def __init__(self, network: str):
        self.network = network
        super().__init__()

    async def get_ports(self, container: DockerContainer) -> Dict[str, List[Dict[str, Any]]]:
        # Inspect the container again after the container has started to view
        # published ports.
        container_json = await container.show()
        return {
            port: [
                {
                    "host_ip": mapping["HostIp"],
                    "host_port": mapping["HostPort"],
                    "container_port": port.split("/")[0],
                }
                for mapping in mappings
            ]
            for port, mappings in container_json.get("NetworkSettings", {}).get("Ports", {}).items()
        }

    async def get_network(self) -> str:
        return self.network


class HostNetworking(TrialNetworking):
    def __init__(self, ports: List[str]):
        self.ports = ports
        super().__init__()

    async def get_ports(self, c: DockerContainer) -> Dict[str, List[Dict[str, Any]]]:
        return {
            port + "/tcp": [{"host_ip": "0.0.0.0", "host_port": port, "container_port": port}]
            for port in self.ports
        }

    async def get_network(self) -> str:
        return "host"
