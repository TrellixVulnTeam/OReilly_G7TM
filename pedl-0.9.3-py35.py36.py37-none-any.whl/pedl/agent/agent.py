"""master <-> agent protocol:

On agent startup, it sends an AGENT_STARTUP message to the master, which
includes the devices available at this agent. The agent then listens for
commands; to launch a new workload on the agent, the master sends the
agent a START_CONTAINER message. The agent launches the workload (by
connecting to the local Docker daemon). The agent does not reply to the
master directly; instead, the workload itself connects back to the
master and initiates its own protocol.
"""
import argparse
import asyncio
import base64
import io
import logging
import os
import re
import signal
import subprocess
import sys
import tarfile
import traceback
import uuid
from typing import Any, Dict, IO, Iterable, List, Optional, Tuple

import aiodocker
import cpuinfo
import psutil
import simplejson
import websockets
from aiodocker.containers import DockerContainer

import pedl
import pedl.storage
from pedl._json import json_encode
from pedl.agent.image import ImageBuildError, ImageManager
from pedl.agent.networking import BridgeNetworking, HostNetworking, TrialNetworking
from pedl.check import check_eq_len, check_gt, check_in, check_len, check_not_in, check_true
from pedl.constants import (
    KRB5_CONFIG_CONTAINER_PATH,
    LOCAL_RENDEZVOUS_PORT,
    MAX_WEBSOCKET_MSG_SIZE,
    MODEL_PACKAGES_CONTAINER_PATH,
)
from pedl.env import RuntimeEnv
from pedl.storage import SharedFSStorageManager


MODEL_PATH = "/model_def"
ABNORMAL_EXIT_CODE = 299

# MAX_LOG_SIZE is the maximum log text (in Unicode code points) to send in one
# log message.
#
# The longest message stream observed for Docker server version 18.09.3 (API
# 1.39) was 32KB in a build stream and 16KB in a log stream. For now, choose a
# maximum log size above this threshold to avoid unnecessary fragmentation.
MAX_LOG_SIZE = 64 * 1024


def _detect_gpus() -> List[pedl.Device]:
    """
    Return the list of available nvidia GPUs.
    """
    try:
        cmd = ["nvidia-smi", "--query-gpu=index,name,uuid", "--format=csv,noheader"]
        output = subprocess.check_output(cmd, encoding="utf-8").rstrip()
        gpu_info = [line.split(", ") for line in output.split(os.linesep)]
        return [pedl.Device(int(i[0]), i[1], i[2], "gpu") for i in gpu_info]
    except (FileNotFoundError, OSError, subprocess.CalledProcessError):
        return []


def _detect_cpus(limit: Optional[float] = None) -> List[pedl.Device]:
    """
    Return the list of available CPUs.
    """
    # We use a single device to represent all the CPUs on a host
    # (this assumes that a single trial can efficiently utilize all
    # CPUs on a host). We will likely want to revisit this.
    num_cpus = psutil.cpu_count(logical=False)
    check_gt(num_cpus, 0)

    cpu_info = cpuinfo.get_cpu_info()
    if limit:
        brand = "{} x {} physical cores (limited to {} cores)".format(
            cpu_info["brand"], num_cpus, limit
        )
    else:
        brand = "{} x {} physical cores".format(cpu_info["brand"], num_cpus)
    return [pedl.Device(0, brand, None, "cpu")]


def _detect_devices(
    artificial_slots: Optional[int] = None,
    gpu_indices: Optional[List[int]] = None,
    cpu_limit: Optional[float] = None,
) -> List[pedl.Device]:
    """
    Autoconfigure the devices exposed by the agent.

    The most common case in deployed installs is to expose all GPU devices present. To
    support various testing configurations, we also allow the agent to expose fake devices,
    a subset of CPU resources or a subset of GPU resources, but this is not representative
    of deployed agents.

    The current policy is:
    - If `artificial_slots` is given, expose that many CPU slots.
    - Otherwise, expose all GPUs present on the machine after applying the optional
      mask `gpu_indices`.
    - If there are no GPUs, expose all CPUs present on the machine after applying
      the optional mask `cpu_limit`.
    """
    if artificial_slots:
        logging.warning("Using %d artificial slots instead of real slots", artificial_slots)
        return [
            pedl.Device(index, "Artificial", str(uuid.uuid4()), "cpu")
            for index in range(artificial_slots)
        ]

    devices = _detect_gpus()
    if not devices:
        logging.warning("Did not detect any GPUs; using CPU-only mode")
        return _detect_cpus(cpu_limit)

    if not gpu_indices:
        return devices

    return [d for d in devices if d.id in gpu_indices]


async def send_msg(socket: websockets.client.WebSocketClientProtocol, msg: Dict[str, Any]) -> None:
    """
    Send a JSON-encoded message to the provided socket.
    """
    await socket.send(json_encode(msg))


async def send_stream(
    socket: websockets.client.WebSocketClientProtocol,
    stream: str,
    container_id: str,
    stream_type: str = "MISC",
) -> None:
    """
    Send stream messages as PEDL log messages.

    Streams, as returned by the Docker API, are sequences of characters
    typically broken at newline boundaries but possibly arbitrarily fragmented
    if newlines occur infrequently. Thus, the maximum length of a stream frame
    is an implementation detail that may vary between Docker versions.

    This function imposes its own limit to stream fragments to ensure a
    well-known fragment limit.
    """
    stream_len = len(stream)
    for start in range(0, stream_len, MAX_LOG_SIZE):
        end = min(start + MAX_LOG_SIZE, stream_len)
        await send_msg(
            socket,
            {
                "type": "CONTAINER_LOG_MSG",
                "container_id": container_id,
                "log_message": {"stream": stream[start:end], "type": stream_type},
            },
        )


async def send_build_logs(
    socket: websockets.client.WebSocketClientProtocol,
    message_dict: Dict[str, Any],
    message_type: str,
    container_id: str,
) -> None:
    """
    Send responses to Docker pull and build requests [1] as PEDL log messages.

    - message_dict: raw response
    - message_type: one of "BUILD" or "PULL"

    The output of Docker POST /build (i.e., docker build) is a stream of JSON
    records:

        {"stream": "Step 1/5..."}
        {"stream": "..."}
        {"error": "Error...", "errorDetail": {"code": 123, "message": "Error..."}}

    And the output of Docker POST /images/create?fromImage=... (i.e., docker
    pull) is a stream of JSON records:

        {"status": "Pulling..."}
        {"status": "Pulling", "progress": "1 B/ 100 B", "progressDetail": {"current": 1, "total": 100}}  # noqa
        {"error": "Invalid..."}
        ...

    A message_dict is one record from this stream.

    [1] https://docs.docker.com/engine/api/v1.24/
    """

    if "stream" in message_dict:
        await send_stream(socket, message_dict["stream"], container_id, stream_type=message_type)
    else:
        # When we have a non-stream message, send it directly.
        message_dict = {**message_dict, "type": message_type}
        await send_msg(
            socket,
            {
                "type": "CONTAINER_LOG_MSG",
                "container_id": container_id,
                "log_message": message_dict,
            },
        )


async def get_installed_runtimes(docker: aiodocker.Docker) -> Iterable[str]:
    """
    Returns a set of installed Docker runtimes.
    """
    system_info = await docker.system.info()
    runtimes = system_info["Runtimes"].keys()  # type: Iterable[str]
    return runtimes


async def handle_exception(
    socket: websockets.client.WebSocketClientProtocol, e: Exception, container_id: str
) -> None:
    """
    Handle unexpected Exceptions during the container lifecycle by recording a
    log message in the agent log and task log, and sending a CONTAINER_EXITED
    message.
    """

    if isinstance(e, ImageBuildError):
        cause = "Failed to build runtime image"
        exit_code = e.error_code
    else:
        cause = "Unexpected error while managing task container"
        exit_code = 1

    # Record the same log message in the agent log and in the per-task log.
    logging.exception(cause)
    await send_stream(socket, "{}:\n{}".format(cause, traceback.format_exc()), container_id)

    exited_msg = {"type": "CONTAINER_EXITED", "container_id": container_id, "exit_code": exit_code}
    await send_msg(socket, exited_msg)


async def _get_working_dir(container: DockerContainer) -> str:
    # TODO: Removing the depencency on aiodocker would allow the agent to
    # retrieve the WorkingDir configuration value on container creation,
    # without the need for two calls to the docker daemon.
    container_json = await container.show()
    working_dir = container_json.get("Config", {}).get("WorkingDir")
    return working_dir or "/"


async def _start_container(
    socket: Any,
    container_id: str,
    container: DockerContainer,
    port_remappings: Iterable[Tuple[str, str]],
    trial_runner_network: TrialNetworking,
) -> int:
    await container.start()

    published_ports = await trial_runner_network.get_ports(container)
    for label, port in port_remappings:
        published_ports[label] = published_ports[str(port) + "/tcp"]
        del published_ports[str(port) + "/tcp"]

    await send_msg(
        socket,
        {"type": "CONTAINER_STARTED", "container_id": container_id, "ports": published_ports},
    )

    exit_code = ABNORMAL_EXIT_CODE
    try:
        # Capture container logs and send back to the master.
        logs = await container.log(
            follow=True, stderr=True, stdout=True, stream=True, timestamps=True
        )
        async for line in logs:
            await send_stream(socket, line, container_id, stream_type="RUN")

        run_status = await container.wait()
        exit_code = run_status["StatusCode"]
    finally:
        await send_msg(
            socket,
            {"type": "CONTAINER_EXITED", "container_id": container_id, "exit_code": exit_code},
        )

    return exit_code


async def _ensure_deleted(container: DockerContainer) -> None:
    try:
        # Delete volumes associated with container too.
        await container.delete(v=True, force=True)
    except aiodocker.exceptions.DockerError as e:
        logging.warning("Error deleting container: %s", e)


def find_nvidia_driver_version() -> str:
    # We expect the content of `nvidia/version` to look like:
    #
    #   NVRM version: NVIDIA UNIX x86_64 Kernel Module  384.111 [...]
    #   [...]
    try:
        with open("/proc/driver/nvidia/version", "r") as version_f:
            first_line = version_f.readline()
            match = re.search(r"Kernel Module\s+([\d.]+)", first_line)
            if match is not None:
                return match.group(1)
    except Exception as e:
        logging.warning("Error querying NVIDIA driver version: %s", e)

    return "Unknown"


class AgentManager:
    def __init__(
        self,
        agent_id: str,
        master_addr: str,
        master_port: int,
        trial_runner_network: str,
        trial_runner_cpus: Optional[float],
        trial_runner_gpu_indices: Optional[List[int]],
        trial_runner_uid: Optional[int],
        trial_runner_gid: Optional[int],
        git_commit: Optional[str],
        registry_auth: Optional[Dict[str, str]] = None,
        artificial_slots: Optional[int] = None,
        proxy_addr: Optional[str] = None,
    ) -> None:
        self.agent_id = agent_id
        self.master_addr = master_addr
        self.master_port = master_port
        self.trial_runner_network = trial_runner_network
        self.trial_runner_cpus = trial_runner_cpus
        self.trial_runner_uid = trial_runner_uid
        self.trial_runner_gid = trial_runner_gid
        self.git_commit = git_commit
        self.registry_auth = registry_auth
        self.proxy_addr = proxy_addr
        self.docker = aiodocker.Docker()
        self.containers = {}  # type: Dict[str, DockerContainer]
        self.image_manager = ImageManager(self.docker)
        self.nvidia_runtime_installed = None  # type: Optional[bool]
        self.container_seqno = 0
        self.shutdown_started = False
        self.devices = _detect_devices(
            artificial_slots=artificial_slots,
            cpu_limit=trial_runner_cpus,
            gpu_indices=trial_runner_gpu_indices,
        )

        device_log = ["Detected compute devices:"]
        device_log += ["  {}".format(d) for d in self.devices]
        logging.info("\n".join(device_log))

    async def run_container(
        self,
        socket: Any,
        workload: Any,
        container_id: str,
        container_config: Dict[str, Any],
        container_name_prefix: str,
        container_files: Iterable[Tuple[Optional[str], IO[bytes]]],
        port_remappings: Iterable[Tuple[str, str]],
        trial_runner_network: TrialNetworking,
    ) -> None:
        check_not_in(container_id, self.containers)

        # Try to pick a container name that is unique but also contains
        # useful metadata. We include a sequence number because it seems
        # that there is a period of time after a container exits before
        # its name can safely be reused (#1372).
        container_name = "{}-{}-{}-{}".format(
            container_name_prefix, self.agent_id, self.container_seqno, uuid.uuid4()
        )
        self.container_seqno += 1

        container = await self.docker.containers.create(
            config=container_config, name=container_name
        )
        short_id = container["id"][:10]

        working_dir = await _get_working_dir(container)
        for path, data in container_files:
            if path is None:
                path = working_dir
            await container.put_archive(path, data)

        logging.info(
            "Starting container for workload %s (%s, ID: %s)", workload, container_name, short_id
        )
        self.containers[container_id] = container
        try:
            exit_code = await _start_container(
                socket, container_id, container, port_remappings, trial_runner_network
            )
        finally:
            await _ensure_deleted(container)
            self.containers.pop(container_id, None)

        if exit_code == 0:
            level = logging.INFO
        else:
            level = logging.WARNING

        logging.log(
            level,
            "Container for workload %s exited with code %s (%s, ID: %s)",
            workload,
            exit_code,
            container_name,
            short_id,
        )

    async def start(self) -> None:
        runtimes = await get_installed_runtimes(self.docker)
        self.nvidia_runtime_installed = "nvidia" in runtimes

        if self.nvidia_runtime_installed:
            logging.info("Nvidia driver version: %s", find_nvidia_driver_version())

        logging.debug("Trial runner network: %s", self.trial_runner_network)
        logging.debug("Nvidia container runtime: %s", self.nvidia_runtime_installed)

        url = "ws://{}:{}/ws/agent/{}".format(self.master_addr, self.master_port, self.agent_id)
        logging.info("Connecting to PEDL master at %s", url)

        async with websockets.connect(url, max_size=MAX_WEBSOCKET_MSG_SIZE) as socket:
            logging.info("Connected to PEDL master")

            await self.socket_loop(socket)

    async def socket_loop(self, socket: websockets.client.WebSocketClientProtocol) -> None:
        startup_msg = {
            "type": "AGENT_STARTUP",
            "version": pedl.__version__,
            "address": self.proxy_addr,
            "devices": self.devices,
        }
        await send_msg(socket, startup_msg)

        # TODO(neilc): Add recv timeout (#277).
        async for raw_msg in socket:
            msg = simplejson.loads(raw_msg)

            if msg["type"] == "START_CONTAINER":
                asyncio.ensure_future(self.start_container(msg, socket))
            elif msg["type"] == "START_TASK":
                asyncio.ensure_future(self.start_task(msg, socket))
            elif msg["type"] == "KILL_CONTAINER":
                asyncio.ensure_future(self.kill_container(msg, socket))
            elif msg["type"] == "GC_CHECKPOINTS":
                asyncio.ensure_future(self.gc_checkpoints(msg, socket))
            else:
                raise NotImplementedError("Unrecognized message: {}".format(msg))

    async def start_container(self, msg: Dict[str, Any], socket: Any) -> None:
        try:
            await self.do_start_container(msg, socket)
        except Exception as e:
            await handle_exception(socket, e, msg["container_id"])

    async def do_start_container(self, msg: Dict[str, Any], socket: Any) -> None:
        if self.shutdown_started:
            workload = pedl.Workload.from_json(msg["initial_workload"])

            # Record the same log message in the agent log and in the
            # per-trial log.
            text = ("Not starting workload {} since agent shutdown has started").format(workload)
            logging.info(text)

            await send_stream(socket, text, msg["container_id"])

            await send_msg(
                socket,
                {"type": "CONTAINER_EXITED", "container_id": msg["container_id"], "exit_code": 1},
            )
            return

        workload = pedl.Workload.from_json(msg["initial_workload"])
        experiment_config = msg["experiment_config"]
        checkpoint = msg["latest_checkpoint"]
        target_devices = pedl.Device.many_from_json(msg["devices"])
        is_gpu = any(d.device_type == "gpu" for d in target_devices)

        assert self.nvidia_runtime_installed is not None
        if is_gpu:
            check_true(self.nvidia_runtime_installed)

        check_len(
            {d.device_type for d in target_devices},
            1,
            "Mixed GPU and CPU devices: {}".format(target_devices),
        )
        for d in target_devices:
            check_in(d, self.devices)

        environment_variables = {
            "PEDL_MASTER_ADDR": self.master_addr,
            "PEDL_MASTER_PORT": self.master_port,
            "PEDL_AGENT_ID": self.agent_id,
            "PEDL_SLOT_IDS": json_encode(msg["slot_ids"]),
            "PEDL_CONTAINER_ID": msg["container_id"],
            "PEDL_USE_GPU": is_gpu,
            "PEDL_EXPERIMENT_ID": workload.experiment_id,
            "PEDL_TRIAL_ID": workload.trial_id,
            "PEDL_TRIAL_SEED": msg["trial_seed"],
            "PEDL_EXPERIMENT_CONFIG": json_encode(experiment_config),
            "PEDL_MODEL_PATH": MODEL_PATH,
            "PEDL_HPARAMS": json_encode(msg["hparams"]),
            "PEDL_INITIAL_WORKLOAD": json_encode(workload),
            "PEDL_LATEST_CHECKPOINT": json_encode(checkpoint),
            "PEDL_WORKLOAD_MANAGER_TYPE": msg["workload_manager_type"],
        }

        # Implement GPU isolation by exposing only the target GPU devices to
        # the container. We identify the target GPUs by UUID to avoid any risk
        # of ambiguity.
        if is_gpu:
            uuids = []
            for d in target_devices:
                assert d.uuid is not None, "Invalid device: {}".format(d)
                uuids.append(d.uuid)

            environment_variables["NVIDIA_VISIBLE_DEVICES"] = ",".join(uuids)
        else:
            # If NVIDIA_VISIBLE_DEVICES is left unset, it defaults to exposing
            # all the GPU's available on the instance. Explicitly set
            # NVIDIA_VISIBLE_DEVICES to "none" to avoid this in the non-GPU
            # setting.
            environment_variables["NVIDIA_VISIBLE_DEVICES"] = "none"

        # Host directories to bind-mount into the container.  These are
        # specified in the experiment config under "bind_mounts" as an
        # array of mappings, one for each mount.  Each mapping has
        # "host_path" and "container_path" keys.  Example:
        #
        #   bind_mounts:
        #     - host_path: /host/path1
        #       container_path: /container/path1
        #     - host_path: /host/path2
        #       container_path: /container/path2
        #
        # We depend on the cluster operator to ensure that the correct file
        # system (e.g., NFS, GlusterFS) volume is mounted at the same path on
        # all agent hosts.
        mounts = [
            {
                "Type": "bind",
                "Source": mount["host_path"],
                "Target": mount["container_path"],
                "ReadOnly": mount.get("read_only", False),
                "BindOptions": {"Propagation": mount.get("propagation", "rprivate")},
            }
            for mount in experiment_config.get("bind_mounts") or []
        ]

        # If the experiment wants to write checkpoints to a `shared_fs`
        # volume, mount the specified host path into the container.
        checkpoint_storage = experiment_config["checkpoint_storage"]
        checkpoint_manager = pedl.storage.build(checkpoint_storage)
        if isinstance(checkpoint_manager, SharedFSStorageManager):
            mounts.append(checkpoint_manager.get_mount_config())

        # If using a custom Kerberos config file, bind-mount that file
        # into the container automatically.
        krb_config = experiment_config.get("security", {}).get("kerberos", {})
        krb_config_file = krb_config.get("config_file")
        if krb_config_file is not None:
            mount = {
                "Type": "bind",
                "Source": krb_config_file,
                "Target": KRB5_CONFIG_CONTAINER_PATH,
                "ReadOnly": True,
                "BindOptions": {"Propagation": "rprivate"},
            }
            mounts.append(mount)

        check_eq_len(
            mounts, {m["Target"] for m in mounts}, "Bind mount container paths not unique!"
        )

        env = experiment_config["environment"]
        force_pull_image = env["force_pull_image"]
        image_type = RuntimeEnv.GPU if is_gpu else RuntimeEnv.CPU
        command_config = env.get("runtime_commands", {}).get(str(image_type), [])
        package_config = env.get("runtime_packages", {}).get(str(image_type), [])
        variable_config = env.get("environment_variables", {}).get(str(image_type), [])
        user_directives = ["RUN {}".format(c) for c in command_config]
        if package_config:
            user_directives.append("RUN pip install {}".format(" ".join(package_config)))
        user_directives += ["ENV {}".format(c) for c in variable_config]

        experiment_auth = env.get("registry_auth")
        if not experiment_auth:
            experiment_auth = self.registry_auth

        async def record_logs(message_dict: Dict[str, Any], message_type: str) -> None:
            await send_build_logs(socket, message_dict, message_type, msg["container_id"])

        distributed_trial = experiment_config["resources"]["distributed"]
        if distributed_trial:
            # For distributed trials we assume we run in host networking mode
            # so each trial is assigned a port based on the smallest slot.
            min_slot_id = min(map(lambda x: int(x), msg["slot_ids"]))
            container_ports = [
                str(LOCAL_RENDEZVOUS_PORT + min_slot_id),
                str(LOCAL_RENDEZVOUS_PORT + min_slot_id + len(self.devices)),
            ]
            trial_runner_network = HostNetworking(container_ports)  # type: TrialNetworking
        else:
            trial_runner_network = BridgeNetworking(self.trial_runner_network)
            container_ports = [str(LOCAL_RENDEZVOUS_PORT), str(LOCAL_RENDEZVOUS_PORT + 1)]
        trial_runner_network_type = await trial_runner_network.get_network()
        environment_variables["PEDL_RENDEZVOUS_PORTS"] = ",".join(container_ports)
        environment_variables["PEDL_TRIAL_RUNNER_NETWORK"] = trial_runner_network_type
        logging.info(
            f"Assigning container ports: {container_ports} to trial with "
            f"{trial_runner_network_type} networking"
        )

        container_config = {
            "Labels": {
                "ai.determined.type": "trial-runner-container",
                "ai.determined.pedl-trial-id": str(workload.trial_id),
                "ai.determined.agent-id": self.agent_id,
                "ai.determined.pedl-version": pedl.__version__,
            },
            "Cmd": ["/entrypoint.sh"],
            "Env": ["{}={}".format(k, v) for k, v in environment_variables.items()],
            "HostConfig": {
                "Mounts": mounts,
                "NetworkMode": trial_runner_network_type,
                "Init": True,
                "PublishAllPorts": True,
                "ShmSize": 4294967296,  # 4g
            },
        }  # type: Dict[str, Any]

        container_config = await self.image_manager.build_from_environment(
            environment=env,
            image_type=image_type,
            user_directives=user_directives,
            container_config=container_config,
            auth=experiment_auth,
            log_handler=record_logs,
            git_commit=self.git_commit,
            force_pull_image=force_pull_image,
        )
        logging.info(
            "Done building runtime image {} for {}".format(container_config["Image"], workload)
        )

        if not distributed_trial:
            container_config["ExposedPorts"] = {
                "{}/tcp".format(LOCAL_RENDEZVOUS_PORT): {},
                "{}/tcp".format(LOCAL_RENDEZVOUS_PORT + 1): {},
            }

        if self.trial_runner_uid is not None:
            if self.trial_runner_gid is not None:
                container_config["User"] = "{}:{}".format(
                    self.trial_runner_uid, self.trial_runner_gid
                )
            else:
                container_config["User"] = str(self.trial_runner_uid)

        if self.trial_runner_cpus is not None:
            container_config["HostConfig"]["NanoCPUs"] = int(self.trial_runner_cpus * 1e9)

        if is_gpu:
            container_config["HostConfig"]["Runtime"] = "nvidia"

        # Transfer model from agent container to trial container.
        container_files = []  # type: List[Tuple[str, IO[bytes]]]
        tarstream = io.BytesIO()
        with tarfile.TarFile(fileobj=tarstream, mode="w") as tar:
            tarinfo = tarfile.TarInfo(name=MODEL_PATH)
            model_def = base64.b64decode(msg["model_definition"])
            tarinfo.size = len(model_def)
            tar.addfile(tarinfo, io.BytesIO(model_def))

        tarstream.seek(0)
        container_files += [("/", tarstream)]

        if "model_packages" in msg:
            container_files += [
                (MODEL_PACKAGES_CONTAINER_PATH, io.BytesIO(base64.b64decode(msg["model_packages"])))
            ]

        await self.run_container(
            socket,
            workload,
            msg["container_id"],
            container_config,
            "pedl-tr-{}-{}".format(workload.trial_id, workload.step_id),
            container_files,
            [],
            trial_runner_network,
        )

    async def kill_container(self, msg: Dict[str, Any], socket: Any) -> None:
        try:
            await self.do_kill_container(msg, socket)
        except Exception as e:
            await handle_exception(socket, e, msg["container_id"])

    async def do_kill_container(self, msg: Dict[str, Any], socket: Any) -> None:
        container = self.containers.pop(msg["container_id"], None)
        if container is None:
            return
        try:
            await container.kill()
        except aiodocker.exceptions.DockerError as e:
            # An HTTP status code of conflict is returned when the container is
            # not running:
            #
            #   https://docs.docker.com/engine/api/v1.37/#operation/ContainerKill
            if e.status not in {404, 409}:
                raise e
            await send_stream(
                socket,
                "{}:\n{}".format("Failed to kill container", traceback.format_exc()),
                msg["container_id"],
            )

    async def start_task(self, msg: Dict[str, Any], socket: Any) -> None:
        try:
            await self.do_start_task(msg, socket)
        except Exception as e:
            await handle_exception(socket, e, msg["container_id"])

    async def do_start_task(self, msg: Dict[str, Any], socket: Any) -> None:
        container_id = msg["container_id"]
        task_id = msg["task_id"]
        config = msg["config"]
        target_devices = pedl.Device.many_from_json(msg["devices"])
        is_gpu = any(d.device_type == "gpu" for d in target_devices)

        assert self.nvidia_runtime_installed is not None
        if is_gpu:
            check_true(self.nvidia_runtime_installed)

        if len(target_devices) > 0:
            check_len(
                {d.device_type for d in target_devices},
                1,
                "Mixed GPU and CPU devices: {}".format(target_devices),
            )
            for d in target_devices:
                check_in(d, self.devices)

        environment_variables = {"PEDL_CONTAINER_ID": container_id, "PEDL_TASK_ID": task_id}

        # Implement GPU isolation by exposing only the target GPU devices to
        # the container. We identify the target GPUs by UUID to avoid any risk
        # of ambiguity.
        if is_gpu:
            uuids = []
            for d in target_devices:
                assert d.uuid is not None, "Invalid device: {}".format(d)
                uuids.append(d.uuid)

            environment_variables["NVIDIA_VISIBLE_DEVICES"] = ",".join(uuids)
        else:
            # If NVIDIA_VISIBLE_DEVICES is left unset, it defaults to exposing
            # all the GPU's available on the instance. Explicitly set
            # NVIDIA_VISIBLE_DEVICES to "none" to avoid this in the non-GPU
            # setting.
            environment_variables["NVIDIA_VISIBLE_DEVICES"] = "none"

        # Host directories to bind-mount into the container.  These are
        # specified in the experiment config under "bind_mounts" as an
        # array of mappings, one for each mount.  Each mapping has
        # "host_path" and "container_path" keys.  Example:
        #
        #   bind_mounts:
        #     - host_path: /host/path1
        #       container_path: /container/path1
        #     - host_path: /host/path2
        #       container_path: /container/path2
        #
        # We depend on the cluster operator to ensure that the correct file
        # system (e.g., NFS, GlusterFS) volume is mounted at the same path on
        # all agent hosts.
        mounts = [
            {
                "Type": "bind",
                "Source": mount["host_path"],
                "Target": mount["container_path"],
                "ReadOnly": mount.get("read_only", False),
                "BindOptions": {"Propagation": mount.get("propagation", "rprivate")},
            }
            for mount in config.get("bind_mounts") or []
        ]

        # If using a custom Kerberos config file, bind-mount that file
        # into the container automatically.
        krb_config = config.get("security", {}).get("kerberos", {})
        krb_config_file = krb_config.get("config_file")
        if krb_config_file is not None:
            mount = {
                "Type": "bind",
                "Source": krb_config_file,
                "Target": KRB5_CONFIG_CONTAINER_PATH,
                "ReadOnly": True,
                "BindOptions": {"Propagation": "rprivate"},
            }
            mounts.append(mount)

        check_eq_len(
            mounts, {m["Target"] for m in mounts}, "Bind mount container paths not unique!"
        )

        env = config["environment"]
        force_pull_image = env["force_pull_image"]
        image_type = RuntimeEnv.GPU if is_gpu else RuntimeEnv.CPU
        command_config = env.get("runtime_commands", {}).get(str(image_type), [])
        package_config = env.get("runtime_packages", {}).get(str(image_type), [])
        variable_config = env.get("environment_variables", {}).get(str(image_type), [])
        user_directives = ["RUN {}".format(c) for c in command_config]
        if package_config:
            user_directives.append("RUN pip install {}".format(" ".join(package_config)))
        user_directives += ["ENV {}".format(c) for c in variable_config]

        experiment_auth = env.get("registry_auth")
        if not experiment_auth:
            experiment_auth = self.registry_auth

        async def record_logs(message_dict: Dict[str, Any], message_type: str) -> None:
            await send_build_logs(socket, message_dict, message_type, msg["container_id"])

        trial_runner_network = BridgeNetworking(self.trial_runner_network)
        container_config = {
            "Labels": {
                "ai.determined.type": "task-container",
                "ai.determined.pedl-task-id": task_id,
                "ai.determined.pedl-container-id": container_id,
                "ai.determined.agent-id": self.agent_id,
                "ai.determined.pedl-version": pedl.__version__,
            },
            "Cmd": config.get("entrypoint"),
            "Env": ["{}={}".format(k, v) for k, v in environment_variables.items()],
            "HostConfig": {
                "Mounts": mounts,
                "NetworkMode": await trial_runner_network.get_network(),
                "PublishAllPorts": True,
                "Init": True,
            },
        }  # type: Dict[str, Any]

        container_config = await self.image_manager.build_from_environment(
            environment=env,
            image_type=image_type,
            user_directives=user_directives,
            container_config=container_config,
            auth=experiment_auth,
            log_handler=record_logs,
            git_commit=self.git_commit,
            force_pull_image=force_pull_image,
        )

        # Exposed ports must be in the form: "<port>/<tcp|udp|sctp>"
        # (e.g. 22/tcp). Additionally, Docker expects the format for
        # "ExposedPorts" to be a mapping of the exposed port to an empty
        # object.
        exposed_ports = {
            str(port) + "/tcp": {} for port in (env.get("ports") or {}).values()
        }  # type: Dict[str, Dict[Any, Any]]
        if exposed_ports:
            container_config["ExposedPorts"] = exposed_ports

        if self.trial_runner_uid is not None:
            if self.trial_runner_gid is not None:
                container_config["User"] = "{}:{}".format(
                    self.trial_runner_uid, self.trial_runner_gid
                )
            else:
                container_config["User"] = str(self.trial_runner_uid)

        if self.trial_runner_cpus is not None:
            container_config["HostConfig"]["NanoCPUs"] = int(self.trial_runner_cpus * 1e9)

        if is_gpu:
            container_config["HostConfig"]["Runtime"] = "nvidia"

        # Add any additional files requested by the task spec into the
        # container.
        container_files = []  # type: List[Tuple[Optional[str], IO[bytes]]]
        full_context = {**(msg.get("context") or {}), **(msg.get("additional_files") or {})}
        if len(full_context) > 0:
            tarstream = io.BytesIO()
            with tarfile.TarFile(fileobj=tarstream, mode="w") as tar:
                for filename, info in full_context.items():
                    content = base64.b64decode(info["content"])
                    with io.BytesIO(content) as fileobj:
                        tarinfo = tarfile.TarInfo(name=filename)
                        tarinfo.mode = info["mode"]
                        tarinfo.size = len(content)
                        tar.addfile(tarinfo, fileobj)
            tarstream.seek(0)
            container_files += [(None, tarstream)]

        await self.run_container(
            socket,
            config["description"],
            container_id,
            container_config,
            "pedl-task",
            container_files,
            (env.get("ports") or {}).items(),
            trial_runner_network,
        )

    async def gc_checkpoints(self, msg: Dict[str, Any], socket: Any) -> None:
        try:
            await self.do_gc_checkpoints(msg, socket)
        except Exception as e:
            await handle_exception(socket, e, msg["container_id"])

    GC_CHECKPOINTS_ENTRYPOINT = ["python3.6", "/pedl/harness/gc_checkpoints_harness.py"]

    async def do_gc_checkpoints(self, msg: Dict[str, Any], socket: Any) -> None:
        # `msg` should have the following fields:
        # - experiment_id
        # - container_id
        # - experiment_config
        # - to_delete (list of two-element dicts)
        #   - uuid: str
        #     resources: list of str
        experiment_id = msg["experiment_id"]
        experiment_config = msg["experiment_config"]

        env_dict = {
            "PEDL_MASTER_ADDR": self.master_addr,
            "PEDL_MASTER_PORT": self.master_port,
            "PEDL_AGENT_ID": self.agent_id,
            "PEDL_EXPERIMENT_ID": experiment_id,
            "PEDL_EXPERIMENT_CONFIG": json_encode(experiment_config),
            "PEDL_DELETE": json_encode(msg["to_delete"]),
        }
        environment = ["{}={}".format(k, v) for k, v in env_dict.items()]

        checkpoint_storage = experiment_config["checkpoint_storage"]
        manager = pedl.storage.build(checkpoint_storage)
        mounts = []
        if isinstance(manager, SharedFSStorageManager):
            mounts.append(manager.get_mount_config())

        async def record_logs(message_dict: Dict[str, Any], message_type: str) -> None:
            await send_build_logs(socket, message_dict, message_type, msg["container_id"])

        trial_runner_network = BridgeNetworking(self.trial_runner_network)
        container_config = {
            "Labels": {
                "ai.determined.type": "gc-checkpoints-container",
                "ai.determined.agent-id": self.agent_id,
                "ai.determined.pedl-version": pedl.__version__,
            },
            "Env": environment,
            "Cmd": self.GC_CHECKPOINTS_ENTRYPOINT,
            "HostConfig": {
                "Mounts": mounts,
                "NanoCPUs": int(1e8),
                "NetworkMode": await trial_runner_network.get_network(),
            },
        }  # type: Dict[str, Any]

        container_config = await self.image_manager.build_from_environment(
            environment=experiment_config["environment"],
            image_type=RuntimeEnv.CPU,
            user_directives=[],
            container_config=container_config,
            auth=self.registry_auth,
            log_handler=record_logs,
            git_commit=self.git_commit,
        )

        if self.trial_runner_uid is not None:
            if self.trial_runner_gid is not None:
                container_config["User"] = "{}:{}".format(
                    self.trial_runner_uid, self.trial_runner_gid
                )
            else:
                container_config["User"] = str(self.trial_runner_uid)

        await self.run_container(
            socket,
            "",
            msg["container_id"],
            container_config,
            "pedl-gc-{}".format(experiment_id),
            [],
            [],
            trial_runner_network,
        )


async def graceful_shutdown(mgr: AgentManager, signum: int) -> None:
    logging.info("Starting graceful agent shutdown")
    mgr.shutdown_started = True
    for container in mgr.containers.values():
        short_id = container._id[:10]
        logging.info("Sending stop message to container: {}".format(short_id))
    if mgr.containers:
        await asyncio.wait([container.stop() for container in mgr.containers.values()])
    asyncio.get_event_loop().call_soon(sys.exit, 130)


def main() -> None:
    def env(key: str, default: Any = None) -> Any:
        value = os.getenv("PEDL_{}".format(key), default)
        if value == "":
            return None
        return value

    parser = argparse.ArgumentParser(description="Determined AI agent")

    parser.add_argument(
        "--version", action="version", version="PEDL agent, version {}".format(pedl.__version__)
    )
    parser.add_argument(
        "--log-level",
        type=str.upper,
        default=env("LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Set the logging level",
    )

    parser.add_argument(
        "master_ip_port",
        default=env("MASTER_IP_PORT", "localhost"),
        help="PEDL master IP[:port] (default port: 8080)",
    )
    parser.add_argument(
        "--agent-id",
        default=env("AGENT_ID", str(uuid.uuid4())),
        help="Unique ID of this PEDL agent",
    )
    parser.add_argument(
        "--artificial-slots", default=env("ARTIFICIAL_SLOTS", None), help=argparse.SUPPRESS
    )
    parser.add_argument(
        "--proxy-addr", type=str, default=env("PROXY_ADDR", None), help=argparse.SUPPRESS
    )
    parser.add_argument(
        "--git-commit", type=str, default=env("GIT_COMMIT", None), help=argparse.SUPPRESS
    )

    trial_runner = parser.add_argument_group("trial runner environment")
    trial_runner.add_argument(
        "--trial-runner-network",
        default=env("TRIAL_RUNNER_NETWORK", "default"),
        choices=["default", "bridge", "host"],
        help="The network mode of trial runner containers.",
    )
    trial_runner.add_argument(
        "--trial-runner-cpus",
        type=float,
        default=env("TRIAL_RUNNER_CPUS"),
        help="The amount of available CPU that a trial "
        "runner is restricted to (can be a decimal "
        "value, defaults to unrestricted use)",
    )
    trial_runner.add_argument(
        "--trial-runner-gpu-indices",
        default=env("TRIAL_RUNNER_GPU_INDICES"),
        help="Comma-separated GPU indices that this "
        "agent can schedule on. If unset, schedule "
        "on all available GPUs.",
    )
    trial_runner.add_argument(
        "--trial-runner-uid",
        type=int,
        default=env("TRIAL_RUNNER_UID"),
        help="The UID to use when running a trial "
        "runner container. Defaults to root "
        "(uid=0) if not specified.",
    )
    trial_runner.add_argument(
        "--trial-runner-gid",
        type=int,
        default=env("TRIAL_RUNNER_GID"),
        help="The GID to use when running a trial "
        "runner container. Defaults to the primary "
        "group of the user first, and the root "
        "group if no primary group is set.",
    )

    registry = parser.add_argument_group("Docker registry authentication")
    registry.add_argument(
        "--registry-server",
        default=env("REGISTRY_SERVER"),
        help="The default Docker registry to authenticate with when pulling trial runner images",
    )
    registry.add_argument(
        "--registry-username",
        default=env("REGISTRY_USERNAME"),
        help="The username to authenticate with to the registry server",
    )
    registry.add_argument(
        "--registry-password",
        default=env("REGISTRY_PASSWORD"),
        help="The password to authenticate with to the registry server",
    )
    registry.add_argument(
        "--registry-email",
        default=env("REGISTRY_EMAIL"),
        help="Email address required for registry authentication with Docker versions < 17.0.6",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=args.log_level, format="%(asctime)s:%(module)s:%(levelname)s: %(message)s"
    )

    loop = asyncio.get_event_loop()

    addr_parts = args.master_ip_port.split(":")
    if len(addr_parts) == 1:
        addr, port = addr_parts[0], "8080"
    else:
        addr, port = addr_parts

    if args.trial_runner_gid:
        check_true(
            args.trial_runner_uid,
            "Trial runner UID must be provided when providing a trial runner GID",
        )

    if (
        args.registry_server
        or args.registry_username
        or args.registry_password
        or args.registry_email
    ):
        assert args.registry_username, "Username must be provided for registry"
        assert args.registry_password, "Password must be provided for registry"
        registry_auth = {
            "serveraddress": args.registry_server,
            "username": args.registry_username,
            "password": args.registry_password,
            "email": args.registry_email,
        }  # type: Optional[Dict[str, str]]
        try:
            loop.run_until_complete(aiodocker.Docker().auth(**registry_auth))
            logging.info("Successfully authenticated with Docker registry")
        except aiodocker.exceptions.DockerError as e:
            if e.status < 500:
                raise e
            logging.exception("Could not check Docker registry credentials")
    else:
        registry_auth = None
        logging.warning(
            "No Docker registry credentials provided. Cannot pull images from remote registry."
        )

    logging.info("PEDL agent ID {}, version {}".format(args.agent_id, pedl.__version__))

    if args.artificial_slots:
        args.artificial_slots = int(args.artificial_slots)

    if args.git_commit is None:
        logging.warning("Git commit not specified; prebuilt images will not work")

    gpu_indices = [int(v) for v in (args.trial_runner_gpu_indices or "").split(",") if v]

    mgr = AgentManager(
        agent_id=args.agent_id,
        master_addr=addr,
        master_port=int(port),
        trial_runner_network=args.trial_runner_network,
        trial_runner_cpus=args.trial_runner_cpus,
        trial_runner_gpu_indices=gpu_indices,
        trial_runner_uid=args.trial_runner_uid,
        trial_runner_gid=args.trial_runner_gid,
        git_commit=args.git_commit,
        registry_auth=registry_auth,
        artificial_slots=args.artificial_slots,
        proxy_addr=args.proxy_addr,
    )

    loop.add_signal_handler(
        signal.SIGINT, asyncio.ensure_future, graceful_shutdown(mgr, signal.SIGINT)
    )
    loop.add_signal_handler(
        signal.SIGTERM, asyncio.ensure_future, graceful_shutdown(mgr, signal.SIGTERM)
    )
    loop.run_until_complete(mgr.start())
    loop.close()


if __name__ == "__main__":
    main()
