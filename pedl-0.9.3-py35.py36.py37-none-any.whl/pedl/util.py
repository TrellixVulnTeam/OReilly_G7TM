import collections
import functools
import hashlib
import logging
import os
import re
import threading
import urllib.parse
from datetime import datetime, timezone
from inspect import BoundArguments, signature
from itertools import tee
from typing import (
    Any,
    Callable,
    cast,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
    Tuple,
    TypeVar,
    Union,
)

import dill
import numpy as np
import simplejson

from pedl.check import check_eq, check_true

T = TypeVar("T")


def current_timestamp() -> datetime:
    """Returns the current time as a datetime object in the UTC timezone."""
    return datetime.now(timezone.utc)


def is_valid_url(url: str) -> bool:
    try:
        result = urllib.parse.urlparse(url)
        return bool(result.scheme and result.netloc and result.path)
    except ValueError:
        return False


def generate_trial_seed(random_state: np.random.RandomState = None) -> int:
    # A trial seed must be between 0 and (2**31 - 1).
    if random_state is None:
        return int(np.random.randint(low=0, high=2 ** 31))
    else:
        return int(random_state.randint(low=0, high=2 ** 31))


def iter_len(iterator: Iterator[Any]) -> int:
    """
    Return the length of an iterator without storing the full iterator
    in memory.
    """
    return sum(1 for _ in iterator)


def chunks(lst: List, chunk_size: int) -> Iterator[List]:
    """
    Collect data into fixed-length chunks or blocks.  Adapted from the
    itertools documentation recipes.

    e.g. chunks('ABCDEFG', 3) --> ABC DEF G
    """
    for i in range(0, len(lst), chunk_size):
        yield lst[i : i + chunk_size]


def pairs(iterable: Union[Iterator[T], Sequence[T]]) -> Iterator[Tuple[T, T]]:
    """ s -> (s0,s1), (s1,s2), (s2, s3), ...  """
    a, b = tee(iterable)
    next(b, None)
    return zip(a, b)


def get_hyperparameters() -> Dict[str, Any]:
    """
    Return a dictionary of hyperparameter names to values. Can be called
    anywhere in model definition code.
    """
    return simplejson.loads(os.getenv("PEDL_HPARAMS", "{}"))  # type: ignore


def get_hyperparameter(name: str) -> Any:
    """
    Return the hyperparameter value for the given name. Can be called from
    anywhere in model definition code.
    """
    hparams = get_hyperparameters()
    if name not in hparams:
        raise ValueError(
            "Could not find name '{}' in experiment "
            "hyperparameters. Please check your experiment "
            "configuration 'hyperparameters' section.".format(name)
        )
    return hparams[name]


def get_experiment_config() -> Dict[str, Any]:
    """
    Return the experiment configuration. Can be called from anywhere in model
    definition code.
    """
    return simplejson.loads(  # type: ignore
        os.getenv("PEDL_EXPERIMENT_CONFIG", "{}")
    )


def get_experiment_id() -> int:
    """
    Return the experiment ID of the current trial. Can be called
    from anywhere in model definition code.
    """
    return int(os.environ["PEDL_EXPERIMENT_ID"])


def get_trial_id() -> int:
    """
    Return the trial ID of the current trial. Can be called from anywhere in
    model definition code.
    """
    return int(os.environ["PEDL_TRIAL_ID"])


# Decorator to cache / memoize function calls to pickle files.


WrappedType = Callable[..., Any]
W = TypeVar("W", bound=WrappedType)


def make_json_call_signer(
    custom_encoder: Optional[simplejson.JSONEncoder] = None
) -> Callable[[BoundArguments], str]:
    """
    Hashes the bound arguments in a function call using JSON and sha512.  Note
    this requires the arguments to be JSON-serializable.  Pass in a
    `custom_encoder` for more flexible encoding.

    This is a simple solution for most functions which works around creating a
    hash for mutable objects like dictionaries and lists.  More subtle function
    calls may require custom signing functions.
    """

    def call_signer(binds: BoundArguments) -> str:
        return hashlib.sha512(
            simplejson.dumps(
                binds.arguments,
                sort_keys=True,
                cls=custom_encoder,
                ensure_ascii=False,
                indent=None,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()

    return call_signer


default_json_call_signer = make_json_call_signer()


def memo_pickle(
    cache_dir: str,
    call_signer: Callable[[BoundArguments], str] = default_json_call_signer,
    build: bool = False,
) -> Any:
    """
    A decorator which memoizes expensive function calls using pickle files.

    Note that the return value of the function to memoize must be pickleable.
    Also, any side-effects of the original function will not be re-run when
    returning a cached value. dill is used instead of pickle to add support for
    serializing the majority of the built-in python types.

    Parameters
    ----------
    cache_dir : str
        The root directory of the cached return values.
    call_signer: callable
        A function to "hash" the bound arguments in a call to the function
        being memoized.  The default signer uses JSON serialization (c.f.
        `make_json_call_signer`); handling arguments that are not
        JSON-serializable will require a custom signer.
    build: bool
        The cache is safe for concurrent read access but not safe for
        concurrent read/write access.  For this reason, by default the memoizer
        will fail on a cache miss instead of attempting to build it.  To build
        the cache, set `build` to `True`, and run in an isolated environment.

    Returns
    -------
    callable
        The memoized function.
    """

    def decorator(wrapped: W) -> W:
        check_true(
            str.isidentifier(wrapped.__qualname__),
            "Cannot construct cache location for {}".format(wrapped.__qualname__),
        )
        func_dir = os.path.join(cache_dir, wrapped.__module__, wrapped.__qualname__)
        logging.info("function cache location: {}".format(func_dir))
        sig = signature(wrapped)

        @functools.wraps(wrapped)
        def wrapper(*args, **kw):  # type: ignore
            binds = sig.bind(*args, **kw)
            call_sign = call_signer(binds)
            call_dir = os.path.join(func_dir, call_sign)
            if os.path.exists(call_dir):
                with open(os.path.join(call_dir, "args.pkl"), "rb") as argspkl:
                    check_eq(dill.load(argspkl), binds.arguments)
                with open(os.path.join(call_dir, "val.pkl"), "rb") as valpkl:
                    return dill.load(valpkl)

            check_true(build, "Cache miss and `build` is False")
            os.makedirs(call_dir)
            with open(os.path.join(call_dir, "args.pkl"), "wb") as argspkl:
                dill.dump(binds.arguments, argspkl, protocol=dill.HIGHEST_PROTOCOL)
            val = wrapped(*args, **kw)
            with open(os.path.join(call_dir, "val.pkl"), "wb") as valpkl:
                dill.dump(val, valpkl, protocol=dill.HIGHEST_PROTOCOL)
            return val

        return cast(W, wrapper)

    return decorator


def threadsafe_generator(fn: Callable[..., Any]) -> Callable[..., Any]:
    """A decorator that takes a generator function and makes it threadsafe.
    """

    class threadsafe_iter:
        def __init__(self, it: Iterator[Any]) -> None:
            self.it = it
            self.lock = threading.Lock()

        def __iter__(self) -> Iterator[Any]:
            return self

        def __next__(self) -> Any:
            with self.lock:
                return next(self.it)

    def g(*args: Any, **kwargs: Any) -> Any:
        return threadsafe_iter(fn(*args, **kwargs))

    return g


def list_to_dict(list_of_dicts: List[Dict[str, Any]]) -> Dict[str, List[Any]]:
    """Transpose list of dicts to dict of lists."""
    dict_of_lists = collections.defaultdict(list)  # type: Dict[str, List[Any]]
    for d in list_of_dicts:
        for key, value in d.items():
            dict_of_lists[key].append(value)
    return dict_of_lists


def coerce_to_valid_docker_name(x: str) -> str:
    return re.sub("[^a-zA-Z0-9_.-]", "-", x)


def decorate(obj: Any, name: str, func: Callable[[Any], Any]) -> None:
    """
    Change an attribute of an object by applying a function to it.
    """
    setattr(obj, name, func(getattr(obj, name)))
