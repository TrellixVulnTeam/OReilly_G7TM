# The container path where model packages are extracted.
MODEL_PACKAGES_CONTAINER_PATH = "/model_packages"

# The container path where the agent bind-mounts the custom Kerberos config
# file, if any.
KRB5_CONFIG_CONTAINER_PATH = "/etc/krb5.pedl.conf"

# The maximum size of a WebSocket message that can be sent or received
# by the PEDL agent and trial-runner. The master uses a different limit,
# because it uses the uwsgi WebSocket implementation; see
# `websocket-max-size` in `uwsgi.ini`.
MAX_WEBSOCKET_MSG_SIZE = 128 * 1024 * 1024

# The maximum HTTP request size that will be accepted by the master. This
# is intended as a safeguard to quickly drop overly large HTTP requests.
MAX_HTTP_REQUEST_SIZE = 128 * 1024 * 1024

# The maximum size of a model (the sum of the model definition plus any
# additional package dependencies). Models are created via HTTP and sent
# to agents via WebSockets; we also have to account for the overhead of
# base64 encoding. Models are also stored in Postgres but the max
# Postgres field size is 1GB, so we ignore that here.
MAX_ENCODED_SIZE = (min(MAX_WEBSOCKET_MSG_SIZE, MAX_HTTP_REQUEST_SIZE) // 8) * 6
# We subtract one megabyte to account for any message envelope size we may have.
MAX_CONTEXT_SIZE = MAX_ENCODED_SIZE - (1 * 1024 * 1024)

# The port to use (from the container's point of view; it will be mapped to
# some arbitrary port on the host) for communication across containers. Must
# match LocalRendezvousPort in master/internal/trial.go.
LOCAL_RENDEZVOUS_PORT = 1734

# The default docker repository for task environments.
TASK_ENV_REPO = "determinedai/task-environment"
