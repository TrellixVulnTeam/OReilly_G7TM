from typing import Any, Dict, List, Optional


class Device:
    """Represents a compute device (CPU or GPU)."""

    def __init__(self, id: int, brand: str, uuid: Optional[str], device_type: str) -> None:
        """
        Args:
            id: A numeric ID that identifies the device on a specific machine.
            uuid: An optional, globally unique identifier. GPUs have UUIDs, but
                we don't currently compute a UUID for CPUs.
            device_type: The type of the device ("gpu" or "cpu").
        """
        self.id = id
        self.brand = brand
        self.uuid = uuid
        self.device_type = device_type

    def __eq__(self, other: object) -> bool:
        if type(self) is not type(other):
            return False

        return self.__dict__ == other.__dict__

    def __json__(self) -> Dict[str, Any]:
        return {"id": self.id, "brand": self.brand, "uuid": self.uuid, "type": self.device_type}

    def __repr__(self) -> str:
        return "{}{} ({}{})".format(
            self.device_type, self.id, self.brand, ", {}".format(self.uuid) if self.uuid else ""
        )

    def type_and_id(self) -> str:
        return "{}{}".format(self.device_type, self.id)

    @staticmethod
    def from_json(dict: Dict[str, Any]) -> "Device":
        """Construct from deserialized JSON.

        Args:
            dict: A JSON object deserialized into a Python dict.

        Returns:
            A `Device`.
        """
        return Device(dict["id"], dict["brand"], dict["uuid"], dict["type"])

    @staticmethod
    def many_from_json(device_json: List[Dict[str, Any]]) -> List["Device"]:
        return [Device.from_json(d) for d in device_json]
