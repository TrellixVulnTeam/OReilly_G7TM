import logging
import os
import subprocess
import sys
from typing import Any, Dict

from pedl.constants import KRB5_CONFIG_CONTAINER_PATH

KRB_PRINCIPAL = "y.zimmerman@CRITEOIS.LAN"
KRB_PASSWORD = "DeterminedAI18+y"


def kerberos_enabled(config: Dict[str, Any]) -> bool:
    return "kerberos" in config.get("security", {})


def kerberos_init(config: Dict[str, Any]) -> None:
    if not kerberos_enabled(config):
        return

    # Support for custom Kerberos configuration file. The config file
    # path is a host path; the agent will bind-mount that config file
    # into the container at a predictable container path.
    krb_config = config.get("security", {}).get("kerberos", {})
    krb_config_file = krb_config.get("config_file")
    if krb_config_file is not None:
        logging.info("Using custom Kerberos config file")
        os.environ["KRB5_CONFIG"] = KRB5_CONFIG_CONTAINER_PATH

    # Attempt to get a TGT from Kerberos with a renewal time of one
    # week. Principal and password are hardcoded for now.
    kinit_cmd = ["/usr/bin/kinit", "-r", "168h", "-f", KRB_PRINCIPAL]
    proc = subprocess.Popen(
        kinit_cmd, stdout=subprocess.DEVNULL, stdin=subprocess.PIPE, stderr=subprocess.PIPE
    )
    proc.stdin.write(KRB_PASSWORD.encode())
    proc.stdin.close()
    proc.wait()

    if proc.returncode != 0:
        error_text = proc.stderr.read().decode()
        logging.error("Kerberos authentication failed: {}".format(error_text))
        sys.exit(1)

    logging.info("Kerberos authentication succeeded")


def kerberos_renew(config: Dict[str, Any]) -> None:
    if not kerberos_enabled(config):
        return

    try:
        subprocess.run(["kinit", "-R", KRB_PRINCIPAL], check=True, timeout=30)
    except subprocess.CalledProcessError as e:
        logging.exception("Failed to renew Kerberos ticket: {}".format(e))
        raise e

    logging.info("Successfully renewed Kerberos ticket")
