from collections import namedtuple

EnvContext = namedtuple(
    "EnvContext",
    [
        "master_addr",
        "master_port",
        "container_id",
        "experiment_config",
        "model_path",
        "hparams",
        "initial_workload",
        "latest_checkpoint",
        "use_gpu",
        "debug",
        "workload_manager_type",
        "pedl_rendezvous_ports",
        "pedl_trial_runner_network",
    ],
)


class SkipWorkloadException(Exception):
    """
    Exception that a Trial can raise in order to indicate to the harness that
    this phase can be skipped.
    """

    pass
