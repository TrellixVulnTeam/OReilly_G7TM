import fnmatch
import sys
import zipfile

script_name = "pedl-prepare-env.sh"
if len(sys.argv) > 1:
    script_name = sys.argv[1]

model_def = zipfile.ZipFile("/model_def", "r")
try:
    prepare_env_files = fnmatch.filter(model_def.namelist(), "*/" + script_name)
    sys.stdout.buffer.write(model_def.read(prepare_env_files[0]))
except (KeyError, IndexError):
    print(
        """#!/bin/bash
        echo "No {} found. Skipping..."
        """.format(
            script_name
        )
    )
