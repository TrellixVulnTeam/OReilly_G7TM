import importlib
import logging
import os
import sys
import tempfile
import zipfile
from typing import Any, Callable, Iterator, Optional, Set, Tuple, Type

from pedl.check import check_len, check_true
from pedl.harness import EnvContext
from pedl.trial import Trial


DataLoaders = Tuple[Any, Any]
ModelDefinition = Tuple[Type[Trial], Optional[Callable[[], DataLoaders]]]


def iter_subclasses(cls: type, _seen: Optional[Set] = None) -> Iterator[type]:
    """
    Generator over all subclasses of a given class, in depth first order.
    """
    if _seen is None:
        _seen = set()

    try:
        subs = cls.__subclasses__()
    except TypeError:
        # Special-case if invoked on the metaclass `type`.
        subs = type.__subclasses__(type)

    for sub in subs:
        if sub not in _seen:
            _seen.add(sub)
            yield sub
            yield from iter_subclasses(sub, _seen)


def import_model_definition(env: EnvContext) -> Any:
    with zipfile.ZipFile(env.model_path) as zf:
        # Use top-level directory as module name.
        dirnames = set()
        for name in zf.namelist():
            dirnames.add(name.split(os.sep)[0])
        check_len(dirnames, 1)
        module_name = next(iter(dirnames))

        module_path = tempfile.mkdtemp()
        zf.extractall(module_path)

    # Add both the path to the module and to the module name to allow
    # absolute imports from the model definition.
    sys.path.append(module_path)
    sys.path.append(os.path.join(module_path, module_name))
    return importlib.import_module(module_name)


def load_user_model_definition(env: EnvContext) -> ModelDefinition:
    """
    Load and initialize a ModelDefinition from a model definition zip file.
    """
    check_true(
        zipfile.is_zipfile(env.model_path),
        "Model definition is not a zip file: {}".format(env.model_path),
    )

    module = import_model_definition(env)

    # There might be multiple subclasses of Trial, but all pedl-defined
    # subclasses (except KerasSimpleTrial) should have abstract methods. The
    # reason we count abstract methods instead of using a try/except block is
    # that if we try to instantiate a class with incomplete methods, a very
    # generic TypeError is raised, and we can't catch that error without also
    # catching TypeErrors raised by user code.
    abstract_classes = []
    for trial_class in iter_subclasses(Trial):
        if trial_class.__abstractmethods__:  # type: ignore
            abstract_classes.append(trial_class)
            continue

        if trial_class.__name__ == "KerasSimpleTrial":
            continue

        make_data_loaders = getattr(module, "make_data_loaders", None)

        return (trial_class, make_data_loaders)

    logging.critical(
        "PEDL could not find a user-defined Trial subclass with no abstract "
        "methods in the provided model definition. If your model definition "
        "is a directory, please verify that you have imported your Trial "
        "subclass in a top-level __init__.py file and confirm that all "
        "necessary abstract methods have been implemented. Please see the "
        "'Model Definition' documentation for more information."
    )
    for c in abstract_classes:
        # Ignore PEDL-defined classes.
        if c.__module__.split(".")[0] == "pedl":
            continue

        abstract_methods = ", ".join(c.__abstractmethods__)  # type: ignore
        logging.critical(
            "Found user-defined class {}.{} with these abstract methods: {}".format(
                c.__module__, c.__qualname__, abstract_methods
            )
        )
    sys.exit(1)
