import logging
import math
import sys
from abc import ABCMeta, abstractmethod
from typing import Any, Dict, Optional

import numpy as np

import pedl
import pedl.storage
from pedl import Workload
from pedl.check import check_eq, check_issubclass, check_not_eq, check_not_none
from pedl.harness import EnvContext
from pedl.harness.load import load_user_model_definition
from pedl.storage import StorageMetadata
from pedl.trial import TrialController, validate_batch_metrics


class WorkloadManager(metaclass=ABCMeta):
    """
    WorkloadManager handles workload messages after they are received on the
    WebSocket. Each WorkloadManager may allow different workload messages.
    """

    def __init__(self, env: EnvContext) -> None:
        self.env = env

    @abstractmethod
    def run_workload(self, w: Workload) -> Dict[str, Any]:
        pass


def build_workload_manager(env: EnvContext) -> WorkloadManager:
    """
    Build the WorkloadManager as specified by the container environment.
    """
    if env.workload_manager_type == "TRIAL_WORKLOAD_MANAGER":
        return TrialWorkloadManager(env)
    raise ValueError("Unexpected workload manager type: {}", env.workload_manager_type)


class TrialWorkloadManager(WorkloadManager):
    def __init__(self, env: EnvContext) -> None:
        super().__init__(env)
        self.workload = None  # type: Optional[Workload]
        # TODO(ryan): Remove the last two pieces of lazy initialization, which are loading the
        # model and setting the rendezvous information. Then initialize the controller here.
        self.controller = None  # type: Optional[TrialController]

        checkpoint_storage = self.env.experiment_config["checkpoint_storage"]
        self.checkpoint_manager = pedl.storage.build(checkpoint_storage)

    def prepare_controller(self) -> None:
        # KerasSimpleTrial must be treated specially.
        if self.env.experiment_config.get("entrypoint"):
            from pedl.frameworks.keras.keras_simple_trial import load_keras_simple_trial

            self.controller = load_keras_simple_trial(
                self.env, self.env.model_path, self.env.experiment_config["entrypoint"]
            )
        else:
            trial_class, make_data_loaders = load_user_model_definition(self.env)
            # TODO(ryan): is_warmstart is probably not the right name here, but because I'm not
            # sure what the right behavior should be (see DET-836) I'm not sure what to call this.
            is_warmstart = (
                self.env.latest_checkpoint is not None and self.env.initial_workload.step_id == 1
            )
            # Get the TrialController from the Trial class.
            controller_class = trial_class.trial_controller_class
            check_not_none(
                controller_class,
                "The class attribute `trial_controller_class` of {} is None; please set it the "
                "correct subclass of `pedl.trial.TrialController`".format(trial_class.__name__),
            )
            check_issubclass(
                controller_class,
                TrialController,
                "The class attribute `trial_controller_class` of {} is not a valid subclass of "
                "`pedl.trial.TrialController`".format(trial_class.__name__),
            )
            assert controller_class is not None
            assert issubclass(controller_class, TrialController)

            self.controller = controller_class(
                trial_class, self.env.hparams, self.env, is_warmstart, make_data_loaders
            )

    def run_workload(self, w: Workload) -> Dict[str, Any]:
        logging.info("Running workload {}".format(w))
        self.check_sane_workload(w)

        # If this is the initial workload, we first instantiate the trial controller and we might
        # need to restore the trial from its most recent checkpoint.
        if self.workload is None:
            self.prepare_controller()
            if self.env.latest_checkpoint is not None:
                self.restore_checkpoint()

        self.workload = w

        if w.kind == Workload.Kind.RUN_STEP:
            return self.train_for_step(w)
        elif w.kind == Workload.Kind.COMPUTE_VALIDATION_METRICS:
            return self.compute_validation_metrics(w)
        elif w.kind == Workload.Kind.CHECKPOINT_MODEL:
            return self.checkpoint_model(w)
        else:
            raise AssertionError("Unexpected workload: {}".format(w.kind))

    def check_sane_workload(self, new_workload: Workload) -> None:
        # If this is the initial workload, we don't expect to start with
        # a checkpoint operation. All other workloads are reasonable.
        if self.workload is None:
            check_not_eq(new_workload.kind, Workload.Kind.CHECKPOINT_MODEL)
            return

        # If this is not the initial workload, it should be compatible
        # with the previous workload that ran in this container.
        check_eq(self.workload.trial_id, new_workload.trial_id)

        if new_workload.kind == Workload.Kind.RUN_STEP:
            check_eq(self.workload.step_id + 1, new_workload.step_id)
        else:
            check_eq(self.workload.step_id, new_workload.step_id)

    def train_for_step(self, workload: Workload) -> Dict[str, Any]:
        start_time = pedl.current_timestamp()

        assert self.controller is not None

        for callback in self.controller.callbacks:
            if workload.step_id == 1:
                callback.on_trial_begin()
            callback.on_train_step_begin(workload.step_id)

        num_batches = self.env.experiment_config.get("batches_per_step", 100)
        metrics = self.controller.train_for_step(workload.step_id, num_batches)

        # Sanity-check training metrics.
        batch_metrics = metrics["batch_metrics"]

        for callback in self.controller.callbacks:
            callback.on_train_step_end(workload.step_id, batch_metrics)

        # Sanity-check training metrics.
        validate_batch_metrics(batch_metrics)

        return {
            "type": "WORKLOAD_COMPLETED",
            "workload": workload,
            "start_time": start_time,
            "end_time": pedl.current_timestamp(),
            "metrics": metrics,
        }

    def compute_validation_metrics(self, workload: Workload) -> Dict[str, Any]:
        start_time = pedl.current_timestamp()

        assert self.controller is not None

        for callback in self.controller.callbacks:
            callback.on_validation_step_begin(workload.step_id)

        metrics = self.controller.compute_validation_metrics(workload.step_id)

        v_metrics = metrics["validation_metrics"]
        for callback in self.controller.callbacks:
            callback.on_validation_step_end(workload.step_id, v_metrics)

        # Check that the validation metrics computed by the model code
        # includes the metric used by the search method.
        searcher_metric = self.env.experiment_config["searcher"]["metric"]
        if searcher_metric not in v_metrics:
            logging.critical(
                "Search method is configured to use metric '{}' but model "
                "definition returned validation metrics {}. The metric "
                "used by the search method must be one of the validation "
                "metrics returned by the model definition.".format(
                    searcher_metric, list(v_metrics.keys())
                )
            )
            sys.exit(1)

        non_serializable_metrics = set()
        # NaN and bytes are not JSON serializable. None does not have a
        # canonical JSON representation. In the case of trial implementation bugs
        # or numerical instability issues, validation metric functions may
        # return None or NaN values. For now, immediately fail any trial that
        # encounters such a metric. Model validation may return fields with
        # byte values. For now, drop the byte fields and notify the user.
        for metric_name, metric_value in v_metrics.items():
            metric_is_none = metric_value is None
            metric_is_nan = isinstance(metric_value, (float, int, np.number)) and math.isnan(
                metric_value
            )

            if metric_is_none or metric_is_nan:
                logging.critical(
                    "Validation metric '{}' returned "
                    "an invalid scalar value: {}".format(metric_name, metric_value)
                )
                sys.exit(1)

            if isinstance(metric_value, (bytes, bytearray)):
                non_serializable_metrics.add(metric_name)

        if len(non_serializable_metrics):
            logging.warn(
                "Removed non serializable metrics: %s", ", ".join(non_serializable_metrics)
            )
            for metric_name in non_serializable_metrics:
                del v_metrics[metric_name]

        return {
            "type": "WORKLOAD_COMPLETED",
            "workload": workload,
            "start_time": start_time,
            "end_time": pedl.current_timestamp(),
            "metrics": metrics,
        }

    def restore_checkpoint(self) -> None:
        metadata = StorageMetadata.from_json(self.env.latest_checkpoint)
        logging.info("Restoring trial from checkpoint {}".format(metadata.storage_id))

        assert self.controller is not None

        self.checkpoint_manager.restore(self.controller, metadata)

        logging.info("Restored trial from checkpoint {}".format(metadata.storage_id))

    def checkpoint_model(self, workload: Workload) -> Dict[str, Any]:
        start_time = pedl.current_timestamp()

        assert self.controller is not None

        metadata = self.checkpoint_manager.store(self.controller)
        logging.info("Saved trial to checkpoint {}".format(metadata.storage_id))

        metadata.labels = {
            "experiment_id": str(workload.experiment_id),
            "trial_id": str(workload.trial_id),
            "step_id": str(workload.step_id),
        }

        return {
            "type": "WORKLOAD_COMPLETED",
            "workload": workload,
            "start_time": start_time,
            "end_time": pedl.current_timestamp(),
            "metrics": metadata,
        }
