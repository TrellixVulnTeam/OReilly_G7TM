"""The entrypoint for the isolated environment we use to run trials.

Basic workflow is:
  * Agent launches a new container that has this script as its
    entrypoint. The agent passes along various parameters (e.g., master
    address, workload) via environment variables.

  * The script establishes a WebSocket connection back to the master,
    and sends a TRIAL_RUNNER_STARTUP message including the container's
    initial workload. We then start running the specified workload.

  * When the initial workload is complete, the trial runner notifies the
    master via a WORKLOAD_COMPLETED message.

  * The master sends a RUN_WORKLOAD message to the trial runner to ask
    it to do some work, e.g., run a step of the current trial,
    checkpoint the model to persistent storage, or compute the model's
    current validation metrics. This can happen many times to run multiple
    steps of the same trial in a row.

  * Eventually, the master asks the trial runner to exit via a TERMINATE
    message.

"""
import logging
import os
import subprocess
import sys
import tarfile
import zipfile
from typing import Any, Dict

import lomond
import simplejson

import pedl
import pedl.storage
from pedl import Workload
from pedl._json import json_encode
from pedl.check import check_true
from pedl.constants import LOCAL_RENDEZVOUS_PORT
from pedl.env import VersionNone
from pedl.harness import EnvContext, SkipWorkloadException
from pedl.harness.auth import kerberos_init, kerberos_renew
from pedl.harness.harness_profiler import HarnessProfiler
from pedl.harness.workload_manager import build_workload_manager


def install_local_packages(packages_path: str) -> None:
    """
    Given a path to a directory containing package archives, install each
    package using pip. Uses subprocess.check_call to install package archives,
    as recommended by the pip documentation [1].

    [1] https://pip.pypa.io/en/latest/user_guide/#using-pip-from-your-program
    """
    for package in os.listdir(packages_path):
        package_path = os.path.join(packages_path, package)
        check_true(
            (zipfile.is_zipfile(package_path) or tarfile.is_tarfile(package_path)),
            "Package must be a file: {}".format(package_path),
        )
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_path])


def send_msg(socket: Any, msg: Dict[str, Any]) -> None:
    socket.send_text(json_encode(msg))


class SocketManager:
    """
    SocketManager handles WebSocket-related events common to any harness.
    Workload messages, which may vary in type depending on the task being run,
    are passed to the WorkloadManager.
    """

    def __init__(self, env: EnvContext) -> None:
        self.env = env
        self.workload_manager = build_workload_manager(env)
        self.url = "ws://{}:{}/ws/trial/{}/{}/{}".format(
            env.master_addr,
            env.master_port,
            env.initial_workload.experiment_id,
            env.initial_workload.trial_id,
            env.container_id,
        )

    def start(self) -> None:
        socket = lomond.WebSocket(self.url)

        for event in socket.connect(ping_rate=0):
            try:
                self.handle_event(event, socket)
            except Exception:
                logging.exception("Exception handling event %s", event)
                socket.close()
                raise

    def handle_event(self, event: Any, socket: Any) -> None:
        if isinstance(event, lomond.events.Connecting):
            logging.info("Connecting to master at %s", event.url)
        elif isinstance(event, lomond.events.Connected):
            logging.info("Connected to master")
        elif isinstance(event, lomond.events.ConnectFail):
            logging.warning("Failed to connect to master: %s", event.reason)
        elif isinstance(event, lomond.events.Closing):
            logging.info("Server started WebSocket shutdown: %s", event.reason)
        elif isinstance(event, lomond.events.Disconnected):
            # The event loop will exit after this event is received.
            if event.graceful:
                logging.info("Disconnected from master, exiting gracefully")
            else:
                logging.warning("Disconnected from master abruptly: %s", event.reason)
        elif isinstance(event, lomond.events.ProtocolError):
            logging.warning("WebSocket protocol error: %s", event.error)
        elif isinstance(event, lomond.events.Rejected):
            logging.warning("Master rejected WebSocket: %s", event.reason)
        elif isinstance(event, lomond.events.Ready):
            logging.info("Established WebSocket session with master")
        elif isinstance(event, lomond.events.Text):
            msg = simplejson.loads(event.text)

            if msg["type"] == "TERMINATE":
                logging.info("Received termination request from master")
                socket.close()
            elif msg["type"] == "RENDEZVOUS_INFO":
                logging.info("Got rendezvous information: %s", msg)

                # If there's only one container, there's nothing to do for
                # rendezvous.
                addrs, rank = msg["addrs"], msg["rank"]
                addrs2 = msg["addrs2"]

                # The rendezvous info contains the external addresses for
                # all the containers, but we need to set what to actually
                # bind to inside this container. We just bind to the
                # wildcard interface, on a fixed port that matches the one
                # the agent is hardcoded to expose in all trial containers.
                # TODO(DET-916): Make number of ports configurable.
                rendezvous_ports = [int(x) for x in self.env.pedl_rendezvous_ports.split(",")]
                if len(rendezvous_ports) != 2:
                    logging.warning(
                        "PEDL_RENDEZVOUS_PORTS not set, falling back on LOCAL_RENDEZVOUS_PORTS"
                    )
                    rendezvous_ports = [LOCAL_RENDEZVOUS_PORT, LOCAL_RENDEZVOUS_PORT + 1]
                addrs[rank] = "0.0.0.0:{}".format(rendezvous_ports[0])
                addrs2[rank] = "0.0.0.0:{}".format(rendezvous_ports[1])

                os.environ["PEDL_RENDEZVOUS_INFO"] = simplejson.dumps(
                    {"addrs": addrs, "addrs2": addrs2, "rank": rank}
                )

                self.run_workload(self.env.initial_workload, socket)
            elif msg["type"] == "RUN_WORKLOAD":
                workload = Workload.from_json(msg["workload"])
                self.run_workload(workload, socket)
            else:
                raise NotImplementedError("Unrecognized message: {}".format(msg))

    def run_workload(self, workload: Workload, socket: Any) -> None:
        if self.env.debug:
            logging.debug("Starting profiler...")
            profiler = HarnessProfiler(use_gpu=self.env.use_gpu)
            profiler.start()

        try:
            result = self.workload_manager.run_workload(workload)
        except SkipWorkloadException:
            logging.info("Skipping workload: {}".format(workload))
        except StopIteration as s:
            # Raising a StopIteration from this function would make the event
            # loop raise a different exception, thereby masking the original
            # one; we instead raise an exception with the original traceback
            # but a different type so that it makes it to the logs.
            raise Exception("Workload raised a StopIteration", *s.args).with_traceback(
                s.__traceback__
            ) from None
        else:
            duration = result["end_time"] - result["start_time"]
            logging.info(
                "Workload completed: {} (duration {})".format(result["workload"], duration)
            )

            send_msg(socket, result)

            # We need to renew the Kerberos ticket periodically; for now, we
            # do so after every completed workload. This should be refined.
            kerberos_renew(self.env.experiment_config)

        if self.env.debug:
            profiler.stop()
            profiler.serialize_raw_results(
                "/tmp/step-{}-{}.json".format(workload.step_id, workload.kind)
            )
            profiler.serialize_graph("/tmp/step-{}-{}.png".format(workload.step_id, workload.kind))


def main() -> None:
    keys = {
        "PEDL_MASTER_ADDR",
        "PEDL_MASTER_PORT",
        "PEDL_AGENT_ID",
        "PEDL_SLOT_IDS",
        "PEDL_CONTAINER_ID",
        "PEDL_USE_GPU",
        "PEDL_EXPERIMENT_ID",
        "PEDL_TRIAL_ID",
        "PEDL_TRIAL_SEED",
        "PEDL_EXPERIMENT_CONFIG",
        "PEDL_MODEL_PATH",
        "PEDL_HPARAMS",
        "PEDL_INITIAL_WORKLOAD",
        "PEDL_LATEST_CHECKPOINT",
        "PEDL_WORKLOAD_MANAGER_TYPE",
        "PEDL_RENDEZVOUS_PORTS",
        "PEDL_TRIAL_RUNNER_NETWORK",
    }
    for k in keys:
        if k not in os.environ:
            sys.exit("Environment not set: missing " + k)

    experiment_config = simplejson.loads(os.environ["PEDL_EXPERIMENT_CONFIG"])
    debug = experiment_config.get("environment", {}).get("debug", VersionNone) != VersionNone
    log_level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=log_level, format="%(asctime)s:%(levelname)s: %(message)s")

    master_addr = os.environ["PEDL_MASTER_ADDR"]
    master_port = int(os.environ["PEDL_MASTER_PORT"])
    agent_id = os.environ["PEDL_AGENT_ID"]
    slot_ids = simplejson.loads(os.environ["PEDL_SLOT_IDS"])
    container_id = os.environ["PEDL_CONTAINER_ID"]
    model_path = os.environ["PEDL_MODEL_PATH"]
    hparams = simplejson.loads(os.environ["PEDL_HPARAMS"])
    initial_work = Workload.from_json(simplejson.loads(os.environ["PEDL_INITIAL_WORKLOAD"]))
    latest_checkpoint = simplejson.loads(os.environ["PEDL_LATEST_CHECKPOINT"])
    use_gpu = os.environ["PEDL_USE_GPU"] == "True"
    workload_manager_type = os.environ["PEDL_WORKLOAD_MANAGER_TYPE"]
    pedl_rendezvous_ports = os.environ["PEDL_RENDEZVOUS_PORTS"]
    pedl_trial_runner_network = os.environ["PEDL_TRIAL_RUNNER_NETWORK"]

    if use_gpu:
        # Sanity check: if this trial is expected to run on the GPU but
        # no GPUs are available, this indicates a misconfiguration.
        import GPUtil

        gpu_list = GPUtil.getGPUs()
        if len(gpu_list) == 0:
            sys.exit("Failed to find GPUs for GPU-only trial")

    logging.info(
        "==========================================================\n"
        "New trial runner: agent {}, slots {}, "
        "container ID {}, initial workload {}".format(
            agent_id, slot_ids, container_id, initial_work
        )
    )

    env = EnvContext(
        master_addr,
        master_port,
        container_id,
        experiment_config,
        model_path,
        hparams,
        initial_work,
        latest_checkpoint,
        use_gpu,
        debug,
        workload_manager_type,
        pedl_rendezvous_ports,
        pedl_trial_runner_network,
    )

    kerberos_init(env.experiment_config)

    try:
        pedl.storage.validate(env.experiment_config["checkpoint_storage"])
    except Exception as e:
        logging.error("Checkpoint storage validation failed: {}".format(e))
        sys.exit(1)

    # Install local packages, if any exist.
    install_local_packages(pedl.constants.MODEL_PACKAGES_CONTAINER_PATH)

    # TODO: Consider connecting to the master before we startup the
    # StepManager (#272).
    mgr = SocketManager(env)
    mgr.start()


if __name__ == "__main__":
    main()
