import argparse
import json
import logging
import os
import sys
from typing import Any, Dict, Generator, List

import numpy as np
import tensorflow as tf


def progressbar(percentage: float, width: int = 100) -> None:
    prog = round(percentage * width)
    bar = "=" * prog
    space = " " * (width - prog)
    pcent = round(percentage * 100)
    print("[{}{}] {:3d}%".format(bar, space, pcent))


def maybe_write_metric(metric_key: str, metric_val: Any, step: int, writer: Any) -> None:
    # For now, we only log scalar metrics.
    if not isinstance(metric_val, (float, int, np.number)):
        return

    summary = tf.Summary()
    summary_value = summary.value.add()
    summary_value.tag = metric_key
    summary_value.simple_value = metric_val
    writer.add_summary(summary, step)


def write_training_metrics(
    writer: Any, step_id: int, batches_per_step: int, metrics: List[Dict[str, Any]]
) -> None:
    assert step_id > 0
    first_batch_in_step = (step_id - 1) * batches_per_step
    for batch_idx, batch_metrics in enumerate(metrics):
        batches_seen = first_batch_in_step + batch_idx
        for tag, value in batch_metrics.items():
            maybe_write_metric(tag, value, batches_seen, writer)


def write_validation_metrics(
    writer: Any, step_id: int, batches_per_step: int, metrics: Dict[str, Any]
) -> None:
    batches_seen = step_id * batches_per_step
    if "validation_metrics" in metrics and metrics["validation_metrics"] is not None:
        for metric_name, metric_value in metrics["validation_metrics"].items():
            maybe_write_metric(metric_name, metric_value, batches_seen, writer)


def write_trial_metrics(
    logdir: str, trial: Dict[str, Any], exp_config: Dict[str, Any]
) -> Generator:
    trial_dir = "trial_" + str(trial["id"])

    training_writer = tf.summary.FileWriter(os.path.join(logdir, "training", trial_dir), None)

    validation_writer = tf.summary.FileWriter(os.path.join(logdir, "validation", trial_dir), None)

    batches_per_step = exp_config.get("batches_per_step", 100)

    for step in trial["steps"]:
        if step["metrics"] is None:
            logging.warning("Step %d of trial %d does not contain metrics", step["id"], trial["id"])
        elif step["metrics"]["batch_metrics"] is None:
            logging.warning(
                "Step %d of trial %d does not contain batch metrics", step["id"], trial["id"]
            )
        else:
            batch_metrics = step["metrics"]["batch_metrics"]
            write_training_metrics(training_writer, step["id"], batches_per_step, batch_metrics)

            if step["validation"] is not None:
                validation_metrics = step["validation"].get("metrics")
                if validation_metrics is not None:
                    write_validation_metrics(
                        validation_writer, step["id"], batches_per_step, validation_metrics
                    )
        yield
    training_writer.flush()
    validation_writer.flush()


def main(argv: List[str]) -> None:
    parser = argparse.ArgumentParser(description="PEDL tensorboard")

    parser.add_argument(
        "--log-level",
        default=os.getenv("PEDL_LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Set the logging level",
    )

    parser.add_argument(
        "--logdir",
        type=str,
        default=os.getenv("PEDL_TENSORBOARD_DIR", "/tmp/pedl-tensorboard"),
        help="Directory to write tensorboard logs to",
    )

    parser.add_argument(
        "--master", default=os.getenv("PEDL_MASTER_ADDR", "localhost:8080"), help="master address"
    )

    args = parser.parse_args(argv)

    logging.basicConfig(
        level=args.log_level, format="%(asctime)s:%(module)s:%(levelname)s: %(message)s"
    )

    task_id = os.getenv("PEDL_TASK_ID")
    if task_id is None:
        logging.error("PEDL_TASK_ID is unset")
        sys.exit(1)

    with open("/etc/tensorboard_data.json") as f:
        tensorboard_data = json.load(f)

    experiment_configs = tensorboard_data["experiment_configs"]
    trial_metrics = tensorboard_data["trial_metrics"]

    total_steps = 0
    active_trials = []
    for trial in trial_metrics:
        total_steps = total_steps + len(trial["steps"])
        if trial["state"] == "ACTIVE":
            active_trials.append(str(trial["id"]))

    if len(active_trials):
        logging.warn(
            "The following trials are active. Tensorboard will show "
            "a static snapshot of trial metrics at this time and "
            "will not update."
        )
        logging.warn("Active Trial IDs: %s", " ".join(active_trials))

    print("Writing {} trial metrics to TensorBoard".format(len(tensorboard_data["trial_metrics"])))

    curr_step = 0
    for trial in tensorboard_data["trial_metrics"]:
        experiment_config = experiment_configs[str(trial["experiment_id"])]
        for _ in write_trial_metrics(args.logdir, trial, experiment_config):
            curr_step = curr_step + 1
            progressbar(curr_step / total_steps, 50)

    print("TensorBoard log writing complete")


if __name__ == "__main__":
    main(sys.argv[1:])
