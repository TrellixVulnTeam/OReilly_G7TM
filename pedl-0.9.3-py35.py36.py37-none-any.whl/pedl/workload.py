from enum import Enum, unique
from typing import Any, Dict

from pedl._types import ExperimentID, StepID, TrialID
from pedl.check import check_in


class Workload:
    @unique
    class Kind(Enum):
        RUN_STEP = 1
        COMPUTE_VALIDATION_METRICS = 2
        CHECKPOINT_MODEL = 3

    def __init__(self, kind: Kind, e_id: ExperimentID, t_id: TrialID, s_id: StepID) -> None:
        self.kind = kind
        self.experiment_id = e_id
        self.trial_id = t_id
        self.step_id = s_id

    def __eq__(self, other: object) -> bool:
        if type(self) is not type(other):
            return False

        return self.__dict__ == other.__dict__

    def __hash__(self) -> int:
        return hash((self.kind, self.experiment_id, self.trial_id, self.step_id))

    def __repr__(self) -> str:
        return "<{}: ({},{},{})>".format(
            self.kind.name, self.experiment_id, self.trial_id, self.step_id
        )

    def __json__(self) -> Dict[str, Any]:
        return self.__dict__

    @staticmethod
    def from_json(dict: Dict[str, Any]) -> "Workload":
        check_in(dict["kind"], Workload.Kind.__members__)
        return Workload(
            Workload.Kind[dict["kind"]], dict["experiment_id"], dict["trial_id"], dict["step_id"]
        )
