import ast
import atexit
import logging
import os
import shutil
import tempfile
from abc import ABCMeta, abstractmethod
from typing import Any, Callable, cast, Dict, List, Optional, Tuple, Type, Union

import numpy as np
import simplejson

from pedl import Workload
from pedl._types import StepID
from pedl.callback import Callback
from pedl.check import check_eq, check_false, check_isinstance, check_len, check_true, check_type
from pedl.data import BatchLoader
from pedl.harness import EnvContext, SkipWorkloadException
from pedl.storage import Storable
from pedl.util import list_to_dict


# Useful type aliases for framework trial subclasses.
MetricOp = Callable[[Any, Any], Any]
Reducer = Callable[[List[Any]], Any]
ValidOp = Union[MetricOp, Tuple[MetricOp, Reducer]]


def get_container_gpus() -> List[str]:
    """Returns a list of the GPU devices visible to the container."""
    use_gpu = bool(ast.literal_eval(os.environ.get("PEDL_USE_GPU", "''")))
    if not use_gpu:
        return []
    return os.environ["NVIDIA_VISIBLE_DEVICES"].split(",")


def get_trial_seed() -> int:
    """Returns the trial seed."""
    return int(os.environ["PEDL_TRIAL_SEED"])


def _get_rendezvous_info() -> Dict[str, Any]:
    """Returns the distributed training rendezvous information."""
    info_key = "PEDL_RENDEZVOUS_INFO"
    if info_key not in os.environ:
        return {}
    return cast(Dict[str, Any], simplejson.loads(os.environ[info_key]))


def get_rank() -> int:
    """Returns the distributed training rank information."""
    info = _get_rendezvous_info()
    return info.get("rank", 0)


def get_gang_addrs() -> List[str]:
    """Returns the addresses of all the gang members."""
    info = _get_rendezvous_info()
    return info.get("addrs", [])


def get_gang_addrs2() -> List[str]:
    """Returns the addresses of all the gang members."""
    info = _get_rendezvous_info()
    return info.get("addrs2", [])


def validate_batch_metrics(batch_metrics: List[Dict[str, Any]]) -> None:
    metric_dict = list_to_dict(batch_metrics)

    # We expect that every batch has a metric named "loss".
    check_true(
        any(v for v in metric_dict if v.startswith("loss")),
        "model did not compute 'loss' training metric",
    )

    # We expect that all batches have the same set of metrics.
    metric_dict_keys = metric_dict.keys()
    for idx, metric_dict in zip(range(len(batch_metrics)), batch_metrics):
        keys = metric_dict.keys()
        if metric_dict_keys == keys:
            continue

        check_eq(metric_dict_keys, keys, "inconsistent training metrics: index: {}".format(idx))


def make_metrics(num_inputs: Optional[int], batch_metrics: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Make metrics dict including aggregates given individual data points."""

    metric_dict = list_to_dict(batch_metrics)
    validate_batch_metrics(batch_metrics)

    avg_metrics = {}  # type: Dict[str, Optional[float]]
    for name, values in metric_dict.items():
        m = None  # type: Optional[float]
        try:
            m = np.mean(values)
        except (TypeError, ValueError):
            # If we get here, values are non-scalars, which cannot be averaged.
            # We keep the key so consumers can see all the metric names but
            # leave the value as None.
            pass
        avg_metrics[name] = m

    metrics = {"batch_metrics": batch_metrics, "avg_metrics": avg_metrics}
    if num_inputs is not None:
        metrics["num_inputs"] = num_inputs

    return metrics


class Trial(metaclass=ABCMeta):
    """Abstract base class for trials.

    A Trial is essentially a collection of user hooks that will be called by the TrialController.
    Frameworks should create framework-specific subclasses to specify framework-specific hooks.
    """

    trial_controller_class = None  # type: Optional[Type[TrialController]]
    """trial_controller_class specifies the subclass of TrialController that is appropriate for a
    given sublcass of Trial.
    """

    def __init__(self, hparams: Dict[str, Any], *_: Any, **__: Any) -> None:
        logging.warning(
            "Calling super().__init__() in a Trial class is deprecated. Please keep track of "
            "the hparams argument manually."
        )
        self._hparams = hparams

    def callbacks(self, hparams: Dict[str, Any]) -> List[Callback]:
        """Returns a list of callbacks that can be used to run arbitrary
        functions during the lifetime of a PEDL trial. If multiple callbacks
        are specified to be invoked at the same time, they will be executed
        in the ordering specified by this list.

        See the documentation in :class:`pedl.callback.Callback` for more
        details.
        """
        return []


class TrialController(Storable, metaclass=ABCMeta):
    """Abstract base class for trial controllers.

    Frameworks should create framework-specific subclasses and implement
    :func:`train_for_step`, :func:`compute_validation_metrics`,
    :func:`set_random_seed`, :func:`save_framework_checkpoint`, and
    :func:`load_framework_checkpoint`.
    """

    def __init__(
        self,
        trial_class: Type[Trial],
        hparams: Dict[str, Any],
        env: EnvContext,
        is_warmstart: bool,
        make_data_loaders: Optional[Callable],
    ) -> None:
        """The base TrialController.__init__() does a variety of standard things that most
        framework-specific TrialController classes will use, such as:
        - storing the env and hparams
        - instantiating the user's Trial subclass
        - calling make_data_loaders (if present)

        Therefore, TrialController subclasses should call super().__init__() early in their own
        __init__() methods.
        """
        self.trial_class = trial_class
        self.hparams = hparams
        self.env = env
        self.is_warmstart = is_warmstart
        self.make_data_loaders = make_data_loaders
        # Set the random seed before instantiating any objects from user code.
        self.set_random_seed(get_trial_seed())

        self.trial = trial_class(hparams)

        self.callbacks = self.trial.callbacks(hparams)
        check_type(
            self.callbacks,
            list,
            "Please modify your model definition's callbacks() implementation.",
        )
        for callback in self.callbacks:
            check_isinstance(
                callback,
                Callback,
                "Please modify your model definition's callbacks() implementation.",
            )

        self.data_loaders = None  # Optional[Tuple[Any, Any]]
        if make_data_loaders is not None:
            self.data_loaders = make_data_loaders(env.experiment_config, hparams)
            check_isinstance(  # type: ignore
                self.data_loaders,
                (tuple, list),
                "make_data_loaders() must return a tuple or list of two data loaders, please "
                "edit your model definition's make_data_loaders().",
            )
            check_len(
                self.data_loaders,
                2,
                "make_data_loaders() must return a tuple or list of two data loaders, please "
                "edit your model definition's make_data_loaders().",
            )

        if TrialController.is_distributed_trial(env):
            check_true(
                self.supports_distributed_training(),
                "Distributed multi-machine training is not supported for this "
                "framework interface. Please set slots_per_task = 1 or "
                "distributed = false.",
            )

        if self.env.pedl_trial_runner_network != "host":
            check_false(
                self.requires_host_mode_networking(),
                "Distributed multi-machinetraining for this framework requires "
                "DISTRIBUTED_TRIAL_RUNNER_NETWORK to be set to host.",
            )

    # Methods implemented by AF-specific subclasses.
    @abstractmethod
    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        """Runs a trial for one step, which should consist of the training
        the model on the given number of batches.  Implemented by frameworks.

        Args:
            step_id: The index of the step to run.  This controls which batches
                to run.
            batches_per_step: How many batches per step to run.
            batch_loader: The training batch loader instance. Depending on the
                framework implementation, a batch loader may or may not be
                needed.

        Returns:
            The training metrics computed for each batch in the step.
        """
        pass

    @abstractmethod
    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        """Computes validation metrics for a trial given the current
        trial state.  Implemented by frameworks.

        Args:
            step_id: The index of the step to run.
            batch_loader: The validation batch loader instance. Depending on
                the framework implementation, a batch loader may or may not be
                needed.

        Returns:
            The validation metrics.
        """
        pass

    @abstractmethod
    def set_random_seed(self, trial_seed: int) -> None:
        """Seed all pseudo random number generators with the provided trial
        seed. Implemented by frameworks.

        Args:
            trial_seed: An integer in the range [0, 2^31)
        """
        pass

    @abstractmethod
    def save_framework_checkpoint(self, path: str) -> None:
        """Saves the current model state to persistent storage. Implemented by
        frameworks. Used by :func:`save()`.

        Args:
            path: A directory on the container file system; the trial
                should create the directory and checkpoint its current
                state into one or more files inside that directory. The
                implementation of this function creates `path`; hence,
                it should not exist before this function is called.
        """
        pass

    @abstractmethod
    def load_framework_checkpoint(self, path: str) -> None:
        """Loads the current model state from persistent storage. Implemented
        by frameworks. Used by :func:`load()`.

        Args:
            path: A directory on the container file system.
        """
        pass

    def set_data_loaders(self, data_loaders: Optional[Tuple[BatchLoader, BatchLoader]]) -> None:
        """Trial subclasses which require data loaders will store them for
        fetching training and validation. Trials which are not based on
        data loaders can ignore this call.
        """
        pass

    def save(self, path: str) -> None:
        self.save_framework_checkpoint(path)
        for c in self.callbacks:
            c.save(path)

    def load(self, path: str) -> None:
        self.load_framework_checkpoint(path)
        for c in self.callbacks:
            c.load(path)

    @staticmethod
    def is_distributed_trial(env: EnvContext) -> bool:
        if env.experiment_config is None:
            return False

        if (
            env.experiment_config.get("resources", {}).get("distributed", False)
            and env.experiment_config.get("resources", {}).get("slots_per_trial", 1) > 1
        ):
            return True

        return False

    @staticmethod
    def requires_host_mode_networking() -> bool:
        return False

    def initialize(self, env: EnvContext) -> None:
        """
        Internal method to save the EnvContext that created this trial.
        """
        self.env = env

        if self.is_distributed_trial(env):
            check_true(
                self.supports_distributed_training(),
                "Distributed multi-machine training is not supported for this "
                "framework interface. Please set slots_per_task = 1 or "
                "distributed = false.",
            )

        if self.env.pedl_trial_runner_network != "host":
            check_false(
                self.requires_host_mode_networking(),
                "Distributed multi-machinetraining for this framework requires "
                "DISTRIBUTED_TRIAL_RUNNER_NETWORK to be set to host.",
            )

    @staticmethod
    def supports_distributed_training() -> bool:
        return False

    @staticmethod
    def make_data_loaders_in_main_process() -> bool:
        return True


class CoordinatingTrialController(TrialController):
    """
    CoordinatingTrialController is an abstract base class for trials that need to start a separate
    process to run the actual workloads and only do minimal communication work in
    the main harness process.

    CoordinatingTrialController.__init__() does not instantiate dataloaders in the main process.
    """

    def __init__(
        self,
        trial_class: Type[Trial],
        hparams: Dict[str, Any],
        env: EnvContext,
        is_warmstart: bool,
        make_data_loaders: Optional[Callable],
        *make_subprocess_args: Any,
    ) -> None:
        self.trial_class = trial_class
        self.hparams = hparams
        self.env = env
        self.is_warmstart = is_warmstart
        self.make_data_loaders = make_data_loaders
        # Set the random seed before instantiating any objects from user code.
        self.set_random_seed(get_trial_seed())

        self.trial = trial_class(hparams)

        self.callbacks = self.trial.callbacks(hparams)
        check_type(
            self.callbacks,
            list,
            "Please modify your model definition's callbacks() implementation.",
        )
        for callback in self.callbacks:
            check_isinstance(
                callback,
                Callback,
                "Please modify your model definition's callbacks() implementation.",
            )

        if TrialController.is_distributed_trial(env):
            check_true(
                self.supports_distributed_training(),
                "Distributed multi-machine training is not supported for this "
                "framework interface. Please set slots_per_task = 1 or "
                "distributed = false.",
            )

        if self.env.pedl_trial_runner_network != "host":
            check_false(
                self.requires_host_mode_networking(),
                "Distributed multi-machinetraining for this framework requires "
                "DISTRIBUTED_TRIAL_RUNNER_NETWORK to be set to host.",
            )

        self._is_first_step = True
        self._load_path = None  # type: Optional[str]

        self._run_proc = self.make_subprocess(*make_subprocess_args)
        self._run_proc.start()

        @atexit.register
        def join() -> None:
            logging.info(f"Waiting for subordinate process to exit")
            self._run_proc.terminate()
            self._run_proc.join()
            logging.info(f"Done waiting, exiting")

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        # TODO: Be able to run a validation as the first workload after restore.
        metrics = self._run_workload(
            Workload.Kind.COMPUTE_VALIDATION_METRICS
        )  # type: Dict[str, Any]
        if get_rank() != 0:
            raise SkipWorkloadException()
        return metrics

    def load_framework_checkpoint(self, path: str) -> None:
        # This must be called before we start any workloads, since we need to do the load by giving
        # the framework the path to load from at the start of training. This method doesn't do any
        # actual loading, but only copies the contents of the given path to a temporary directory.

        # This object will delete the directory when it is destroyed, which will happen when this
        # object is destroyed as the main process exits.
        self.tmp_dir = tempfile.TemporaryDirectory()
        target_dir = os.path.join(self.tmp_dir.name, os.path.basename(path))
        logging.info(f"Copying checkpoint from {path} to {target_dir}")
        shutil.copytree(path, target_dir)
        self._load_path = target_dir

    def save_framework_checkpoint(self, path: str) -> None:
        if get_rank() != 0:
            raise SkipWorkloadException()
        self._run_workload(Workload.Kind.CHECKPOINT_MODEL, path)

    @abstractmethod
    def _run_workload(self, kind: Workload.Kind, args: Any = None) -> Any:
        pass

    @staticmethod
    @abstractmethod
    def make_subprocess(*subprocess_args: Any) -> Any:
        """
        Instantiates the class that runs the training subprocess.
        """
        pass
