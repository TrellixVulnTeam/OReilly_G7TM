"""
Functions for runtime correctness checks.

These functions are similar to Python's `assert` facility, but when a
check fails, we print both the expected value and the actual value. PEDL
code should generally prefer using `check` functions over `assert`.
"""
from typing import Any, Container, Optional, Sized


class CheckFailedError(Exception):
    pass


def check_true(actual: bool, reason: Optional[str] = None) -> None:
    if actual:
        return

    msg = "CHECK FAILED! Got {}, expected True".format(actual)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_false(actual: bool, reason: Optional[str] = None) -> None:
    if not actual:
        return

    msg = "CHECK FAILED! Got {}, expected False".format(actual)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_none(actual: Optional[Any], reason: Optional[str] = None) -> None:
    if actual is None:
        return

    msg = "CHECK FAILED! Got {}, expected None".format(actual)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_not_none(actual: Optional[Any], reason: Optional[str] = None) -> None:
    if actual is not None:
        return

    msg = "CHECK FAILED! Got {}, expected non-None".format(actual)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_eq(actual: Any, expected: Any, reason: Optional[str] = None) -> None:
    if actual == expected:
        return

    msg = "CHECK FAILED! Got {}, expected {}".format(actual, expected)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_not_eq(x: Any, y: Any, reason: Optional[str] = None) -> None:
    if x != y:
        return

    msg = "CHECK FAILED! Got {}, expected value != {}".format(x, y)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_gt(x: Any, y: Any, reason: Optional[str] = None) -> None:
    if x > y:
        return

    msg = "CHECK FAILED! Got {}, expected value > {}".format(x, y)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_gt_eq(x: Any, y: Any, reason: Optional[str] = None) -> None:
    if x >= y:
        return

    msg = "CHECK FAILED! Got {}, expected value >= {}".format(x, y)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_lt(x: Any, y: Any, reason: Optional[str] = None) -> None:
    if x < y:
        return

    msg = "CHECK FAILED! Got {}, expected value < {}".format(x, y)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_lt_eq(x: Any, y: Any, reason: Optional[str] = None) -> None:
    if x <= y:
        return

    msg = "CHECK FAILED! Got {}, expected value <= {}".format(x, y)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_eq_len(x: Sized, y: Sized, reason: Optional[str] = None) -> None:
    if len(x) == len(y):
        return

    msg = "CHECK FAILED! Expected lengths {} and {} to be equal".format(len(x), len(y))
    msg += "; values: {}, {}".format(x, y)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_len(actual: Sized, expected_len: int, reason: Optional[str] = None) -> None:
    actual_len = len(actual)
    if actual_len == expected_len:
        return

    msg = "CHECK FAILED! Got length {}, expected length {}".format(actual_len, expected_len)
    if reason is not None:
        msg += ": {}".format(reason)
    msg += ". Values: {}".format(actual)

    raise CheckFailedError(msg)


def check_in(val: Any, expected: Container[Any], reason: Optional[str] = None) -> None:
    if val in expected:
        return

    msg = "CHECK FAILED! "

    # Report a more concise error message when `expected` is a dict.
    if isinstance(expected, dict):
        msg += "'{}' is not in {}".format(val, list(expected.keys()))
    else:
        msg += "'{}' is not in {}".format(val, expected)

    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_not_in(val: Any, expected: Container[Any], reason: Optional[str] = None) -> None:
    if val not in expected:
        return

    msg = "CHECK FAILED! Got {}, expected value not in {}".format(val, expected)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_type(val: Any, expected: type, reason: Optional[str] = None) -> None:
    if type(val) == expected:
        return

    msg = "CHECK FAILED! {} has type {}, expected type {}".format(val, type(val), expected)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_isinstance(val: Any, expected: type, reason: Optional[str] = None) -> None:
    if isinstance(val, expected):
        return

    msg = "CHECK FAILED! {} has type {}, expected isinstance of {}".format(val, type(val), expected)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)


def check_issubclass(val: Any, expected: type, reason: Optional[str] = None) -> None:
    if issubclass(val, expected):
        return

    msg = "CHECK FAILED! {} has type {}, expected issubclass of {}".format(val, type(val), expected)
    if reason is not None:
        msg += ": {}".format(reason)

    raise CheckFailedError(msg)
