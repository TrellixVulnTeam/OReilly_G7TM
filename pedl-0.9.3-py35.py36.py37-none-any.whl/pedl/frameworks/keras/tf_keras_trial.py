"""
When distributed strategy is enabled, there is significant overhead for each
call to model.fit(). To overcome this we launch a second process called
TFKerasTrainProcess which stays inside the model.fit() call until we need to
perform validation.
"""


import contextlib
import json
import logging
import multiprocessing
import multiprocessing.synchronize
import os
import random
from abc import abstractmethod
from typing import (
    Any,
    Callable,
    cast,
    Dict,
    Generator,
    Iterator,
    List,
    Optional,
    Tuple,
    Type,
    Union,
)

import numpy as np
import tensorflow

from packaging import version
from tensorflow.keras.models import Model
from tensorflow.keras.utils import custom_object_scope

from pedl import Workload
from pedl._types import StepID
from pedl.check import (
    check_eq,
    check_eq_len,
    check_gt,
    check_in,
    check_isinstance,
    check_len,
    check_none,
    check_not_in,
    check_not_none,
    check_type,
)
from pedl.frameworks.keras.data import (
    KerasBatch,
    KerasDataAdapter,
    make_keras_data_adapter,
    unwrap_data,
)
from pedl.frameworks.keras.util import build_multi_gpu_model
from pedl.frameworks.util import elementwise_mean
from pedl.harness import SkipWorkloadException
from pedl.harness.load import EnvContext
from pedl.trial import (
    _get_rendezvous_info,
    CoordinatingTrialController,
    get_container_gpus,
    get_gang_addrs,
    get_rank,
    get_trial_seed,
    make_metrics,
    MetricOp,
    Reducer,
    Trial,
    ValidOp,
)

# TODO(ryan): remove this check after removing support for TensorFlow 1.13.1.
if version.parse(tensorflow.__version__) >= version.parse("1.14.0"):
    import tensorflow.compat.v1 as tf
else:
    import tensorflow as tf

IMPOSSIBLY_LARGE_EPOCHS = 9999999999999


@contextlib.contextmanager
def nullcontext() -> Generator:
    yield


def named_func(name: str, f: Callable) -> Callable:
    def f2(*args: Any, **kwargs: Any) -> Any:
        return f(*args, **kwargs)

    f2.__name__ = f2.__qualname__ = name
    return f2


# Some utilities for working with either arrays or string-to-array dicts.
Data = Union[np.ndarray, Dict[str, np.ndarray]]


def data_concat(xs: List[Data]) -> Data:
    x0 = xs[0]
    if isinstance(x0, np.ndarray):
        return np.concatenate(xs)

    return {k: np.concatenate([x[k] for x in xs]) for k in x0}


def data_truncate(x: Data, n: int) -> Data:
    if isinstance(x, np.ndarray):
        return x[:n]

    for k, v in x.items():
        x[k] = v[:n]
    return x


def data_shape(x: Data) -> Union[Tuple, Dict[str, Tuple]]:
    if isinstance(x, np.ndarray):
        return cast(Tuple, x.shape)

    return {k: v.shape for k, v in x.items()}


def save_checkpoint(model: Model, training_data_adapter: KerasDataAdapter, path: str) -> None:
    if get_rank():
        raise SkipWorkloadException()

    # We assume that at least one training step has completed when saving a
    # checkpoint.
    assert model is not None
    assert training_data_adapter is not None

    os.mkdir(path)
    training_data_adapter.save_data_checkpoint(path)
    tf.keras.models.save_model(model, os.path.join(path, "pedl-keras-model"))


class LoadWeightsCallback(tf.keras.callbacks.Callback):  # type: ignore
    """
    Loading a Keras model inside a distribution strategy scope doesn't work at all [1]. However, we
    can work around that by loading a copy of the model outside the scope, retrieving its weights,
    and later loading those weights into another copy created inside the strategy scope. Because the
    optimizer's weights are only created somewhere inside the call to `model.fit`, we need to do the
    loading in a callback rather than in a normal place in our code.

    [1] https://github.com/tensorflow/tensorflow/issues/30850
    """

    # Set the callback to run on all workers.
    _chief_worker_only = False

    def __init__(self, weights: List[np.ndarray], optimizer_weights: List[np.ndarray]):
        self.weights = weights
        self.optimizer_weights = optimizer_weights

    def on_train_begin(self, logs: Any = None) -> None:
        logging.info(
            f"Restoring {self.weights} weights and {self.optimizer_weights} optimizer weights"
        )
        self.model.set_weights(self.weights)
        self.model.optimizer.set_weights(self.optimizer_weights)


class WaitForInstructionsCallback(tf.keras.callbacks.Callback):  # type: ignore
    """
    WaitForInstructionsCallback allows a separate process to control this trial.
    This callback, which is triggered from inside the model.fit(), checks with the
    main process if it should stay inside the fit loop (training step or checkpoint)
    or if it should exit the fit() loop (validation).
    """

    # Set the callback to run on all workers.
    _chief_worker_only = False

    def __init__(
        self,
        conn: multiprocessing.connection.Connection,
        batches_per_step: int,
        batch_size: int,
        t_metrics_names: List[str],
        v_metrics_names: List[MetricOp],
        training_data_adapter: KerasDataAdapter,
    ) -> None:
        self.conn = conn
        self.batches_per_step = batches_per_step
        self.batch_size = batch_size
        self.t_metrics_names = t_metrics_names
        self.v_metrics_names = v_metrics_names
        self.training_data_adapter = training_data_adapter
        self.batches_processed = 0
        self.metrics = []  # type: List[Dict[str, Any]]

    def on_train_batch_end(self, _: int, logs: Any = None) -> None:
        self.batches_processed += 1
        if self.batches_processed != self.batches_per_step:
            return
        # Step completed, process results and send back to main process.
        # In addition to training and validation metrics, logs includes
        # "loss", "batch id", and "size".
        check_len(logs, 3 + len(self.t_metrics_names) + len(self.v_metrics_names))
        metrics = {k: logs[k] for k in ["loss", *self.t_metrics_names]}
        self.metrics.append(metrics)
        num_inputs = self.batches_per_step * self.batch_size
        self.conn.send((Workload.Kind.RUN_STEP, make_metrics(num_inputs, self.metrics)))
        self.metrics = []
        self.model.reset_metrics()
        self.batches_processed = 0

        while True:
            # Receive instructions for next step.
            kind, args = self.conn.recv()
            if kind == Workload.Kind.RUN_STEP:
                break
            elif kind == Workload.Kind.COMPUTE_VALIDATION_METRICS:
                self.conn.send((Workload.Kind.COMPUTE_VALIDATION_METRICS, None))
                self.model.stop_training = True
                break
            elif kind == Workload.Kind.CHECKPOINT_MODEL:
                save_checkpoint(self.model, self.training_data_adapter, args)
                self.conn.send((Workload.Kind.CHECKPOINT_MODEL, None))
            else:
                logging.error(f"Unknown workload kind {kind}")
                self.model.stop_training = True
                break

    def on_epoch_end(self, _: int, logs: Any = None) -> None:
        """
        If batches per epoch / batches per steps != 0, tf.keras is going to
        clear the metrics before the step is completed. We save the left-over
        metrics and combine them with the metrics generated during the
        remainder of the step.

        TODO: Metrics should be weighted based on number of batches completed
        vs remaining in the step.
        """
        if self.batches_processed > 0:
            # In addition to training and validation metrics, logs includes "loss".
            check_len(logs, 1 + len(self.t_metrics_names) + len(self.v_metrics_names))
            metrics = {k: logs[k] for k in ["loss", *self.t_metrics_names]}
            self.metrics.append(metrics)


class InterProcessArgs(object):
    def __init__(
        self,
        rendezvous_info: Dict[str, Any],
        hparams: Dict[str, Any],
        trial_type: Type,
        load_path: Optional[str],
        step_id: StepID,
        batches_per_step: int,
        env: Optional[EnvContext],
        make_data_loaders: Callable,
    ):
        self.rendezvous_info = rendezvous_info
        self.hparams = hparams
        self.trial_type = trial_type
        self.load_path = load_path
        self.step_id = step_id
        self.batches_per_step = batches_per_step
        self.env = env
        self.make_data_loaders = make_data_loaders


class TFKerasTrialController(CoordinatingTrialController):
    def __init__(self, *args: Any) -> None:
        # Keep local state about whether TFKerasTrainProcess is inside model.fit().
        self._fit_running = False

        self.conn_to_train_process, conn_from_train_process = multiprocessing.Pipe(duplex=True)
        self.conn_to_fit_callback, conn_from_fit_callback = multiprocessing.Pipe(duplex=True)

        super().__init__(*args, conn_from_train_process, conn_from_fit_callback)

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        logging.info(f"Calling train_for_step")
        if self._is_first_step:
            self._is_first_step = False

            check_not_none(
                self.make_data_loaders,
                "TFKerasTrial requires a `make_data_loaders` function in the model definition",
            )
            assert self.make_data_loaders is not None

            args = InterProcessArgs(
                _get_rendezvous_info(),
                self.hparams,
                self.trial_class,
                self._load_path,
                step_id,
                batches_per_step,
                self.env,
                self.make_data_loaders,
            )
        else:
            args = step_id  # type: ignore

        batch_metrics = self._run_workload(Workload.Kind.RUN_STEP, args)  # type: Dict[str, Any]

        if get_rank() != 0:
            raise SkipWorkloadException()

        return batch_metrics

    def _run_workload(self, kind: Workload.Kind, args: Any = None) -> Any:
        """
        The primary method for communicating with the subordinate process. It sends the given
        workload to the subprocess and waits for a response containing the result.

        The connecting sockets are determined by whether TFKerasTrainProcess is inside
        a model.fit() call and by the kind of workload request.
        """
        logging.info(f"Sending _run_workload of kind {kind}, fit status {self._fit_running}")
        if kind == Workload.Kind.COMPUTE_VALIDATION_METRICS and self._fit_running:
            # If TFKerasTrainProcess is inside a model.fit() call,
            # need to signal it to stop, and only then send request
            # for it to perform validation.
            self.send_receive(kind, args)
        ret = self.send_receive(kind, args)

        return ret

    def send_receive(self, kind: Workload.Kind, args: Any = None) -> Any:
        check_in(
            kind,
            [
                Workload.Kind.RUN_STEP,
                Workload.Kind.COMPUTE_VALIDATION_METRICS,
                Workload.Kind.CHECKPOINT_MODEL,
            ],
        )

        if self._fit_running:
            send_connection = self.conn_to_fit_callback
        else:
            send_connection = self.conn_to_train_process

        receive_connection = send_connection
        if kind == Workload.Kind.RUN_STEP and not self._fit_running:
            receive_connection = self.conn_to_fit_callback

        send_connection.send((kind, args))
        kind2, ret = receive_connection.recv()

        if kind == Workload.Kind.RUN_STEP:
            self._fit_running = True
        elif kind == Workload.Kind.COMPUTE_VALIDATION_METRICS:
            self._fit_running = False

        if kind2 is None:
            logging.info(f"Train process exited")
            exit()

        logging.info(f"Main process got result for kind {kind}: {ret}")
        check_eq(kind2, kind, f"args: {args}, return value: {ret}")

        return ret

    @staticmethod
    def make_subprocess(*subprocess_args: Any) -> "TFKerasTrainProcess":
        return TFKerasTrainProcess(*subprocess_args)

    def set_random_seed(self, seed: int) -> None:
        random.seed(seed + get_rank())
        np.random.seed(seed + get_rank())
        tf.set_random_seed(seed + get_rank())

    @staticmethod
    def supports_distributed_training() -> bool:
        return True


class TFKerasTrial(Trial):
    trial_controller_class = TFKerasTrialController

    @abstractmethod
    def build_model(self, hparams: Dict[str, Any]) -> tensorflow.keras.models.Model:
        """
        Returns a new keras `Sequential` instance configured with
        hyperparameters.
        """
        pass

    @abstractmethod
    def batch_size(self) -> int:
        """Returns the batch size to be used for training."""
        pass

    def training_metrics(self) -> Dict[str, MetricOp]:
        """
        Returns the metrics to compute at training time on a per-batch basis.
        The format is::

            {
                "metric1_name": metric1_operation,
                "metric2_name": metric2_operation,
                ...
            }

        The training loss is always computed and reported as a metric named
        "loss". Implementing this method is optional.

        The dictionary values must be valid Keras metric functions, such as
        those in the standard library or callable functions that conform to the
        "Keras custom metrics API" <https://keras.io/metrics/#custom-metrics>;
        their return values must be JSON-serializable.
        """
        return {}

    @abstractmethod
    def validation_metrics(self) -> Dict[str, ValidOp]:
        """
        Returns the metrics to compute at validation time. The format is::

            {
                "metric1_name": metric1_operation,
                "metric2_name": (metric2_operation, metric2_reducer),
                ...
            }

        The dictionary values must be either valid Keras metric functions::

            function: (predictions: tf.Tensor, labels: tf.Tensor) -> tf.Tensor

        or a pair (function, reducer) where::

            function: (prediction: tf.Tensor, labels: tf.Tensor) -> tf.Tensor
            reducer: [per-batch values] -> JSON-serializable metric.

        The first form is a valid Keras metric function that conforms to the
        "Keras custom metrics API" <https://keras.io/metrics/#custom-metrics>.
        In this form, the element-wise mean of this validation metric across
        all validation batches will be stored.

        The second form is a pair of operations; the first is a valid Keras
        metric function as described above. The second is a reducer function
        run on a list of all the intermediate results produced for this
        validation set to yield a final metric value. An example of a reducer
        function is provided in :func:`pedl.frameworks.util.elementwise_mean`;
        this is the default reduction function used if a metric is specified
        in the form above. This second form is useful if it is desirable to
        overwrite the default reduction procedure.
        """
        pass

    @abstractmethod
    def optimizer(self) -> tensorflow.keras.optimizers.Optimizer:
        """Returns the optimizer to be used by the model."""
        pass

    @abstractmethod
    def loss(self) -> MetricOp:
        """Returns the loss to be used by the model."""
        pass

    def session_config(self, hparams: Dict[str, Any]) -> tf.ConfigProto:
        """
        Returns the tf.ConfigProto used to configure the TensorFlow session.
        """
        return tf.ConfigProto(allow_soft_placement=True)


class TFKerasTrainProcess(multiprocessing.context.SpawnProcess):
    def __init__(
        self,
        conn: multiprocessing.connection.Connection,
        callback_conn: multiprocessing.connection.Connection,
    ) -> None:
        super().__init__(name="tfkeras-training-process")

        self.set_random_seed(get_trial_seed())

        self.conn = conn
        self.callback_conn = callback_conn

        # The model is lazily compiled upon loading from checkpoint, or the first step -- see
        # compile_model().
        self.template_model = None  # type: Optional[Model]
        self.model = None  # type: Optional[Model]

        # The weights and optimizer weights to restore from, if any.
        self.loaded_weights = None  # type: Optional[Tuple[np.ndarray, np.ndarray]]

        # These will be set when the harness calls set_data_loaders().
        self.data_loaders = None  # type: Optional[Tuple[Any, Any]]
        self.training_data_adapter = None  # type: Optional[KerasDataAdapter]
        self.validation_data_adapter = None  # type: Optional[KerasDataAdapter]
        self.training_iterator = None  # type: Optional[Iterator]
        self.validation_iterator = None  # type: Optional[Iterator]

        # These will be set by the initial connection message.
        self.hparams = None  # type: Optional[Dict[str, Any]]
        self.trial_class = None  # type: Optional[Type]
        self.load_path = None  # type: Optional[str]
        self.first_step = None  # type: Optional[int]
        self.batches_per_step = None  # type: Optional[int]
        self.env = None  # type: Optional[EnvContext]

    def set_random_seed(self, seed: int) -> None:
        random.seed(seed + get_rank())
        np.random.seed(seed + get_rank())
        tf.set_random_seed(seed + get_rank())

    def run(self) -> None:
        logging.basicConfig(
            level=logging.INFO, format="%(asctime)s:%(levelname)s [%(process)s]: %(message)s"
        )

        try:
            self._run()
        except Exception:
            logging.exception(f"TFKeras training process exception")
        finally:
            logging.info(f"Train process exiting")
            # Send closing messages on both connections, in case an exception is thrown while
            # transitioning from one mode to the other; the master process might hang waiting for
            # a response on the wrong connection.
            self.conn.send((None, None))
            self.callback_conn.send((None, None))

    def config(self, args: InterProcessArgs) -> None:
        os.environ["PEDL_RENDEZVOUS_INFO"] = json.dumps(args.rendezvous_info)
        self.hparams = args.hparams
        self.trial_class = args.trial_type
        self.load_path = args.load_path
        self.first_step = args.step_id
        self.batches_per_step = args.batches_per_step
        self.env = args.env

        assert args.env
        if args.env.experiment_config:
            # TODO: Right now when multiprocessing is enabled, we get an error.
            # It would be good to figure out a way we can continue supporting
            # multiprocessing in the KerasDataAdapter.
            acceleration = args.env.experiment_config.get("data", {}).get("acceleration")
            if acceleration:
                args.env.experiment_config["data"]["acceleration"]["use_multiprocessing"] = False

        assert self.trial_class
        assert issubclass(self.trial_class, TFKerasTrial)
        self.trial = self.trial_class(self.hparams)  # type: TFKerasTrial

        self.make_data_loaders = args.make_data_loaders

    def _init_model(self) -> None:
        # The Keras session to use. In the TensorFlow setting, the default TF
        # graph (self.session.graph) is thread-local (and we might invoke Trial
        # methods from different Python threads), so we save this graph aside
        # when the TFKerasTrial is constructed and use it for all subsequent
        # Keras API calls.
        assert self.hparams is not None
        self.session = tf.Session(
            graph=tf.get_default_graph(), config=self.trial.session_config(self.hparams)
        )
        tensorflow.keras.backend.set_session(self.session)

        # Initialize and validate training metrics and validation metrics.
        self._init_metrics()

        # Make data loaders.
        assert self.env is not None
        assert self.make_data_loaders is not None
        self.set_data_loaders(
            data_loaders=self.make_data_loaders(self.env.experiment_config, self.hparams)
        )

        # If a load path is provided load weights.
        if self.load_path:
            self.load_weights(path=self.load_path)

    def _run(self) -> None:
        # Wait for setup information from the main process.
        kind, args = self.conn.recv()

        check_eq(kind, Workload.Kind.RUN_STEP)
        check_not_none(args)

        logging.info(f"Training process got config arguments {args}")
        self.config(args)
        self._init_model()
        step_id = self.first_step

        while True:
            if kind == Workload.Kind.RUN_STEP:
                assert step_id
                assert self.batches_per_step
                self.launch_fit(step_id=step_id, batches_per_step=self.batches_per_step)
                step_id += 1
            elif kind == Workload.Kind.COMPUTE_VALIDATION_METRICS:
                metrics = self.compute_validation_metrics()
                self.send_result(Workload.Kind.COMPUTE_VALIDATION_METRICS, metrics)
            elif kind == Workload.Kind.CHECKPOINT_MODEL:
                assert isinstance(args, str)
                assert self.training_data_adapter
                save_checkpoint(self.model, self.training_data_adapter, args)
                self.send_result(Workload.Kind.CHECKPOINT_MODEL, None)
            else:
                logging.error(f"Unknown workload kind: {kind}")
                exit()

            kind, args = self.conn.recv()
            if kind == Workload.Kind.RUN_STEP:
                step_id = args

    def _init_metrics(self) -> None:
        # Keras always includes the training loss as the first
        # metric it returns, followed by any additional metrics that
        # were requested.
        training_metrics = self.trial.training_metrics()
        check_type(
            training_metrics,
            dict,
            "training_metrics() must be a dictionary, got {}".format(training_metrics),
        )
        check_not_in(
            "loss",
            training_metrics,
            "Please remove 'loss' metric from "
            "training_metrics(). TFKerasTrial will automatically "
            "include a training metric named 'loss'",
        )

        # Split up the training metric names and functions. We only pass the
        # functions into Keras itself; we then match up the results with the
        # names positionally.
        self.t_metrics_names = list(training_metrics.keys())  # type: List[str]
        self.t_metrics_funcs = list(training_metrics.values())  # type: List[MetricOp]

        validation_metrics = self.trial.validation_metrics()
        check_type(
            validation_metrics,
            dict,
            "validation_metrics() must be a dictionary, got {}".format(validation_metrics),
        )
        check_not_in(
            "loss",
            validation_metrics,
            "Please remove 'loss' metric from "
            "validation_metrics(). TFKerasTrial will automatically "
            "include a validation metric named 'loss'",
        )

        # Do the same with validation metrics, but also keep track of reducer
        # functions. If no reducer function is specified for a metric, use
        # elementwise_mean as a default.
        self.v_metrics_names = []  # type: List[str]
        self.v_metrics_funcs = []  # type: List[MetricOp]
        self.v_metrics_reducers = []  # type: List[Reducer]
        for name, spec in validation_metrics.items():
            self.v_metrics_names.append(name)
            if isinstance(spec, (list, tuple)):
                check_len(spec, 2)
                self.v_metrics_funcs.append(spec[0])
                self.v_metrics_reducers.append(spec[1])
            else:
                self.v_metrics_funcs.append(spec)
                self.v_metrics_reducers.append(elementwise_mean)

        self._metric_objs = {}  # type: Dict[str, Any]
        for i, n in enumerate(self.t_metrics_names):
            check_not_in(n, self._metric_objs, "Duplicate training metric name '{}'".format(n))
            self._metric_objs[n] = self.t_metrics_funcs[i] = named_func(n, self.t_metrics_funcs[i])
        for i, n in enumerate(self.v_metrics_names):
            check_not_in(n, self._metric_objs, "Duplicate validation metric name '{}'".format(n))
            self._metric_objs[n] = self.v_metrics_funcs[i] = named_func(n, self.v_metrics_funcs[i])

    def strategy_scope(self) -> Any:
        return nullcontext() if self.strategy is None else self.strategy.scope()

    def init_strategy(self) -> Any:
        """
        Sets up the TF distribution strategy by updating the environment (if necessary) and creating
        the strategy object.
        """
        addrs = get_gang_addrs()

        # In TF 1.13, setting TF_CONFIG when training on a single node makes
        # tf.distribute.MirroredStrategy follow its distributed training code
        # path, which causes internal invariants in reduction code to fail.
        if len(addrs) > 1:
            rank = get_rank()
            cluster = {"chief": addrs[:1], "worker": addrs[1:]}
            if rank == 0:
                task = {"type": "chief", "index": 0}
            else:
                task = {"type": "worker", "index": rank - 1}

            os.environ.update({"TF_CONFIG": json.dumps({"cluster": cluster, "task": task})})

            self.strategy = tf.distribute.experimental.MultiWorkerMirroredStrategy()
        else:
            self.strategy = None

    def compile_model(self) -> None:
        self.init_strategy()
        logging.info(f"Using distribution strategy: {self.strategy}")

        with self.session.graph.as_default(), self.strategy_scope():
            assert self.hparams
            self.template_model = self.trial.build_model(self.hparams)
            check_not_none(self.template_model, "build_model() returned None")

            num_gpus = len(get_container_gpus())
            if self.strategy is None and num_gpus > 1:
                logging.info(f"Converting graph into multi-GPU graph")
                self.model = build_multi_gpu_model(self.template_model, num_gpus)
            else:
                self.model = self.template_model

            # One unfortunate limitation of this implementation is that
            # training AND validation metrics will be computed on each step,
            # regardless of the workload kind. Keras does not offer support
            # for distinguishing training from validation metrics, nor
            # selectively computing metrics without re-compiling a model.
            #
            # NOTE: A second implementation option is to re-compile the model
            # with the correct metrics when switching between training and
            # validation steps. This would eliminate the potential cost of
            # computing unnecessary metrics, but would incur the cost of
            # recompilation at the beginning of a step and complexity of
            # tracking the state. A third option is to maintain the two
            # separate instances of a training and validation model, at the
            # cost of memory.
            self.model.compile(
                loss=self.trial.loss(),
                optimizer=self.trial.optimizer(),
                metrics=self.t_metrics_funcs + self.v_metrics_funcs,
            )

    def join_batches(self, batches: List[KerasBatch]) -> Tuple:
        """
        Concatenate together the data for multiple batches. The batches must contain either arrays
        or dicts mapping strings to arrays (the `data` attributes of all the batches must be the
        same type, as must the `label` attributes, but the two can differ from each other).
        """
        data = data_concat([b.data for b in batches])
        labels = data_concat([b.labels for b in batches])

        num_inputs = (
            data.shape[0] if isinstance(data, np.ndarray) else next(iter(data.values())).shape[0]
        )

        # Partial batches are not allowed during training, so make sure the input consists of
        # complete batches. During training, Keras will complain about the input iterator running
        # out; during validation, it enforces full batches ahead of time in the function
        # `distributed_training_utils.get_input_params`.
        rounded_num_inputs = num_inputs - num_inputs % self.trial.batch_size()
        if rounded_num_inputs != num_inputs:
            logging.warning(
                f"Truncating data from {num_inputs} samples to {rounded_num_inputs} for "
                f"batch size {self.trial.batch_size()}"
            )
            num_inputs = rounded_num_inputs
            data = data_truncate(data, rounded_num_inputs)
            labels = data_truncate(labels, rounded_num_inputs)

        logging.info(f"Data shape: {data_shape(data)}")
        logging.info(f"Labels shape: {data_shape(labels)}")

        return data, labels, num_inputs

    def launch_fit(self, step_id: int, batches_per_step: int) -> None:
        """Runs a trial for one step."""

        # If we don't have a compiled model yet, load and compile the
        # model now.
        assert self.training_data_adapter is not None
        if self.model is None:
            self.compile_model()
            assert self.model is not None

        # `step_id` is one-based; `step_num` is zero-based.
        check_gt(step_id, 0)
        step_num = step_id - 1
        first_batch_in_step = step_num * batches_per_step

        if self.training_iterator is None:
            # We process the data sequences from batches 0-n; set a batch_offset so that we process
            # the data in the right order.
            self.training_data_adapter.start(batch_offset=first_batch_in_step)
            self.training_iterator = self.training_data_adapter.get_iterator()
            assert self.training_iterator is not None

        # With a distribution strategy, `fit_on_batch` and `test_on_batch` cannot be used; we must
        # use `fit` and `evaluate`. But, in a distributed setting, `fit` can have a significant
        # per-call overhead (1-2 seconds), and it also does not appear to support taking anything
        # but arrays as data. Therefore, we shall now proceed to take the data that were so
        # thoughtfully divvied up into batches for us and re-merge them into a large array to pass
        # to `fit`. Because we are expecting to stay inside the model.fit() call, `batches` include
        # the entire dataset rather than just what is necessary for one step.
        # TODO(DET-1023): Support tf.data.Dataset as an input.
        batches = [
            unwrap_data(next(self.training_iterator))
            for _ in range(len(self.training_data_adapter))
        ]
        data, labels, num_inputs = self.join_batches(batches)

        with self.session.graph.as_default():
            cbs = []
            if self.loaded_weights is not None:
                weights, optimizer_weights = self.loaded_weights
                self.loaded_weights = None
                cbs.append(LoadWeightsCallback(weights, optimizer_weights))
            cbs.append(
                WaitForInstructionsCallback(
                    conn=self.callback_conn,
                    batches_per_step=batches_per_step,
                    batch_size=self.trial.batch_size(),
                    t_metrics_names=self.t_metrics_names,
                    v_metrics_names=self.v_metrics_funcs,
                    training_data_adapter=self.training_data_adapter,
                )
            )
            self.model.stop_training = False

            _ = self.model.fit(
                data,
                labels,
                batch_size=self.trial.batch_size(),
                callbacks=cbs,
                shuffle=False,
                epochs=IMPOSSIBLY_LARGE_EPOCHS,
                validation_split=0,
            ).history

        return

    def compute_validation_metrics(self) -> Dict[str, Any]:
        assert self.validation_data_adapter is not None
        assert self.model is not None

        metrics = []

        self.validation_data_adapter.start(is_validation=True)
        validation_iterator = self.validation_data_adapter.get_iterator()
        assert validation_iterator is not None

        # See comments in train_for_step: we need one big array to pass to `model.evaluate`.
        batches = [unwrap_data(x) for x in validation_iterator]

        data, labels, num_inputs = self.join_batches(batches)

        with self.session.graph.as_default(), self.strategy_scope():
            metrics_values = self.model.evaluate(data, labels, batch_size=self.trial.batch_size())

        logging.info(f"Validation metrics: {metrics_values}")

        if not self.t_metrics_funcs and not self.v_metrics_funcs:
            metrics_values = [metrics_values]

        check_len(metrics_values, 1 + len(self.t_metrics_names) + len(self.v_metrics_names))
        v_metrics_values = [metrics_values[0]] + metrics_values[1 + len(self.t_metrics_names) :]
        metrics.append(v_metrics_values)

        self.validation_data_adapter.stop()

        check_gt(len(metrics), 0)

        # The "loss" will be the first element in the v_metrics_values list,
        # followed by user-specified validation metrics.
        v_metrics_names = ["loss"] + self.v_metrics_names
        v_metrics_reducers = [elementwise_mean]  # type: List[Reducer]
        v_metrics_reducers += self.v_metrics_reducers
        reduced_metrics = [
            reducer([b[idx] for b in metrics]) for idx, reducer in enumerate(v_metrics_reducers)
        ]
        check_eq_len(v_metrics_names, reduced_metrics)
        named_metrics = dict(zip(v_metrics_names, reduced_metrics))

        return {"num_inputs": num_inputs, "validation_metrics": named_metrics}

    def load_weights(self, path: str) -> None:
        logging.info(f"Loading checkpoint from {path}")

        # If we're restoring from a checkpoint, we don't expect to
        # replace an existing model.
        check_none(self.model)
        assert self.training_data_adapter is not None
        self.training_data_adapter.load_data_checkpoint(path)

        # Here, we load a model temporarily, extract its weights, and throw the rest of the model
        # away -- see comments in LoadWeightsCallback.
        with custom_object_scope(self._metric_objs):
            model = tf.keras.models.load_model(os.path.join(path, "pedl-keras-model"))
        self.loaded_weights = (model.get_weights(), model.optimizer.get_weights())

    def set_data_loaders(self, data_loaders: Optional[Tuple[Any, Any]]) -> None:
        check_not_none(
            data_loaders,
            "TFKerasTrial requires a `make_data_loaders` function in the model definition",
        )
        assert data_loaders is not None  # get mypy to stop complaining

        type_err_msg = (
            "`make_data_loaders` must return a tuple of two BatchLoader "
            "or two keras.utils.Sequence objects"
        )

        check_isinstance(data_loaders, (tuple, list), type_err_msg)  # type: ignore
        check_len(data_loaders, 2, type_err_msg)

        self.training_data_adapter = make_keras_data_adapter(
            data_loaders[0], self.trial.batch_size(), drop_leftovers=True
        )

        # We can choose the batch size freely when evaluating the
        # validation set. For now, we use the same batch size as
        # this trial uses for training, but this could be improved.
        self.validation_data_adapter = make_keras_data_adapter(
            data_loaders[1], self.trial.batch_size()
        )

    def send_result(self, kind: Workload.Kind, result: Any) -> None:
        self.conn.send((kind, result))
