"""
Trial interface intended for use with the Keras functional API. This is
only recommended for use in models with multiple data inputs and/or
label outputs.  For a model with a single input and single output,
please use :class:`pedl.frameworks.keras.KerasTrial`.
"""
import logging
import os
import random
from abc import abstractmethod
from collections import defaultdict
from enum import Enum, unique
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

import keras
import numpy as np
import tensorflow
from keras.utils.generic_utils import Progbar
from packaging import version

from pedl._types import StepID
from pedl.check import (
    check_eq_len,
    check_gt,
    check_in,
    check_isinstance,
    check_len,
    check_none,
    check_not_in,
    check_not_none,
    check_true,
    check_type,
)
from pedl.frameworks.keras.data import KerasDataAdapter, make_keras_data_adapter, unwrap_data
from pedl.frameworks.keras.util import (
    build_multi_gpu_model,
    load_keras_optimizer_state,
    save_keras_optimizer_state,
)
from pedl.frameworks.util import elementwise_mean
from pedl.trial import get_container_gpus, make_metrics, MetricOp, Reducer, Trial, TrialController

# TODO(ryan): remove this check after removing support for TensorFlow 1.13.1.
if version.parse(tensorflow.__version__) >= version.parse("1.14.0"):
    import tensorflow.compat.v1 as tf
else:
    import tensorflow as tf

# A validation metric specification can take one of two forms:
# (layer, metric func)
# (layer, metric func, reducer func)
# See validation_metrics() for more.
KerasFunctionalValidSpec = Union[Tuple[str, MetricOp], Tuple[str, MetricOp, Reducer]]


class Metric(object):
    """
    Helper class to track metric values returned from the Keras train_on_batch
    and test_on_batch functions. These can be either be loss values or PEDL
    training and validation metrics specified as Keras metric functions.
    """

    @unique
    class Kind(Enum):
        # Training and validation metrics are specified by the user as
        # keras metric functions.
        TRAINING = 1
        VALIDATION = 2
        # Loss metrics are specified by the user as keras loss functions.
        LOSS = 3

    def __init__(
        self,
        kind: Kind,
        name: str,
        metric_op: Optional[MetricOp] = None,
        reducer: Optional[Reducer] = None,
    ) -> None:
        if kind == Metric.Kind.TRAINING:
            check_not_none(metric_op)
        elif kind == Metric.Kind.VALIDATION:
            check_not_none(metric_op)
            check_not_none(reducer)

        self.kind = kind
        self.name = name
        self.metric_op = metric_op
        self.reducer = reducer

    def __repr__(self) -> str:
        return "<{}: {}>".format(self.kind.name, self.name)


class KerasFunctionalTrialController(TrialController):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        # TrialController.__init__() will correctly order setting random seeds, instantiating user
        # classes, etc.
        super().__init__(*args, **kwargs)

        assert isinstance(self.trial, KerasFunctionalTrial)
        self.trial = self.trial  # type: KerasFunctionalTrial

        # The Keras session to use.  In the TensorFlow setting, the default TF
        # graph (self.session.graph) is thread-local (and we might invoke Trial
        # methods from different Python threads), so we save this graph aside
        # when the KerasTrial is constructed and use it for all subsequent
        # Keras API calls.
        self.session = tf.Session(
            graph=tf.get_default_graph(), config=self.trial.session_config(self.hparams)
        )
        keras.backend.set_session(self.session)

        # The Keras model instances this class will use for training.
        # `self.template_model` is the model returned by `self.build_model()`
        # and is used to save and load checkpoints. `self.model` is used for
        # the model computation. In the single-GPU setting,
        # `self.template_model` is the same object as `self.model`. In the
        # multi-GPU setting, they are distinct, with `self.model` wrapping
        # `self.template_model` via Keras's `multi_gpu_model`.
        #
        # These models are lazily compiled upon loading from checkpoint, or the
        # first step -- see compile_model().
        self.template_model = None  # type: Optional[keras.models.Model]
        self.model = None  # type: Optional[keras.models.Model]

        # Initialize and validate training metrics and validation metrics.
        self._init_metrics()

        # These will be set when the harness calls set_data_loaders().
        self.training_data_adapter = None  # type: Optional[KerasDataAdapter]
        self.validation_data_adapter = None  # type: Optional[KerasDataAdapter]
        self.training_iterator = None  # type: Optional[Iterator]
        self.validation_iterator = None  # type: Optional[Iterator]

        # TODO(ryan): Remove this compatibility layer with the old Trial API.
        super().initialize(self.env)
        self.set_data_loaders(self.data_loaders)

    def _init_metrics(self) -> None:
        # This object tracks the training and validation metrics specified by
        # the user. These will be passed to the model.compile() call as the
        # metrics argument -- see self.compile_model().
        self.pedl_metrics = defaultdict(list)  # type: Dict[str, List[Metric]]

        training_metrics = self.trial.training_metrics()
        check_type(
            training_metrics,
            dict,
            "training_metrics() must be a dictionary, got {}".format(training_metrics),
        )
        check_not_in(
            "loss",
            training_metrics,
            "Please remove 'loss' metric from "
            "training_metrics(). KerasFunctionalTrial will "
            "automatically include a training metric named 'loss'",
        )

        for name, (layer, metric) in training_metrics.items():
            self.pedl_metrics[layer].append(Metric(Metric.Kind.TRAINING, name, metric))

        validation_metrics = self.trial.validation_metrics()
        check_type(
            validation_metrics,
            dict,
            "validation_metrics() must be a dictionary, got {}".format(validation_metrics),
        )
        check_not_in(
            "loss",
            validation_metrics,
            "Please remove 'loss' metric from "
            "validation_metrics(). KerasFunctionalTrial will "
            "automatically include a validation metric named 'loss'",
        )

        for layer in self.trial.losses().keys():
            loss_name = "{}_loss".format(layer)
            check_not_in(
                loss_name,
                training_metrics,
                "Please remove '{}' metric from "
                "training_metrics(). KerasFunctionalTrial will "
                "automatically include a training "
                "metric named '{}'".format(loss_name, loss_name),
            )
            check_not_in(
                loss_name,
                validation_metrics,
                "Please remove '{}' metric from "
                "validation_metrics(). KerasFunctionalTrial will "
                "automatically include a validation "
                "metric named '{}'".format(loss_name, loss_name),
            )

        # Mypy gets confused by the different representations of a validation
        # metric, so force `spec` to be a very broad type.
        spec = None  # type: Any
        for name, spec in validation_metrics.items():
            check_true(isinstance(spec, (list, tuple)))

            if len(spec) == 2:
                layer, metric, reducer = spec[0], spec[1], elementwise_mean
            elif len(spec) == 3:
                layer, metric, reducer = spec
            else:
                raise Exception(
                    "Invalid validation metric: expected sequence "
                    "of length 2 or 3, got {}".format(spec)
                )

            self.pedl_metrics[layer].append(Metric(Metric.Kind.VALIDATION, name, metric, reducer))

    def set_random_seed(self, seed: int) -> None:
        random.seed(seed)
        np.random.seed(seed)
        tf.set_random_seed(seed)

    def compile_model(self) -> None:
        with self.session.graph.as_default():
            self.template_model = self.trial.build_model(self.hparams)
            check_not_none(self.template_model, "build_model() returned None")
            self._validate_model()

            num_gpus = len(get_container_gpus())
            if num_gpus > 1:
                self.model = build_multi_gpu_model(self.template_model, num_gpus)
            else:
                self.model = self.template_model

            # Keras expects a loss function for every output layer specified.
            # If an output layer is not being optimized, this can be set to a
            # loss of `None` and a loss weight of 0.0 for Keras to ignore.
            # Note that this means Keras will ignore any specified metrics for
            # this layer as well.
            keras_losses = self.trial.losses().copy()
            keras_loss_weights = {k: 1.0 for k in keras_losses.keys()}
            for output_name in self.model.output_names:
                if output_name not in keras_losses:
                    keras_losses[output_name] = None
                    keras_loss_weights[output_name] = 0.0

            # One unfortunate limitation of this implementation is that
            # training AND validation metrics will be computed on each step,
            # regardless of the workload kind. See comment in
            # KerasTrial.compile_model.
            keras_metrics = {
                layer: [m.metric_op for m in ms] for layer, ms in self.pedl_metrics.items()
            }
            self.model.compile(
                loss=keras_losses,
                loss_weights=keras_loss_weights,
                optimizer=self.trial.optimizer(),
                metrics=keras_metrics,
            )

            # self.model_metrics will be an ordered list of Metrics, where the
            # order corresponds to the list of values returned by
            # self.model.train_on_batch / self.model.test_on_batch. This list
            # will include loss value(s), PEDL training metrics, and PEDL
            # validation metrics.
            #
            # NOTE: The following logic is based on examining the Keras source
            # code. See keras/engine/training.py and the model.compile()
            # function.
            self.model_metrics = []  # type: List[Metric]

            # The first metric value returned is always the "total" loss. In
            # the multiple loss case, this may be a sum of different loss
            # functions.
            check_in("loss", self.model.metrics_names)
            self.model_metrics.append(Metric(Metric.Kind.LOSS, "loss"))

            # The next metrics in the list are the individual loss values of
            # each output layer, but only if more than a single output is
            # defined. Keras maintains the ordering of self.model.output_names
            # when constructing this portion of the output list.
            if len(self.model.output_names) > 1:
                for output in self.model.output_names:
                    if keras_losses[output]:
                        loss_name = output + "_loss"
                        check_in(loss_name, self.model.metrics_names)
                        self.model_metrics.append(Metric(Metric.Kind.LOSS, loss_name))

            # The final metric values are those specified as the `metrics`
            # argument to compile. Keras maintains the ordering of
            # self.model.output_names and the ordering within the nested metric
            # lists when constructing this portion of the output list.
            # Following the Keras implementation, metrics without loss
            # functions specified on their layers are ignored.
            for output in self.model.output_names:
                if output in self.pedl_metrics:
                    if not keras_losses[output]:
                        logging.warning(
                            "Metric function ('{}') on layer {} found without "
                            "a loss function specified. Keras will ignore "
                            "this metric."
                        )
                        continue

                    self.model_metrics.extend(self.pedl_metrics[output])

            # Do a final check that the length of the Keras representation of
            # the output list (`self.model.metrics_names`) matches our internal
            # representation.
            check_eq_len(self.model_metrics, self.model.metrics_names)

    def _validate_model(self) -> None:
        assert self.template_model is not None

        for layer_name in self.trial.losses().keys():
            check_in(
                layer_name,
                self.template_model.output_names,
                "'{}' not found in model outputs as a layer "
                "name. Please change your loss specification "
                "to reference named output layers.".format(layer_name),
            )

        for (layer_name, _) in self.trial.training_metrics().values():
            check_in(
                layer_name,
                self.template_model.output_names,
                "'{}' not found in model outputs as a layer "
                "name. Please change your training metrics "
                "to reference named output layers.".format(layer_name),
            )

        for spec in self.trial.validation_metrics().values():
            check_in(
                spec[0],
                self.template_model.output_names,
                "'{}' not found in model outputs as a layer "
                "name. Please change your validation metrics "
                "to reference named output layers.".format(layer_name),
            )

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        """Runs a trial for one step."""
        # If we don't have a compiled model yet, load and compile the
        # model now.
        assert self.training_data_adapter is not None
        if self.model is None:
            self.compile_model()
            assert self.model is not None

        # `step_id` is one-based; `step_num` is zero-based.
        check_gt(step_id, 0)
        step_num = step_id - 1
        first_batch_in_step = step_num * batches_per_step

        if self.training_iterator is None:
            # We process the data sequences from batches 0-n
            #   set a batch_offset so that we process the data in the right
            #   order
            self.training_data_adapter.start(batch_offset=first_batch_in_step)
            self.training_iterator = self.training_data_adapter.get_iterator()
            assert self.training_iterator is not None

        num_inputs = 0
        metrics = []

        progbar = Progbar(target=batches_per_step, interval=0.5)
        for i in range(batches_per_step):
            batch = unwrap_data(next(self.training_iterator))
            num_inputs += len(batch)

            with self.session.graph.as_default():
                metrics_values = self.model.train_on_batch(
                    batch.data, batch.labels, sample_weight=batch.sample_weight
                )

            # train_on_batch() will return the metric as a scalar if there is
            # only a single one.
            if len(self.model_metrics) == 1:
                metrics_values = [metrics_values]

            batch_metrics = {}
            for metric, metric_val in zip(self.model_metrics, metrics_values):
                if metric.kind in {Metric.Kind.TRAINING, Metric.Kind.LOSS}:
                    batch_metrics[metric.name] = metric_val

            metrics.append(batch_metrics)
            progbar.update(i + 1, batch_metrics.items())

        logging.info(
            "Done training step: {} records in {} batches".format(num_inputs, batches_per_step)
        )

        return make_metrics(num_inputs, metrics)

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        assert self.validation_data_adapter is not None
        assert self.model is not None

        metrics = []
        num_inputs = 0

        self.validation_data_adapter.start(is_validation=True)
        validation_iterator = self.validation_data_adapter.get_iterator()
        assert validation_iterator is not None

        progbar_length = None
        if self.validation_data_adapter.is_finite():
            progbar_length = len(self.validation_data_adapter)
        progbar = Progbar(target=progbar_length, interval=0.5)
        progbar_idx = 0

        for tup in validation_iterator:
            batch = unwrap_data(tup)
            num_inputs += len(batch)
            with self.session.graph.as_default():
                metrics_values = self.model.test_on_batch(
                    batch.data, batch.labels, sample_weight=batch.sample_weight
                )

            # `test_on_batch` will return the metric as a scalar if there is
            # only a single one.
            if len(self.model_metrics) == 1:
                metrics_values = [metrics_values]

            check_eq_len(metrics_values, self.model_metrics)

            batch_metrics = {}
            for metric, metric_val in zip(self.model_metrics, metrics_values):
                if metric.kind in {Metric.Kind.VALIDATION, Metric.Kind.LOSS}:
                    batch_metrics[metric.name] = metric_val

            check_in(
                "loss",
                batch_metrics,
                "Expected at least one 'loss' reported by Keras but got: "
                "{}".format(batch_metrics),
            )

            metrics.append(batch_metrics)

            progbar_idx += 1
            progbar.update(progbar_idx, batch_metrics.items())

        self.validation_data_adapter.stop()

        check_gt(len(metrics), 0)

        reduced_metrics = {}
        for metric in self.model_metrics:
            if metric.kind == Metric.Kind.LOSS:
                reducer = elementwise_mean  # type: Reducer
            elif metric.kind == Metric.Kind.VALIDATION:
                assert metric.reducer is not None
                reducer = metric.reducer
            else:
                continue

            reduced_metrics[metric.name] = reducer([b[metric.name] for b in metrics])

        return {"num_inputs": num_inputs, "validation_metrics": reduced_metrics}

    def save_framework_checkpoint(self, path: str) -> None:
        # We assume that at least one training step has completed when saving a
        # checkpoint.
        assert self.template_model is not None
        assert self.model is not None
        assert self.training_data_adapter is not None
        os.mkdir(path)

        # Save the model architecture.
        model_path = os.path.join(path, "model.json")
        with open(model_path, "w") as f:
            f.write(self.template_model.to_json())

        # Save the model weights.
        weights_path = os.path.join(path, "weights.h5")
        self.template_model.save_weights(weights_path)

        # Save optimizer weights, if they exist.
        save_keras_optimizer_state(self.model, os.path.join(path, "optimizer_weights.h5"))

        self.training_data_adapter.save_data_checkpoint(path)

    def load_framework_checkpoint(self, path: str) -> None:
        # If we're restoring from a checkpoint, we don't expect to
        # replace an existing model.
        check_none(self.model)
        self.compile_model()
        assert self.template_model is not None
        assert self.training_data_adapter is not None

        # Load the model weights.
        weights_path = os.path.join(path, "weights.h5")

        check_true(os.path.isfile(weights_path))
        with self.session.graph.as_default():
            self.template_model.load_weights(weights_path)

            # If any optimizer weights exist in the checkpoint path, load them
            # as well.
            optimizer_weights_path = os.path.join(path, "optimizer_weights.h5")
            if os.path.isfile(optimizer_weights_path):
                load_keras_optimizer_state(self.model, optimizer_weights_path)

        self.training_data_adapter.load_data_checkpoint(path)

    def set_data_loaders(self, data_loaders: Optional[Tuple[Any, Any]]) -> None:
        check_not_none(
            data_loaders,
            "KerasFunctionalTrial requires a `make_data_loaders` function in the model definition",
        )
        assert data_loaders is not None  # get mypy to stop complaining

        type_err_msg = (
            "`make_data_loaders` must return a tuple of two BatchLoader "
            "or two keras.utils.Sequence objects"
        )

        check_isinstance(data_loaders, (tuple, list), type_err_msg)  # type: ignore
        check_len(data_loaders, 2, type_err_msg)

        self.training_data_adapter = make_keras_data_adapter(
            data_loaders[0], self.trial.batch_size(), drop_leftovers=True, multi_input_output=True
        )

        # We can choose the batch size freely when evaluating the
        # validation set. For now, we use the same batch size as
        # this trial uses for training, but this could be improved.
        self.validation_data_adapter = make_keras_data_adapter(
            data_loaders[1], self.trial.batch_size(), multi_input_output=True
        )


class KerasFunctionalTrial(Trial):
    trial_controller_class = KerasFunctionalTrialController

    @abstractmethod
    def build_model(self, hparams: Dict[str, Any]) -> keras.models.Model:
        """
        Returns a new `keras.Functional` instance configured with
        hyperparameters.

        The model instance may have multiple outputs, but does not yet
        support multiple inputs.
        """
        pass

    def training_metrics(self) -> Dict[str, Tuple[str, MetricOp]]:
        """
        Returns the metrics to compute at training time on a per-batch basis.
        The format is::

            {
                "metric1_name": metric1_operation,
                "metric2_name": metric2_operation,
                ...
            }

        The training loss is always computed and reported as a metric named
        "loss". Implementing this method is optional.

        The dictionary values are tuples of `(str, function)`. The first member
        of the tuple is a string name corresponding to the output layer the
        metric should be computed on. The functions must be valid Keras metric
        functions, such as those in the standard library or callable functions
        that conform to the "Keras custom metrics API"
        <https://keras.io/metrics/#custom-metrics>; their return values must be
        JSON-serializable.
        """
        return {}

    @abstractmethod
    def validation_metrics(self) -> Dict[str, KerasFunctionalValidSpec]:
        """
        Returns the metrics to compute at validation time. The format is::

            {
                "metric1_name": ("output_layer": str,
                                 metric1_operation: MetricOp),
                "metric2_name": ("output_layer": str,
                                 metric2_operation: MetricOp,
                                 metric2_reducer: Reducer),
                ...
            }

        The dictionary values must be tuples of length 2 or 3.

        The first element of the tuple is the string name of the Keras output
        layer the metric should be calculated on. This is necessary in case the
        model has multiple output layers.

        The second element of the tuple is a valid Keras metric function::

            function: (predictions: tf.Tensor, labels: tf.Tensor) -> tf.Tensor

        The third element of the tuple is an optional reducer function that
        defines how the per-batch values of each metric are reduced to a single
        value::

            reducer: [per-batch values] -> JSON-serializable metric.

        If no reducer function is specified,
        :func:`pedl.frameworks.util.elementwise_mean` will be used by default.
        """
        pass

    @abstractmethod
    def optimizer(self) -> keras.optimizers.Optimizer:
        """Returns the optimizer to be used by the model."""
        pass

    @abstractmethod
    def losses(self) -> Dict[str, Optional[MetricOp]]:
        """
        Returns a dict. The keys are the names of the output layers.  The
        values are valid Keras losses to be used for that output layer, or
        `None` if that output should not be optimized.
        """
        pass

    @abstractmethod
    def batch_size(self) -> int:
        """
        Returns the batch size of the input.
        """
        pass

    def session_config(self, hparams: Dict[str, Any]) -> tf.ConfigProto:
        """
        Returns the tf.ConfigProto used to configure the TensorFlow session.
        """
        return tf.ConfigProto(allow_soft_placement=True)
