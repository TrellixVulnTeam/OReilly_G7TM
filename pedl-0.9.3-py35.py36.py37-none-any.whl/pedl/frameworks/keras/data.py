import io
import math
import os
import threading
from typing import Any, cast, Dict, IO, Iterator, List, Optional, Sized, Tuple, Union

import cloudpickle
import cloudpickle_generators
import keras
import numpy as np
from keras.utils.data_utils import OrderedEnqueuer, Sequence

from pedl.data import BatchLoader


class SequenceWithOffset(Sequence):  # type: ignore
    def __init__(self, sequence: Sequence, batch_offset: int = 0):
        self._sequence = sequence
        self._batch_offset = batch_offset

    def __len__(self):  # type: ignore
        return len(self._sequence)

    def __getitem__(self, index):  # type: ignore
        index = (index + self._batch_offset) % len(self)
        return self._sequence[index]


class BatchLoaderToSequence(Sequence):  # type: ignore
    def __init__(
        self,
        batch_loader: BatchLoader,
        batch_size: int,
        drop_leftovers: bool = True,
        multi_input_output: bool = False,
    ) -> None:
        assert batch_loader is not None
        self.batch_loader = batch_loader
        self.batch_size = batch_size
        self.drop_leftovers = drop_leftovers
        self.multi_input_output = multi_input_output

    def __len__(self):  # type: ignore
        # Returns number of batches
        if self.drop_leftovers:
            return math.floor(len(self.batch_loader) / self.batch_size)
        return math.ceil(len(self.batch_loader) / self.batch_size)

    def __getitem__(self, index):  # type: ignore
        # Gets batch at position index
        batch = self.batch_loader.get_batch_by_index(
            batch_size=self.batch_size, ith=index, wrap=False, drop_leftovers=self.drop_leftovers
        )
        if self.multi_input_output:
            return batch.data, batch.labels
        return batch.plain_data, batch.plain_labels


class KerasBatch(object):
    """A class the encapsulates the inputs needed for Keras to train/test a batch.

    This class is intentionally small and minimizes the checks it makes to what could
    break our code. Validation of the fields is left to Keras as much as possible.
    """

    def __init__(
        self,
        data: Union[np.ndarray, List, Dict],
        labels: Union[np.ndarray, List, Dict],
        sample_weight: Union[np.ndarray, List, Dict],
    ):
        self.data = data
        self.labels = labels
        self.sample_weight = sample_weight

    def __len__(self) -> int:
        if isinstance(self.data, np.ndarray):
            return len(self.data)
        elif isinstance(self.data, list):
            return len(self.data[0])
        elif isinstance(self.data, dict):
            return len(self.data[next(iter(self.data))])
        raise TypeError(
            "Input data for Keras trials must be either a NumPy array, list of NumPy "
            "arrays, or a dictionary mapping input names to NumPy arrays."
        )


def is_sequence(data: Any) -> bool:
    # We cannot directly check if data_loader is an instance of Sequence
    #   because some versions of Keras have some problems with this:
    #   https://github.com/keras-team/keras/pull/11468
    return set(dir(Sequence())).issubset(set(dir(data)))


def iter_sequence_infinite(sequence: Sequence) -> Iterator:
    while True:
        yield from sequence


def make_finite(iterator: Iterator, num_steps: int) -> Iterator:
    for _ in range(num_steps):
        yield next(iterator)


def unwrap_data(tup: Tuple) -> KerasBatch:
    if len(tup) != 2 and len(tup) != 3:
        raise TypeError(
            "Inputs to Keras trials must be of the structure `(data, labels)`"
            " or `(data, labels, sample_weight)`"
        )

    data = None
    labels = None
    sample_weight = None

    data = tup[0]
    labels = tup[1]

    if len(tup) == 3:
        sample_weight = tup[2]

    return KerasBatch(data, labels, sample_weight)


class KerasDataAdapter:
    def __init__(
        self,
        data: Union[Sequence, Iterator],
        use_multiprocessing: bool = False,
        workers: int = 1,
        max_queue_size: int = 10,
    ):
        """Data encapsulation for Keras models

        KerasDataAdapter wraps a keras.utils.Sequence which would normally be fed to
        Keras' fit_generator. This behaves the same as the data inputs to fit_generator.

        Multiprocessing or multithreading for native Python generators is not supported.
        If you want these performance accelerations, please consider using a Sequence.

        Args:
            sequence: A keras.utils.Sequence that holds the data.
            use_multiprocessing: If True, use process-based threading. If unspecified,
                `use_multiprocessing` will default to False. Note that because this implementation
                relies on multiprocessing, you should not pass non-picklable arguments for the
                data loaders as they can't be passed easily to children processes.
            workers: Maximum number of processes to spin up when using process-based threading.
                If unspecified, workers will default to 1. If 0, will execute the data loading on
                the main thread.
            max_queue_size: Maximum size for the generator queue. If unspecified, `max_queue_size`
                will default to 10.
       """
        self._max_queue_size = max_queue_size
        self._sequence = None
        self._generator = None
        self._pickled_generator = None  # type: Optional[IO]
        if is_sequence(data):
            data = cast(Sequence, data)
            self._sequence = SequenceWithOffset(data)
            if not len(data):
                raise ValueError("keras.utils.Sequence objects should have a non-zero length.")
            self._use_multiprocessing = use_multiprocessing
            self._workers = workers
        else:
            assert isinstance(data, Iterator)
            self._use_multiprocessing = False
            self._workers = 0
            cloudpickle_generators.register()
            self._generator = data

    def is_finite(self) -> bool:
        return isinstance(self._sequence, Sized)

    def __len__(self) -> int:
        if self.is_finite():
            return len(self._sequence)  # type: ignore
        raise TypeError("KerasDataAdapter does not have a finite length.")

    def start(self, batch_offset: int = 0, is_validation: bool = False) -> None:
        """Sets a batch offset and starts the pre-processing of data.

        Pre-processing of data only happens if workers >0. If the underlying data type is an
        iterator, we are unable to set a batch_offset.

        Args:
            batch_offset: Batch number to start at.
            is_validation: Whether this iterator will be used for validation. This is necessary
                because `get_iterator` usually returns an infinite iterator. When `is_validation`
                is True, the iterator stops at the end of the epoch.
        """
        self._is_validation = is_validation
        if self._sequence is not None:
            self._sequence._batch_offset = batch_offset
            if self._workers > 0:
                self._enqueuer = OrderedEnqueuer(
                    self._sequence, use_multiprocessing=self._use_multiprocessing
                )
                self._enqueuer.start(workers=self._workers, max_queue_size=self._max_queue_size)
        else:
            assert self._generator is not None
            if self._is_validation:
                self._pickled_generator = io.BytesIO()
                cloudpickle.dump(self._generator, self._pickled_generator)

    def get_iterator(self) -> Iterator:
        """Gets an Iterator over the data.

        `start` must be called prior to calling this function"
        """
        if self._sequence is not None:
            if self._is_validation:
                if self._workers > 0:
                    iterator = self._enqueuer.get()
                    return make_finite(iterator, len(self._sequence))
                return iter(self._sequence)

            if self._workers > 0:
                return self._enqueuer.get()  # type: ignore
            return iter_sequence_infinite(self._sequence)
        else:
            assert self._generator is not None
            return self._generator

    def stop(self, timeout: Optional[int] = None) -> None:
        """Stops processing the data.

        If workers is >0, this will stop any related threads and processes.
        Otherwise this is a no-op.

        Args:
            timeout: Maximum time to wait.
        """
        if self._workers > 0:
            self._enqueuer.stop(timeout=timeout)

        if self._pickled_generator is not None:
            self._pickled_generator.seek(0)
            self._generator = cloudpickle.load(self._pickled_generator)
            self._pickled_generator.close()
            self._pickled_generator = None

    def save_data_checkpoint(self, path: str) -> None:
        if self._generator is not None:
            generator_path = os.path.join(path, "generator_state.pkl")
            with open(generator_path, "wb") as f:
                self._save_generator(self._generator, f)

    def load_data_checkpoint(self, path: str) -> None:
        if self._generator is not None:
            generator_path = os.path.join(path, "generator_state.pkl")
            with open(generator_path, "rb") as f:
                self._generator = self._load_generator(f)

    def _save_generator(self, generator: Any, fileobj: IO[bytes]) -> None:
        # HACK: Keras's utility ImageDataGenerator creates generators that
        # subclass from keras.preprocessing.image.Iterator. These generators
        # include a threading.Lock() instance to prevent race conditions when
        # fit_generator() is called with multithreading enabled ('workers' >
        # 1). Since these threading.Lock() objects cannot be serialized to
        # disk, overwrite the attribute to None and create a new
        # threading.Lock() instance when restoring from checkpoint.
        if isinstance(generator, keras.preprocessing.image.Iterator):
            assert hasattr(generator, "lock")
            generator.lock = None

        cloudpickle.dump(generator, fileobj)

        if isinstance(generator, keras.preprocessing.image.Iterator):
            generator.lock = threading.Lock()

    def _load_generator(self, fileobj: IO[bytes]) -> Any:
        generator = cloudpickle.load(fileobj)
        # HACK: See comment above.
        if isinstance(generator, keras.preprocessing.image.Iterator):
            assert hasattr(generator, "lock")
            generator.lock = threading.Lock()
        return generator


def make_keras_data_adapter(
    data_loader: Any,
    batch_size: int,
    multi_input_output: bool = False,
    drop_leftovers: bool = False,
) -> KerasDataAdapter:
    if isinstance(data_loader, KerasDataAdapter):
        return data_loader

    data = None

    if is_sequence(data_loader) or isinstance(data_loader, Iterator):
        data = data_loader
    elif isinstance(data_loader, BatchLoader):
        data = BatchLoaderToSequence(
            data_loader,
            batch_size,
            multi_input_output=multi_input_output,
            drop_leftovers=drop_leftovers,
        )

    if data is None:
        raise ValueError(
            "Data loaders of type {} are not supported by KerasDataAdapter".format(
                type(data_loader).__name__
            )
        )

    return KerasDataAdapter(data)
