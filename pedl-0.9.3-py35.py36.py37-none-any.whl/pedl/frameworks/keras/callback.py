import os
from typing import Any, Dict, List

import cloudpickle
import keras

import pedl.callback


class KerasValidationCallback(keras.callbacks.Callback):  # type: ignore
    """
    Any callback inheriting from this class will be computed during the
    validation step and _not_ during the training step as normal.

    The Keras metric API makes it difficult to compute metrics, such as mAP.
    One workaround is to pass in a reference to validation data in a Keras
    callback and compute the metric in on_epoch_end():
    https://github.com/keras-team/keras/issues/4506.

    To integrate this workaround into PEDL, the validation metric callback
    should be inherit from this class and add the computed metric value to the
    `logs` argument of on_epoch_end().
    """

    pass


class KerasCallback(pedl.callback.Callback):
    def __init__(self, keras_callback: keras.callbacks.Callback) -> None:
        self._keras_callback = keras_callback
        if isinstance(keras_callback, KerasValidationCallback):
            self._training = False
            self._validation = True
            self._save_state = False
        elif isinstance(keras_callback, keras.callbacks.ReduceLROnPlateau):
            self._save_state = True
            if self._keras_callback.monitor.startswith("val_"):
                self._training = False
                self._validation = True
            else:
                self._training = True
                self._validation = False
        else:
            self._training = True
            self._validation = False
            self._save_state = False

    def on_trial_begin(self) -> None:
        self._keras_callback.on_train_begin()

    def on_train_step_begin(self, step_id: int) -> None:
        if self._training:
            self._keras_callback.on_epoch_begin(step_id)

    def on_train_step_end(self, step_id: int, metrics: List[Dict[str, Any]]) -> None:
        if self._training:
            self._keras_callback.on_epoch_end(step_id, metrics[-1])

    def on_validation_step_begin(self, step_id: int) -> None:
        if self._validation:
            self._keras_callback.on_epoch_begin(step_id)

    def on_validation_step_end(self, step_id: int, metrics: Dict[str, Any]) -> None:
        if self._validation:
            self._keras_callback.on_epoch_end(step_id, metrics)

    def set_model(self, model: keras.models.Model) -> None:
        self._keras_callback.set_model(model)

    def get_model(self) -> keras.models.Model:
        return self._keras_callback.model

    def save(self, path: str) -> None:
        if self._save_state:
            path = os.path.join(path, "{}.pkl".format(self._keras_callback.__class__.__name__))

            # Clear the model before serializing the Keras callback to disk.
            # Serializing the entire model to disk is a waste of disk space,
            # because it will get overwritten on load.
            del self._keras_callback.model
            with open(path, "wb") as f:
                cloudpickle.dump(self._keras_callback, f)

    def load(self, path: str) -> None:
        if self._save_state:
            path = os.path.join(path, "{}.pkl".format(self._keras_callback.__class__.__name__))

            # Load the entire callback state, only preserving the current
            # model attribute.
            model = self.get_model()
            with open(path, "rb") as f:
                self._keras_callback = cloudpickle.load(f)
            self.set_model(model)
