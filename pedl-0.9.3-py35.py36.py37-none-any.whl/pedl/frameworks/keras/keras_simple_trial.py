"""Trial class for simple model definitions when used with Keras.

NOTE: This class heavily relies on internal Keras APIs. Special care should be
taken when upgrading the Keras API the logic in this class is still correct.
"""


import functools
import inspect
import io
import logging
import os
import random
import sys
import tempfile
import threading
import zipfile
from typing import Any, Dict, IO, List, Optional

import cloudpickle
import cloudpickle_generators
import keras
import numpy as np
import tensorflow
from packaging import version

from pedl._types import StepID
from pedl.check import check_in, check_len, check_lt_eq, check_not_none, check_true
from pedl.frameworks.keras.callback import KerasCallback
from pedl.frameworks.keras.ordered_enqueuer import PEDLOrderedEnqueuer
from pedl.frameworks.keras.util import (
    build_multi_gpu_model,
    load_keras_optimizer_state,
    save_keras_optimizer_state,
)
from pedl.harness import EnvContext
from pedl.trial import get_container_gpus, get_trial_seed, make_metrics, TrialController

# TODO(ryan): remove this check after removing support for TensorFlow 1.13.1.
if version.parse(tensorflow.__version__) >= version.parse("1.14.0"):
    import tensorflow.compat.v1 as tf
else:
    import tensorflow as tf


class KerasSimpleTrialController(TrialController):
    class _PEDLMetricsLogger(keras.callbacks.Callback):  # type: ignore
        """
        Internal Keras callback used to track batch metrics during the Keras
        `fit_generator()` internal loop. Training metrics are saved every
        batch.
        """

        def __init__(self) -> None:
            self.training_metrics = []  # type: List[Dict[str, Any]]
            self.num_inputs = None

        def on_batch_end(self, batch: Any, logs: Optional[Dict[str, Any]] = None) -> None:
            assert logs is not None
            if "batch" in logs:
                del logs["batch"]
            if "size" in logs:
                self.num_inputs = logs["size"]
                del logs["size"]

            self.training_metrics.append(logs)

    def __init__(
        self,
        fit_generator_args: List[str],
        fit_generator_kwargs: Dict[str, Any],
        compile_args: List[str],
        compile_kwargs: Dict[str, Any],
    ) -> None:
        cloudpickle_generators.register()

        logging.debug("fit_generator args: {}".format(fit_generator_args))
        logging.debug("fit_generator kwargs: {}".format(fit_generator_kwargs))
        logging.debug("compile args: {}".format(compile_args))
        logging.debug("compile kwargs: {}".format(compile_kwargs))

        # Model will always be the first argument of fit_generator as 'self'.
        num_gpus = len(get_container_gpus())
        if num_gpus > 1:
            self.model = build_multi_gpu_model(fit_generator_args[0], num_gpus)
        else:
            self.model = fit_generator_args[0]

        self.model.compile(*compile_args[1:], **compile_kwargs)

        # Arguments to fit_generator() might be specified as positional
        # arguments or keyword arguments. If any positional arguments exist
        # migrate them to keyword arguments here.
        positional_argument_idx_to_name = dict(
            enumerate(inspect.signature(keras.engine.Model.fit_generator).parameters)
        )

        if len(fit_generator_args) > 1:
            check_lt_eq(len(fit_generator_args), 14)
            # The first argument to fit_generator is "self" (the model), and
            # can be ignored here.
            for idx, arg in enumerate(fit_generator_args[1:], start=1):
                fit_generator_kwargs[positional_argument_idx_to_name[idx]] = arg

        if "generator" not in fit_generator_kwargs:
            raise ValueError("fit_generator() call must include a generator argument.")

        if "validation_data" not in fit_generator_kwargs:
            raise ValueError("fit_generator() call must include a validation_data argument.")

        self.train_gen = fit_generator_kwargs.pop("generator")
        self.validation_gen = fit_generator_kwargs.pop("validation_data")
        self.validation_steps = fit_generator_kwargs.pop("validation_steps", None)

        self.callbacks = [KerasCallback(c) for c in fit_generator_kwargs.pop("callbacks", [])]
        for c in self.callbacks:
            assert isinstance(c, KerasCallback)
            c.set_model(self.model)

        for ignored_arg in ("epochs", "steps_per_epoch"):
            if ignored_arg in fit_generator_kwargs:
                logging.warning(
                    "'{}' argument to fit_generator() will be "
                    "ignored. Please see the 'searcher' section "
                    "in experiment configuration to control the "
                    "number of batches a model is trained "
                    "for.".format(ignored_arg)
                )
                del fit_generator_kwargs[ignored_arg]

        self.other_fit_generator_kwargs = fit_generator_kwargs

        # The Keras session to use.  In the TensorFlow setting, the default TF
        # graph (self.session.graph) is thread-local (and we might invoke Trial
        # methods from different Python threads), so we save this graph aside
        # Keras API calls.
        self.session = keras.backend.get_session()

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        """Runs a trial for one step."""
        metrics_logger_callback = self._PEDLMetricsLogger()

        # HACK: keras.utils.data_utils.OrderedEnqueuer is an internal Keras
        # class that handles queueing training examples in the multiprocessing
        # or multithreaded setting. This class faces several issues in the PEDL
        # environment and is replaced with a custom monkey-patched class to
        # amend them. See PEDLOrderedEnqueuer documentation for more details.
        logging.debug("Monkey patching Keras's OrderedEnqueuer with PEDLOrderedEnqueuer")
        keras_ordered_enqueuer = keras.engine.training_generator.OrderedEnqueuer
        keras.engine.training_generator.OrderedEnqueuer = functools.partial(
            PEDLOrderedEnqueuer, step_id, batches_per_step
        )

        with self.session.graph.as_default():
            self.model.fit_generator(
                self.train_gen,
                callbacks=[metrics_logger_callback],
                steps_per_epoch=batches_per_step,
                initial_epoch=step_id,
                epochs=step_id + 1,
                **self.other_fit_generator_kwargs
            )

        # Replace the monkey-patched version of OrderedEnqueuer with the
        # original Keras version to restore the original state. Validation
        # steps (evaluate_generator) will use the non-monkey-patched version to
        # queue examples.
        keras.engine.training_generator.OrderedEnqueuer = keras_ordered_enqueuer

        return make_metrics(
            metrics_logger_callback.num_inputs, metrics_logger_callback.training_metrics
        )

    def save_generator(self, generator: Any, fileobj: IO[bytes]) -> None:
        # HACK: Keras's utility ImageDataGenerator creates generators that
        # subclass from keras.preprocessing.image.Iterator. These generators
        # include a threading.Lock() instance to prevent race conditions when
        # fit_generator() is called with multithreading enabled ('workers' >
        # 1). Since these threading.Lock() objects cannot be serialized to
        # disk, overwrite the attribute to None and create a new
        # threading.Lock() instance when restoring from checkpoint.
        if isinstance(generator, keras.preprocessing.image.Iterator):
            assert hasattr(generator, "lock")
            generator.lock = None

        cloudpickle.dump(generator, fileobj)

    def load_generator(self, fileobj: IO[bytes]) -> Any:
        generator = cloudpickle.load(fileobj)
        # HACK: See comment above.
        if isinstance(generator, keras.preprocessing.image.Iterator):
            assert hasattr(generator, "lock")
            generator.lock = threading.Lock()
        return generator

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        # HACK: To maintain the initial state of the generator across multiple
        # invocations of compute_validation_metrics in the same trial instance,
        # the generator is pickled and restored after it is "used".
        pickled_validation_generator = io.BytesIO()
        self.save_generator(self.validation_gen, pickled_validation_generator)
        with self.session.graph.as_default():
            metrics = self.model.evaluate_generator(
                generator=self.validation_gen, steps=self.validation_steps
            )
        # Restore the state of the generator.
        pickled_validation_generator.seek(0)
        self.validation_gen = self.load_generator(pickled_validation_generator)

        # If the model defines a single metric, evaluate_generator() will
        # return a scalar value instead of a singleton list.
        if len(self.model.metrics_names) == 1:
            metrics = [metrics]

        assert len(metrics) == len(self.model.metrics_names)
        val_metrics = dict(zip(self.model.metrics_names, metrics))

        # Keras follows the convention of adding "val_" as a prefix to all
        # validation metrics.
        val_metrics = {"val_" + k: v for k, v in val_metrics.items()}

        return {"validation_metrics": val_metrics}

    def save_framework_checkpoint(self, path: str) -> None:
        # We assume that at least one training step has completed when saving a
        # checkpoint.
        check_not_none(self.model)

        os.mkdir(path)

        # Save the model architecture.
        model_path = os.path.join(path, "model.json")
        with open(model_path, "w") as model_file:
            model_file.write(self.model.to_json())

        # Save the model weights.
        weights_path = os.path.join(path, "weights.h5")
        self.model.save_weights(weights_path)

        # Save optimizer weights, if they exist.
        optimizer_weights_path = os.path.join(path, "optimizer_weights.h5")
        save_keras_optimizer_state(self.model, optimizer_weights_path)

        generator_path = os.path.join(path, "generator_state.pkl")
        with open(generator_path, "wb") as generator_file:
            self.save_generator(self.train_gen, generator_file)

    def load_framework_checkpoint(self, path: str) -> None:
        # Model should be built on class initialization.
        check_not_none(self.model)

        # Restore the model architecture by calling user-defined code, and
        # restoring weights from file.
        weights_path = os.path.join(path, "weights.h5")
        with self.session.graph.as_default():
            self.model.load_weights(weights_path)

        # Restore any optimizer state, if it exists.
        optimizer_weights_path = os.path.join(path, "optimizer_weights.h5")
        if os.path.exists(optimizer_weights_path):
            with self.session.graph.as_default():
                load_keras_optimizer_state(self.model, optimizer_weights_path)

        generator_path = os.path.join(path, "generator_state.pkl")
        with open(generator_path, "rb") as f:
            self.train_gen = self.load_generator(f)

    @staticmethod
    def set_random_seed(seed: int) -> None:
        """
        Seed all pseudo random number generators with the provided trial seed.
        """
        random.seed(seed)
        np.random.seed(seed)
        tf.set_random_seed(seed)


def load_keras_simple_trial(
    env: EnvContext, model_path: str, entrypoint_config: Dict[str, Any]
) -> KerasSimpleTrialController:
    check_true(
        zipfile.is_zipfile(model_path), "Model definition is not a zip file: {}".format(model_path)
    )
    check_in(
        "script",
        entrypoint_config,
        "Entrypoint configuration is missing 'script': {}".format(entrypoint_config),
    )

    with zipfile.ZipFile(model_path) as zf:
        # Use top-level directory as module name.
        dirnames = set()
        for name in zf.namelist():
            dirnames.add(name.split(os.sep)[0])
        check_len(dirnames, 1)
        module_name = next(iter(dirnames))

        module_path = tempfile.mkdtemp()
        zf.extractall(module_path)

    entrypoint_file = entrypoint_config["script"]
    entrypoint_args = [str(arg) for arg in entrypoint_config.get("args") or []]

    sys.path.append(module_path)
    sys.path.append(os.path.join(module_path, module_name))

    entrypoint_file = os.path.join(module_path, module_name, entrypoint_file)
    if not os.path.isfile(entrypoint_file):
        raise ValueError("Can't find file: {}".format(entrypoint_file))

    fit_generator_args = []  # type: List[Any]
    fit_generator_kwargs = {}  # type: Dict[str, Any]
    compile_args = []  # type: List[Any]
    compile_kwargs = {}  # type: Dict[str, Any]

    def _pedl_fit_generator(*args: Any, **kwargs: Any) -> None:
        nonlocal fit_generator_args, fit_generator_kwargs
        fit_generator_args = list(args)
        fit_generator_kwargs = kwargs

    def _pedl_compile(*args: Any, **kwargs: Any) -> None:
        nonlocal compile_args, compile_kwargs
        compile_args = list(args)
        compile_kwargs = kwargs

    # Save the old sys args.
    old_sys_args = sys.argv
    sys.argv = [entrypoint_file] + entrypoint_args

    # Monkey patch the keras function.
    keras_fit_generator = keras.engine.Model.fit_generator
    keras.engine.Model.fit_generator = _pedl_fit_generator
    keras_compile = keras.engine.Model.compile
    keras.engine.Model.compile = _pedl_compile

    # Seed any random number generators with the trial seed before executing
    # user code to control for any non-determinism.
    KerasSimpleTrialController.set_random_seed(get_trial_seed())

    if TrialController.is_distributed_trial(env):
        check_true(
            KerasSimpleTrialController.supports_distributed_training(),
            "Distributed multi-machine training is not supported for this "
            "framework interface. Please set slots_per_task = 1 or "
            "distributed = false.",
        )

    # Execute the file.
    try:
        entrypoint_globals = {"__name__": "__main__", "__file__": entrypoint_file}

        with open(entrypoint_file) as f:
            exec(f.read(), entrypoint_globals)

    # Restore the old sys args and undo the monkey-patch.
    finally:
        sys.argv = old_sys_args
        keras.engine.Model.fit_generator = keras_fit_generator
        keras.engine.Model.compile = keras_compile

    if len(compile_args) == 0 and len(compile_kwargs) == 0:
        raise ValueError(
            "No model.compile() call found in simple model "
            "definition. Please double-check that the "
            "entrypoint script contains a model.compile() "
            "call in it's execution path."
        )

    if len(fit_generator_args) == 0 and len(fit_generator_kwargs) == 0:
        raise ValueError(
            "No fit_generator() call found in simple model "
            "definition. Please double-check that the "
            "entrypoint script contains a fit_generator() "
            "call in it's execution path."
        )

    return KerasSimpleTrialController(
        fit_generator_args, fit_generator_kwargs, compile_args, compile_kwargs
    )
