import logging
import os
from typing import Any, Optional

import h5py  # noqa: F401
import keras
import tensorflow as tf

from pedl.check import check_true


def build_multi_gpu_model(model: Any, num_gpus: int) -> Any:
    """
    Returns a multi-GPU model using the keras.utils.multi_gpu_model API.
    """

    # The user's model code might use either top-level Keras or
    # `tensorflow.python.keras`. To support the latter case, we need to call
    # into APIs provided by `tensorflow.keras` rather than using top-level
    # Keras APIs;
    if isinstance(model, keras.models.Model):
        return keras.utils.multi_gpu_model(model, num_gpus)
    elif isinstance(model, tf.keras.models.Model):
        return tf.keras.utils.multi_gpu_model(model, num_gpus)
    else:
        raise NotImplementedError(
            "Cannot instantiate multi-GPU model with "
            "unrecognized keras model type: "
            "{}".format(type(model))
        )


def save_keras_optimizer_state(model: Any, weights_path: str) -> None:
    """
    Given a Keras model, save the optimizer state to disk if it exists. This
    should only be used with TensorFlow-backed Keras models. If no optimizer
    state is found in the model, this function will be a no-op.

    This implementation is lifted from keras.models.save_model().
    """
    if isinstance(model.optimizer, keras.optimizers.TFOptimizer):
        logging.warning(
            "TensorFlow optimizers do not "
            "make it possible to access "
            "optimizer attributes or optimizer state "
            "after instantiation. "
            "Prefer using a Keras optimizer instead "
            "(see keras.io/optimizers)."
        )
        return

    symbolic_weights = model.optimizer.weights
    if symbolic_weights is None:
        return

    logging.info("Saving optimizer state to {}".format(weights_path))

    # For some versions of TF and Keras, `batch_get_value` from
    # top-level Keras might be incompatible with models created using
    # `tensorflow.python.keras`. Hence, we fallback to using the
    # `tensorflow.python.keras` APIs if the top-level Keras call raises
    # an exception.
    try:
        weight_values = keras.backend.batch_get_value(symbolic_weights)
    except tf.errors.FailedPreconditionError:
        weight_values = tf.keras.backend.batch_get_value(symbolic_weights)

    weight_names = []
    for i, (w, _) in enumerate(zip(symbolic_weights, weight_values)):
        if hasattr(w, "name") and w.name:
            name = str(w.name)
        else:
            name = "param_" + str(i)
        weight_names.append(name.encode("utf8"))

    with h5py.File(weights_path) as f:
        f.attrs["weight_names"] = weight_names
        for name, val in zip(weight_names, weight_values):
            param_dset = f.create_dataset(name, val.shape, dtype=val.dtype)
            if not val.shape:
                # scalar
                param_dset[()] = val
            else:
                param_dset[:] = val


def load_keras_optimizer_state(model: Any, weights_path: str) -> None:
    """
    Given a compiled keras model, load it's optimizer state from the
    given weights path.

    This implementation is lifted from keras.models.load_model().
    """
    logging.info("Restoring optimizer state from {}".format(weights_path))

    # Build train function (to get weight updates).
    model._make_train_function()

    with h5py.File(weights_path) as f:
        optimizer_weight_names = [n.decode("utf8") for n in f.attrs["weight_names"]]
        optimizer_weight_values = [f[n] for n in optimizer_weight_names]

        model.optimizer.set_weights(optimizer_weight_values)


def convert_checkpoint_to_single_file(
    checkpoint_dir: str, output_file: Optional[str] = None
) -> None:
    """
    Given a PEDL checkpoint directory for a Keras model, convert the
    "weights.h5" and "model.json" files into a single file using Keras'
    model.save() API.

    If no output_file path is provided, <checkpoint_dir>/model.h5 is used.
    """
    check_true(
        os.path.exists(checkpoint_dir),
        "Checkpoint directory does not exist: '{}'".format(checkpoint_dir),
    )

    weights_path = os.path.join(checkpoint_dir, "weights.h5")
    architecture_path = os.path.join(checkpoint_dir, "model.json")
    check_true(
        os.path.exists(weights_path), "Weights path does not exist: '{}'".format(weights_path)
    )
    check_true(
        os.path.exists(architecture_path),
        "Architecture path does not exist: '{}'".format(architecture_path),
    )

    if output_file is None:
        output_file = os.path.join(checkpoint_dir, "model.h5")

    with open(architecture_path) as f:
        model = keras.models.model_from_json(f.read())
    model.load_weights(weights_path)
    model.save(output_file)
