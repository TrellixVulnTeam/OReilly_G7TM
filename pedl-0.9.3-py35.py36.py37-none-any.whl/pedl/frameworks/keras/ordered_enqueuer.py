import logging
from contextlib import closing
from typing import List

import numpy as np
from keras.utils.data_utils import _SHARED_SEQUENCES, get_index, OrderedEnqueuer, Sequence


from pedl.check import check_gt
from pedl.trial import get_trial_seed

STOP_TIMEOUT = 5


class PEDLOrderedEnqueuer(OrderedEnqueuer):  # type: ignore
    """
    The keras.utils.data_utils.OrderedEnqueuer object is used by Keras
    fit_generator and evaluate_generator functions to handle queueing data
    examples in a multiprocessing or multithreaded setting when the Sequence is
    of type keras.utils.Sequence.

    This is undesirable for use within PEDL for the following reasons:

    1) When use_multiprocessing = True, the process pool used for preprocessing
       might get closed early when there are still items being processed by the
       queue. This may lead to a race condition that ends in deadlock due to a
       multiprocessing bug.  See https://bugs.python.org/issue35267 and #2299.
    2) OrderedEnqueuer queues / shuffles random examples from the _entire_
       dataset on every invocation of _run(), in both the multiprocessing and
       multithreaded context. In PEDL, we would like to queue examples from a
       predictable slice of the dataset each training step. See #2600.

    To amend these issues, PEDLOrderedEnqueuer overrides the _run()
    implementation with one that (1) closes the multiprocessing pool only after
    waiting for the queue to empty and (2) provides the correct slice of data
    given the current PEDL step ID.
    """

    def _epoch_indices(self, num_epochs_seen: int) -> List[int]:
        """
        Given the number of epochs seen so far, return the sequence of batches
        to iterate through for the current epoch. With shuffle disabled, this
        is an ordered list of indices. With shuffle enabled, we concatenate the
        trial seed with num epochs seen such that:

        1) The same shuffle is seen consistently for this epoch no matter when
           or where this object is instantiated.
        2) The dataset is shuffled for different epochs.
        """
        indices = list(range(self._batches_in_epoch))
        if self._shuffle:
            seed = get_trial_seed() + num_epochs_seen
            logging.debug("Shuffling epoch {} with seed {}".format(num_epochs_seen, seed))
            np.random.RandomState(seed).shuffle(indices)
        return indices

    def __init__(
        self,
        step_id: int,
        batches_per_step: int,
        sequence: Sequence,
        use_multiprocessing: bool = False,
        shuffle: bool = False,
    ) -> None:
        super(PEDLOrderedEnqueuer, self).__init__(sequence, use_multiprocessing, shuffle)
        self._shuffle = shuffle
        self._batches_in_epoch = len(sequence)

        check_gt(step_id, 0)
        step_num = step_id - 1
        first_batch_in_step = step_num * batches_per_step
        num_epochs_seen = first_batch_in_step // self._batches_in_epoch

        indices = self._epoch_indices(num_epochs_seen)
        start_batch_idx = first_batch_in_step % self._batches_in_epoch
        end_batch_idx = start_batch_idx + batches_per_step

        # If a step calls for more batches than are left in an epoch, we
        # have to calculate the indices of the next epoch to complete this
        # step.
        if end_batch_idx > len(indices):
            indices.extend(self._epoch_indices(num_epochs_seen + 1))

        self._batches = indices[start_batch_idx:end_batch_idx]

    def _run(self) -> None:
        """
        Submits request to the executor and queue the `Future` objects.

        This is an override of the OrderedEnqueuer._run() function based on the
        original implementation.
        """
        self._send_sequence()  # Share the initial sequence.

        with closing(self.executor_fn(_SHARED_SEQUENCES)) as executor:
            for i in self._batches:
                self.queue.put(executor.apply_async(get_index, (self.uid, i)), block=True)
                logging.debug("Queued {}".format(i))

            # A key difference between the PEDLOrderedEnqueuer implementation
            # and the original is that we wait for the queue to join before
            # closing the multiprocessing pool. The original implementation
            # closes the pool as soon as the stop signal is set.
            logging.debug("Waiting on queue")
            self.queue.join()
            logging.debug("Queue done")

        # Call the internal on epoch end.
        self.sequence.on_epoch_end()
        self._send_sequence()  # Update the pool.

    def stop(self) -> None:
        """
        If an exception is raised during the execution of an asynchronous call,
        The _run thread will be blocked waiting on the queue to empty. If the
        queue is not empty, this could lead to a deadlock. Add a default
        timeout joining the _run thread so that the main thread isn't blocked.

        TODO(yoavz): A major downside is that the state of the run thread and
        worker processes / threads may not be properly cleaned up when
        encountering an exception. Is there a way to properly terminate these
        computations?
        """
        super(PEDLOrderedEnqueuer, self).stop(STOP_TIMEOUT)
