import logging
import os
import random
from abc import abstractmethod
from typing import Any, Dict, Iterator, List, Optional, Tuple

import keras.backend
import keras.models
import keras.optimizers
import numpy as np
import tensorflow
from keras.engine.training import Model
from keras.utils.generic_utils import Progbar
from packaging import version

from pedl._types import StepID
from pedl.check import (
    check_eq_len,
    check_gt,
    check_isinstance,
    check_len,
    check_none,
    check_not_in,
    check_not_none,
    check_true,
    check_type,
)
from pedl.frameworks.keras.data import KerasDataAdapter, make_keras_data_adapter, unwrap_data
from pedl.frameworks.keras.util import (
    build_multi_gpu_model,
    load_keras_optimizer_state,
    save_keras_optimizer_state,
)
from pedl.frameworks.util import elementwise_mean
from pedl.trial import (
    get_container_gpus,
    make_metrics,
    MetricOp,
    Reducer,
    Trial,
    TrialController,
    ValidOp,
)

# TODO(ryan): remove this check after removing support for TensorFlow 1.13.1.
if version.parse(tensorflow.__version__) >= version.parse("1.14.0"):
    import tensorflow.compat.v1 as tf
else:
    import tensorflow as tf


class KerasTrialController(TrialController):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        # TrialController.__init__() will correctly order setting random seeds, instantiating user
        # classes, etc.
        super().__init__(*args, **kwargs)

        assert isinstance(self.trial, KerasTrial)
        self.trial = self.trial  # type: KerasTrial

        # The Keras session to use. In the TensorFlow setting, the default TF
        # graph (self.session.graph) is thread-local (and we might invoke Trial
        # methods from different Python threads), so we save this graph aside
        # when the KerasTrial is constructed and use it for all subsequent
        # Keras API calls.
        self.session = tf.Session(
            graph=tf.get_default_graph(), config=self.trial.session_config(self.hparams)
        )
        keras.backend.set_session(self.session)

        # The Keras model instances this class will use for training.
        # `self.template_model` is the model returned by `self.build_model()`
        # and is used to save and load checkpoints. `self.model` is used for
        # the model computation. In the single-GPU setting,
        # `self.template_model` is the same object as `self.model`. In the
        # multi-GPU setting, they are distinct, with `self.model` wrapping
        # `self.template_model` via Keras's `multi_gpu_model`.
        #
        # These models are lazily compiled upon loading from checkpoint, or the
        # first step -- see compile_model().
        self.template_model = None  # type: Optional[Model]
        self.model = None  # type: Optional[Model]

        # Initialize and validate training metrics and validation metrics.
        self._init_metrics()

        # These will be set when the harness calls set_data_loaders().
        self.training_data_adapter = None  # type: Optional[KerasDataAdapter]
        self.validation_data_adapter = None  # type: Optional[KerasDataAdapter]
        self.training_iterator = None  # type: Optional[Iterator]
        self.validation_iterator = None  # type: Optional[Iterator]

        # TODO(ryan): Remove this compatibility layer with the old Trial API.
        super().initialize(self.env)
        self.set_data_loaders(self.data_loaders)

    def _init_metrics(self) -> None:
        # Keras always includes the training loss as the first
        # metric it returns, followed by any additional metrics that
        # were requested.
        training_metrics = self.trial.training_metrics()
        check_type(
            training_metrics,
            dict,
            "training_metrics() must be a dictionary, got {}".format(training_metrics),
        )
        check_not_in(
            "loss",
            training_metrics,
            "Please remove 'loss' metric from "
            "training_metrics(). KerasTrial will automatically "
            "include a training metric named 'loss'",
        )

        # Split up the training metric names and functions. We only pass the
        # functions into Keras itself; we then match up the results with the
        # names positionally.
        self.t_metrics_names = list(training_metrics.keys())  # type: List[str]
        self.t_metrics_funcs = list(training_metrics.values())  # type: List[MetricOp]

        validation_metrics = self.trial.validation_metrics()
        check_type(
            validation_metrics,
            dict,
            "validation_metrics() must be a dictionary, got {}".format(validation_metrics),
        )
        check_not_in(
            "loss",
            validation_metrics,
            "Please remove 'loss' metric from "
            "validation_metrics(). KerasTrial will automatically "
            "include a validation metric named 'loss'",
        )

        # Do the same with validation metrics, but also keep track of reducer
        # functions. If no reducer function is specified for a metric, use
        # elementwise_mean as a default.
        self.v_metrics_names = []  # type: List[str]
        self.v_metrics_funcs = []  # type: List[MetricOp]
        self.v_metrics_reducers = []  # type: List[Reducer]
        for name, spec in validation_metrics.items():
            self.v_metrics_names.append(name)
            if isinstance(spec, (list, tuple)):
                check_len(spec, 2)
                self.v_metrics_funcs.append(spec[0])
                self.v_metrics_reducers.append(spec[1])
            else:
                self.v_metrics_funcs.append(spec)
                self.v_metrics_reducers.append(elementwise_mean)

    def set_random_seed(self, seed: int) -> None:
        random.seed(seed)
        np.random.seed(seed)
        tf.set_random_seed(seed)

    def compile_model(self) -> None:
        with self.session.graph.as_default():
            self.template_model = self.trial.build_model(self.hparams)
            check_not_none(self.template_model, "build_model() returned None")

            num_gpus = len(get_container_gpus())
            if num_gpus > 1:
                self.model = build_multi_gpu_model(self.template_model, num_gpus)
            else:
                self.model = self.template_model

            # One unfortunate limitation of this implementation is that
            # training AND validation metrics will be computed on each step,
            # regardless of the workload kind. Keras does not offer support
            # for distinguishing training from validation metrics, nor
            # selectively computing metrics without re-compiling a model.
            #
            # NOTE: A second implementation option is to re-compile the model
            # with the correct metrics when switching between training and
            # validation steps. This would eliminate the potential cost of
            # computing unnecessary metrics, but would incur the cost of
            # recompilation at the beginning of a step and complexity of
            # tracking the state. A third option is to maintain the two
            # separate instances of a training and validation model, at the
            # cost of memory.
            self.model.compile(
                loss=self.trial.loss(),
                optimizer=self.trial.optimizer(),
                metrics=self.t_metrics_funcs + self.v_metrics_funcs,
            )

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        """Runs a trial for one step."""
        # If we don't have a compiled model yet, load and compile the
        # model now.
        assert self.training_data_adapter is not None
        if self.model is None:
            self.compile_model()
            assert self.model is not None

        # `step_id` is one-based; `step_num` is zero-based.
        check_gt(step_id, 0)
        step_num = step_id - 1
        first_batch_in_step = step_num * batches_per_step

        if self.training_iterator is None:
            # We process the data sequences from batches 0-n
            #   set a batch_offset so that we process the data in the right
            #   order
            self.training_data_adapter.start(batch_offset=first_batch_in_step)
            self.training_iterator = self.training_data_adapter.get_iterator()
            assert self.training_iterator is not None

        num_inputs = 0
        metrics = []

        progbar = Progbar(
            target=batches_per_step, interval=0.25, stateful_metrics=self.t_metrics_names
        )
        for i in range(batches_per_step):
            batch = unwrap_data(next(self.training_iterator))
            num_inputs += len(batch)

            with self.session.graph.as_default():
                # train_on_batch always includes the training loss as the first
                # metric it returns, followed by any additional metrics that
                # were requested. If no training metrics are requested, the
                # loss is returned as a scalar value. Otherwise, the metric
                # values are returned in a list.
                metrics_values = self.model.train_on_batch(
                    batch.data, batch.labels, sample_weight=batch.sample_weight
                )

            if not self.t_metrics_funcs and not self.v_metrics_funcs:
                metrics_values = [metrics_values]

            check_len(metrics_values, 1 + len(self.t_metrics_names) + len(self.v_metrics_names))
            t_metrics_values = metrics_values[: 1 + len(self.t_metrics_names)]

            batch_metrics = dict(zip(["loss"] + self.t_metrics_names, t_metrics_values))
            metrics.append(batch_metrics)
            progbar.update(i + 1, batch_metrics.items())

        logging.info(
            "Done training step: {} records in {} batches".format(num_inputs, batches_per_step)
        )

        return make_metrics(num_inputs, metrics)

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        assert self.validation_data_adapter is not None
        assert self.model is not None

        metrics = []

        self.validation_data_adapter.start(is_validation=True)
        validation_iterator = self.validation_data_adapter.get_iterator()
        assert validation_iterator is not None

        progbar_length = None
        if self.validation_data_adapter.is_finite():
            progbar_length = len(self.validation_data_adapter)
        progbar = Progbar(target=progbar_length, interval=0.5)
        progbar_idx = 0

        num_inputs = 0
        for tup in validation_iterator:
            batch = unwrap_data(tup)
            # test_on_batch always includes the validation loss as the
            # first metric it returns, followed by any additional metrics
            # that were requested. If no validation metrics other than the
            # loss are requested, the loss is returned as a scalar value.
            # Otherwise, the metric values are returned in a list.
            with self.session.graph.as_default():
                metrics_values = self.model.test_on_batch(
                    batch.data, batch.labels, sample_weight=batch.sample_weight
                )

            if not self.t_metrics_funcs and not self.v_metrics_funcs:
                metrics_values = [metrics_values]

            check_len(metrics_values, 1 + len(self.t_metrics_names) + len(self.v_metrics_names))
            v_metrics_values = [metrics_values[0]] + metrics_values[1 + len(self.t_metrics_names) :]
            metrics.append(v_metrics_values)

            num_inputs += len(batch)

            progbar_idx += 1
            progbar.update(progbar_idx)

        self.validation_data_adapter.stop()

        check_gt(len(metrics), 0)

        # The "loss" will be the first element in the v_metrics_values list,
        # followed by user-specified validation metrics.
        v_metrics_names = ["loss"] + self.v_metrics_names
        v_metrics_reducers = [elementwise_mean]  # type: List[Reducer]
        v_metrics_reducers += self.v_metrics_reducers
        reduced_metrics = [
            reducer([b[idx] for b in metrics]) for idx, reducer in enumerate(v_metrics_reducers)
        ]
        check_eq_len(v_metrics_names, reduced_metrics)
        named_metrics = dict(zip(v_metrics_names, reduced_metrics))

        return {"num_inputs": num_inputs, "validation_metrics": named_metrics}

    def save_framework_checkpoint(self, path: str) -> None:
        # We assume that at least one training step has completed when saving a
        # checkpoint.
        assert self.template_model is not None
        assert self.model is not None
        assert self.training_data_adapter is not None
        os.mkdir(path)

        # Save the model architecture.
        model_path = os.path.join(path, "model.json")
        with open(model_path, "w") as f:
            f.write(self.template_model.to_json())

        # Save the model weights.
        weights_path = os.path.join(path, "weights.h5")
        self.template_model.save_weights(weights_path)

        # Save optimizer weights, if they exist.
        save_keras_optimizer_state(self.model, os.path.join(path, "optimizer_weights.h5"))

        self.training_data_adapter.save_data_checkpoint(path)

    def load_framework_checkpoint(self, path: str) -> None:
        # If we're restoring from a checkpoint, we don't expect to
        # replace an existing model.
        check_none(self.model)
        self.compile_model()
        assert self.template_model is not None
        assert self.training_data_adapter is not None

        # Load the model weights.
        weights_path = os.path.join(path, "weights.h5")

        check_true(os.path.isfile(weights_path))
        with self.session.graph.as_default():
            self.template_model.load_weights(weights_path)

            # If any optimizer weights exist in the checkpoint path, load them
            # as well.
            optimizer_weights_path = os.path.join(path, "optimizer_weights.h5")
            if os.path.isfile(optimizer_weights_path):
                load_keras_optimizer_state(self.model, optimizer_weights_path)

        self.training_data_adapter.load_data_checkpoint(path)

    def set_data_loaders(self, data_loaders: Optional[Tuple[Any, Any]]) -> None:
        check_not_none(
            data_loaders,
            "KerasTrial requires a `make_data_loaders` function in the model definition",
        )
        assert data_loaders is not None  # get mypy to stop complaining

        type_err_msg = (
            "`make_data_loaders` must return a tuple of two BatchLoader "
            "or two keras.utils.Sequence objects"
        )

        check_isinstance(data_loaders, (tuple, list), type_err_msg)  # type: ignore
        check_len(data_loaders, 2, type_err_msg)

        self.training_data_adapter = make_keras_data_adapter(
            data_loaders[0], self.trial.batch_size(), drop_leftovers=True
        )

        # We can choose the batch size freely when evaluating the
        # validation set. For now, we use the same batch size as
        # this trial uses for training, but this could be improved.
        self.validation_data_adapter = make_keras_data_adapter(
            data_loaders[1], self.trial.batch_size()
        )


class KerasTrial(Trial):
    trial_controller_class = KerasTrialController

    @abstractmethod
    def build_model(self, hparams: Dict[str, Any]) -> keras.models.Model:
        """
        Returns a new keras `Sequential` instance configured with
        hyperparameters.
        """
        pass

    @abstractmethod
    def batch_size(self) -> int:
        """Returns the batch size to be used for training."""
        pass

    def training_metrics(self) -> Dict[str, MetricOp]:
        """
        Returns the metrics to compute at training time on a per-batch basis.
        The format is::

            {
                "metric1_name": metric1_operation,
                "metric2_name": metric2_operation,
                ...
            }

        The training loss is always computed and reported as a metric named
        "loss". Implementing this method is optional.

        The dictionary values must be valid Keras metric functions, such as
        those in the standard library or callable functions that conform to the
        "Keras custom metrics API" <https://keras.io/metrics/#custom-metrics>;
        their return values must be JSON-serializable.
        """
        return {}

    @abstractmethod
    def validation_metrics(self) -> Dict[str, ValidOp]:
        """
        Returns the metrics to compute at validation time. The format is::

            {
                "metric1_name": metric1_operation,
                "metric2_name": (metric2_operation, metric2_reducer),
                ...
            }

        The dictionary values must be either valid Keras metric functions::

            function: (predictions: tf.Tensor, labels: tf.Tensor) -> tf.Tensor

        or a pair (function, reducer) where::

            function: (prediction: tf.Tensor, labels: tf.Tensor) -> tf.Tensor
            reducer: [per-batch values] -> JSON-serializable metric.

        The first form is a valid Keras metric function that conforms to the
        "Keras custom metrics API" <https://keras.io/metrics/#custom-metrics>.
        In this form, the element-wise mean of this validation metric across
        all validation batches will be stored.

        The second form is a pair of operations; the first is a valid Keras
        metric function as described above. The second is a reducer function
        run on a list of all the intermediate results produced for this
        validation set to yield a final metric value. An example of a reducer
        function is provided in :func:`pedl.frameworks.util.elementwise_mean`;
        this is the default reduction function used if a metric is specified
        in the form above. This second form is useful if it is desirable to
        overwrite the default reduction procedure.
        """
        pass

    @abstractmethod
    def optimizer(self) -> keras.optimizers.Optimizer:
        """Returns the optimizer to be used by the model."""
        pass

    @abstractmethod
    def loss(self) -> MetricOp:
        """Returns the loss to be used by the model."""
        pass

    def session_config(self, hparams: Dict[str, Any]) -> tf.ConfigProto:
        """
        Returns the tf.ConfigProto used to configure the TensorFlow session.
        """
        return tf.ConfigProto(allow_soft_placement=True)
