"""
A collection of utility functions for PyTorch tensors; these mirror the
functions in `pedl.frameworks.util`, except for the argument types. In order to
account for the possibility of the input tensors being placed on GPUs, we
reimplement the functions here with PyTorch functions instead of wrapping the
versions from `util`.
"""

from collections import Counter
from typing import Any, Dict, List, Tuple

import torch

# `mean_reducer` is unused here; it would be exactly the same if reimplemented
# here, and we just import it to make it available for PyTorch users.
from pedl.check import check_eq, check_eq_len, check_in, check_len
from pedl.frameworks.util import mean_reducer  # noqa: F401


def sparse_multiclass_error_rate(predictions: torch.Tensor, labels: torch.Tensor) -> float:
    """Return the error rate based on dense predictions and sparse labels."""
    check_eq(predictions.shape, labels.shape)

    correct = float(torch.sum(torch.argmax(predictions, 1) == torch.argmax(labels, 1)))
    total = float(predictions.shape[0])

    return 1.0 - correct / total


def error_rate(predictions: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """Return the error rate based on dense predictions and dense labels."""
    check_eq_len(predictions, labels)
    check_len(labels.shape, 1, "Labels must be a column vector")

    return (
        1.0 - float((predictions.argmax(1) == labels.to(torch.long)).sum()) / predictions.shape[0]
    )


def error_rate_batched(predictions: torch.Tensor, labels: torch.Tensor) -> Tuple[float, int]:
    """Batched version of `error_rate`; use with `error_rate_reducer`."""
    check_eq_len(predictions, labels)
    check_len(labels.shape, 1, "Labels must be a column vector")

    return (float(torch.sum(torch.argmax(predictions, 1) == labels)), predictions.shape[0])


def error_rate_reducer(batches: List[Tuple[float, int]]) -> float:
    """Reducer for `error_rate_batched`."""
    count = sum(bsize for _, bsize in batches)
    return 1 - sum(err for err, _ in batches) / count


def binary_error_rate(predictions: torch.Tensor, labels: torch.Tensor) -> float:
    """Return the classification error rate for binary classification."""
    check_eq(predictions.shape[0], labels.shape[0])
    check_in(len(predictions.shape), [1, 2])
    if len(predictions.shape) == 2:
        check_eq(predictions.shape[1], 1)
    check_len(labels.shape, 1, "Labels must be a column vector")

    if len(predictions.shape) > 1:
        predictions = torch.squeeze(predictions)

    errors = torch.sum(labels.to(torch.long) != torch.round(predictions).to(torch.long))
    result = float(errors) / predictions.shape[0]  # type: float
    return result


def binary_error_rate_batched(predictions: torch.Tensor, labels: torch.Tensor) -> Tuple[float, int]:
    """Batched version of `binary_error_rate`; use with `mean_reducer`."""
    check_eq(predictions.shape[0], labels.shape[0])
    check_in(len(predictions.shape), [1, 2])
    if len(predictions.shape) == 2:
        check_eq(predictions.shape[1], 1)
    check_len(labels.shape, 1, "Labels must be a column vector")

    if len(predictions.shape) > 1:
        predictions = torch.squeeze(predictions)

    errors = float(torch.sum(labels != torch.round(predictions)))
    return (errors, predictions.shape[0])


def predicted_class_frequencies(
    predictions: torch.Tensor, true_labels: torch.Tensor
) -> List[Dict[str, Any]]:
    """Given an ndarray containing predicted class probabilities, returns
       the number of times each class was predicted with the highest
       probability. The return value is a list of two-element
       dictionaries: `[{"label": n_0, "count": c_0}, ...]`, meaning that
       the `n_0`'th class was predicted `c_0` times. If a class is never
       predicted, it is omitted from the return value.

       NOTE: `true_labels` is ignored.
    """
    predicted_labels = torch.argmax(predictions, 1)

    # If we don't explicitly apply `int`, `Counter` sees scalar `Tensor`s,
    # which go into different buckets even when numerically equal.
    counts = Counter(map(int, predicted_labels))

    check_eq_len(predicted_labels, predictions)
    check_len(predictions, sum(counts.values()))

    # We represent predicted label counts as a list of two-element maps as
    # follows: [{"label": n_0, "count": c_0}, ...].
    frequency_map = [{"label": key, "count": val} for key, val in sorted(counts.items())]

    return frequency_map
