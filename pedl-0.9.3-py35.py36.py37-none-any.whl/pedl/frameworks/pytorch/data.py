from typing import Dict, Iterator, Sequence, Union

import numpy as np
import torch
from torch.utils.data import BatchSampler, DataLoader


Array = Union[np.ndarray, torch.Tensor]
Data = Union[Dict[str, Array], Sequence[Array], Array]
TorchData = Union[Dict[str, torch.Tensor], Sequence[torch.Tensor], torch.Tensor]


class DataLoaderRepeater:
    """
    A class that wraps a PyTorch DataLoader to provide an infinite iterator.

    PyTorch DataLoaders provide iterators that infinite through the Dataset
    once. This adapter gives us the ability to start the iterator at an offset,
    and then iterate indefinitely from that point.
    """

    def __init__(self, data_loader: DataLoader):
        self._data_loader = data_loader
        self._is_offset = False

    def set_offset(self, offset: int) -> None:
        offset_batch_sampler = OffsetBatchSampler(self._data_loader.batch_sampler, offset)
        self._data_loader.batch_sampler = offset_batch_sampler
        self._is_offset = True

    def __iter__(self) -> Iterator:
        # Yield all the batches.
        yield from self._data_loader

        # Check if we are using OffsetBatchSampler and go to original if so.
        if self._is_offset:
            offset_batch_sampler = self._data_loader.batch_sampler
            self._data_loader.batch_sampler = offset_batch_sampler.batch_sampler
            self._is_offset = False

        # Yield forever from the data loader.
        while True:
            yield from self._data_loader


class OffsetBatchSampler(BatchSampler):  # type: ignore
    def __init__(self, batch_sampler: BatchSampler, offset: int):
        self.batch_sampler = batch_sampler
        self._offset = offset % len(self.batch_sampler)

    def __len__(self) -> int:
        return len(self.batch_sampler) - self._offset

    def __iter__(self) -> Iterator:
        iterator = iter(self.batch_sampler)
        # Skip over `self._offset` batches from `self._batch_sampler`.
        for _ in range(self._offset):
            next(iterator)
        yield from iterator


def data_length(data: Data) -> int:
    """Calculate length of data input.

    Accepts np.ndarray, torch.tensor, dictionary, or list. Recursively traverses the tree to find
    the first np.ndarray or torch.Tensor and calculates the length of it. Assumes that every "leaf"
    of the data structure is batched to the same length.
    """
    if isinstance(data, (np.ndarray, torch.Tensor)):
        return len(data)
    if isinstance(data, dict):
        if len(data) == 0:
            raise ValueError(
                "`PyTorchTrial` must have at least one `np.ndarray` or `torch.Tensor` in it's dict "
                "of inputs."
            )
        return len(next(iter(data.values())))
    if isinstance(data, list):
        if len(data) == 0:
            raise ValueError(
                "`PyTorchTrial` must have at least one `np.ndarray` or `torch.Tensor` in it's list "
                "of inputs."
            )
        return len(data[0])
    if isinstance(data, tuple):
        if len(data) == 0:
            raise ValueError(
                "`PyTorchTrial` must have at least one `np.ndarray` or `torch.Tensor` in it's tuple"
                " of inputs."
            )
        return len(data[0])
    raise TypeError("Data of incorrect type: {}".format(type(data)))
