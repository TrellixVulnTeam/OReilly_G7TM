import logging
import os
import random
from abc import abstractmethod
from typing import Any, Dict, Iterator, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from pedl._types import StepID
from pedl.check import check_eq, check_gt, check_in, check_isinstance, check_len, check_not_none
from pedl.frameworks.pytorch.data import Data, data_length, DataLoaderRepeater, TorchData
from pedl.trial import get_container_gpus, make_metrics, Trial, TrialController


class PyTorchTrialController(TrialController):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        # TrialController.__init__() will correctly order setting random seeds, instantiating user
        # classes, etc.
        super().__init__(*args, **kwargs)

        assert isinstance(self.trial, PyTorchTrial)
        self.trial = self.trial  # type: PyTorchTrial

        self.model = self.trial.build_model(self.hparams)

        n_gpus = len(get_container_gpus())
        if n_gpus > 1:
            self.device = torch.device("cuda")
            self.model = nn.DataParallel(self.model)
        elif n_gpus > 0:
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")

        for _, module in self.model.named_modules():
            if hasattr(module, "reset_parameters"):
                module.reset_parameters()

        self.model = self.model.to(self.device)
        self.optimizer = self.trial.optimizer(self.model)

        # These will be set when the harness calls set_data_loaders().
        self.training_loader = None  # type: Optional[DataLoaderRepeater]
        self.validation_loader = None  # type: Optional[DataLoader]

        self.training_iterator = None  # type: Optional[Iterator]

        # TODO(ryan): Remove this compatibility layer with the old Trial API.
        super().initialize(self.env)
        self.set_data_loaders(self.data_loaders)

    # Accept np.ndarray, torch.Tensor, or dictionary. Recursively convert any
    # ndarrays to tensors and call .to() on any tensors.
    def _to_device(self, data: Data) -> TorchData:
        if isinstance(data, dict):
            return {name: self._to_device(d) for name, d in data.items()}
        if isinstance(data, list):
            return [self._to_device(d) for d in data]
        if isinstance(data, tuple):
            return tuple(self._to_device(d) for d in data)
        if isinstance(data, np.ndarray):
            return torch.from_numpy(data).to(self.device)
        if isinstance(data, torch.Tensor):
            return data.to(self.device)
        raise ValueError("Data of incorrect type: {}".format(type(data)))

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        assert self.training_loader is not None

        # `step_id` is one-based; `step_num` is zero-based.
        check_gt(step_id, 0)
        step_num = step_id - 1
        first_batch_in_step = step_num * batches_per_step

        if self.training_iterator is None:
            self.training_loader.set_offset(first_batch_in_step)
            self.training_iterator = iter(self.training_loader)

        num_inputs = 0
        metrics = []

        # Set the behavior of certain layers (e.g., dropout) that are different
        # between training and inference.
        self.model.train()

        for _ in range(batches_per_step):
            train_data, train_labels = next(self.training_iterator)
            num_inputs += data_length(train_data)

            self.optimizer.zero_grad()
            predictions = self.model(self._to_device(train_data))
            labels = self._to_device(train_labels)
            losses = self.trial.losses(predictions, labels)
            if isinstance(losses, dict):
                check_in(
                    "loss",
                    losses,
                    "losses() must output either a single tensor of "
                    "losses or a dictionary of losses, containing the "
                    "key 'loss'.",
                )
                loss = losses["loss"]
            elif isinstance(losses, torch.Tensor):
                loss = losses
            else:
                raise ValueError(
                    "losses() must output either a single tensor of "
                    "losses or a dictionary of losses, containing the key "
                    "'loss'."
                )
            loss.backward()
            self.optimizer.step()

            # Collect training metrics for this batch in batch_metrics. The
            # loss must be a scalar, so that we can call `item` on it, but the
            # remaining training metrics might not be.
            batch_metrics = {"loss": loss.item()}
            tr_metrics = self.trial.training_metrics(predictions, labels, losses)
            check_isinstance(
                tr_metrics,
                dict,
                "training_metrics() must return a dictionary "
                "mapping string names to Tensor metrics",
            )
            for name, metric in tr_metrics.items():
                # Convert PyTorch metric values to NumPy, so that
                # `pedl._json.encode_json` handles them properly without
                # needing a dependency on PyTorch.
                if isinstance(metric, torch.Tensor):
                    metric = metric.cpu().detach().numpy()
                batch_metrics[name] = metric

            metrics.append(batch_metrics)

        logging.info(
            "Done training step: {} records in {} batches".format(num_inputs, batches_per_step)
        )

        return make_metrics(num_inputs, metrics)

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        assert self.validation_loader is not None
        batch_metrics = []
        num_inputs = 0

        with torch.no_grad():
            # Set the behavior of certain layers (e.g., dropout) that are
            # different between training and inference.
            self.model.eval()

            keys = None

            for test_data, test_labels in self.validation_loader:
                num_inputs += data_length(test_data)
                predictions = self.model(self._to_device(test_data))
                labels = self._to_device(test_labels)
                vld_metrics = self.trial.validation_metrics(
                    predictions, labels, self.trial.losses(predictions, labels)
                )
                # Verify validation metric names are the same across batches.
                if keys is None:
                    keys = vld_metrics.keys()
                else:
                    check_eq(
                        keys,
                        vld_metrics.keys(),
                        "Validation metric names must match across all batches of data.",
                    )
                check_isinstance(
                    vld_metrics,
                    dict,
                    "validation_metrics() must return a "
                    "dictionary of string names to Tensor "
                    "metrics",
                )
                batch_metrics.append(vld_metrics)

            def elementwise_mean(values: List[torch.Tensor]) -> np.ndarray:
                return np.mean(
                    np.stack(
                        [
                            v.cpu().detach().numpy() if isinstance(v, torch.Tensor) else v
                            for v in values
                        ]
                    ),
                    axis=0,
                )

            metrics = {
                name: elementwise_mean([b[name] for b in batch_metrics]) for name in keys or []
            }

        # Convert PyTorch return values to NumPy, as is done for training
        # metrics.
        for metric_name, metric_val in metrics.items():
            if isinstance(metric_val, torch.Tensor):
                metrics[metric_name] = metric_val.cpu().numpy()

        return {"num_inputs": num_inputs, "validation_metrics": metrics}

    def save_framework_checkpoint(self, path: str) -> None:
        os.makedirs(path)

        # PyTorch uses optimizer objects that take the model parameters to
        # optimize on construction, so we store and reload the `state_dict()`
        # of the model and optimizer explicitly (instead of dumping the entire
        # objects) to avoid breaking the connection between the model and the
        # optimizer.
        torch.save(self.model.state_dict(), os.path.join(path, "model.pytorch"))
        torch.save(self.optimizer.state_dict(), os.path.join(path, "optimizer.pytorch"))

    def load_framework_checkpoint(self, path: str) -> None:
        model_state = torch.load(os.path.join(path, "model.pytorch"))
        optimizer_state = torch.load(os.path.join(path, "optimizer.pytorch"))

        self.model.load_state_dict(model_state)
        self.optimizer.load_state_dict(optimizer_state)

    def set_data_loaders(self, data_loaders: Optional[Tuple[DataLoader, DataLoader]]) -> None:
        check_not_none(
            data_loaders,
            "TensorFlowTrial requires a `make_data_loaders` function in the model definition",
        )
        # Get mypy to stop complaining.
        assert data_loaders is not None

        type_err_msg = "`make_data_loaders` must return a tuple of two DataLoader objects"
        check_isinstance(data_loaders, (tuple, list), type_err_msg)  # type: ignore
        check_len(data_loaders, 2, type_err_msg)
        check_isinstance(data_loaders[0], DataLoader, type_err_msg)
        check_isinstance(data_loaders[1], DataLoader, type_err_msg)

        # For the training loader we need the ability to start iterating from
        #   an offset. DataLoaderRepeater gives us this ability. For validation
        #   we always process through a full validation set so we can reuse the
        #   original DataLoader
        self.training_loader = DataLoaderRepeater(data_loaders[0])
        self.validation_loader = data_loaders[1]

    def set_random_seed(self, seed: int) -> None:
        random.seed(seed)
        np.random.seed(seed)
        torch.random.manual_seed(seed)


class PyTorchTrial(Trial):
    trial_controller_class = PyTorchTrialController

    @abstractmethod
    def batch_size(self) -> int:
        """Returns the batch size to be used for training."""
        pass

    @abstractmethod
    def build_model(self, hparams: Dict[str, Any]) -> nn.Module:
        """
        Defines the deep learning architecture associated with a trial, which
        typically depends on the trial's specific hyperparameter settings
        stored in the `hparams` dictionary. This method returns the model as an
        an instance or subclass of `nn.Module`.

        The input to the model's `forward` method will be the `Batch.data` for
        the `Batch` that was returned by this experiment's `BatchLoader`. For
        simple models, that data will often be a plain tensor, but for
        multi-input models, it will be in the form of a dictionary of named
        inputs.

        The output of the model's `forward` method will be fed directly into
        the user-defined `losses`, `training_metrics`, and `validation_metrics`
        methods as `predictions`.
        """
        pass

    @abstractmethod
    def losses(self, predictions: TorchData, labels: TorchData) -> TorchData:
        """
        Calculates loss(es) of the model. If the model only returns a single
        loss, the output of this method can be a scalar tensor which will be
        used for backpropagation. If the model reports multiple losses, this
        method must return a dictionary of losses which contains the special
        key "loss" corresponding to a scalar tensor which will be used for
        backpropagation. The output of this method is fed directly into the
        `training_metrics` and `validation_metrics` methods.
        """
        pass

    @abstractmethod
    def optimizer(self, model: nn.Module) -> torch.optim.Optimizer:
        """
        Describes the optimizer to be used during training of the given model,
        an instance of :class:`torch.optim.Optimizer`.
        """
        pass

    def training_metrics(
        self, predictions: TorchData, labels: TorchData, losses: TorchData
    ) -> Dict[str, torch.Tensor]:
        """
        Optional method.

        Calculates and returns a dictionary mapping string names to training
        metrics. If supplied, this method defines a set of metrics to be
        computed in addition to the training loss. Metrics may be non-scalar
        tensors.
        """
        return {}

    @abstractmethod
    def validation_metrics(
        self, predictions: TorchData, labels: TorchData, losses: TorchData
    ) -> Dict[str, torch.Tensor]:
        """
        Calulates and returns a dictionary mapping string names to validation
        metrics. Metrics may be non-scalar tensors. Results from each batch of
        validation data will be averaged to compute validation metrics for a
        given model.
        """
        pass
