"""
Tensorpack has a similar issue to TF Estimators in that it wants to control your training loop:
you give it your model and it runs a function that does everything for you and can't be called more
than once. This trial class addresses the issue by creating a long-running subordinate process that
runs the training function. The main process then does very little besides tell the subordinate
process which workloads to run and return the results back to the harness.

In the subordinate process, we give Tensorpack a callback of type `ManagerCallback`, which allows us
to control what Tensorpack is doing even while inside the single long call to the training function.
At the end of each training step, the callback blocks until it receives a new workload from the main
process and then reacts accordingly.
"""

import atexit
import functools
import json
import logging
import multiprocessing
import multiprocessing.synchronize
import os
import sys
import time
from abc import abstractmethod
from typing import Any, Callable, cast, Dict, List, Optional, Tuple, Type, Union

import tensorflow as tf
import tensorpack as tp
from tensorflow.train import SessionManager
from tensorpack.callbacks.steps import MaintainStepCounter
from tensorpack.tfutils.common import get_global_step_var
from tensorpack.train.tower import TowerTrainer

from pedl import Workload
from pedl._types import StepID
from pedl.check import check_eq, check_none, check_not_none, check_true
from pedl.harness import SkipWorkloadException
from pedl.trial import (
    _get_rendezvous_info,
    CoordinatingTrialController,
    get_container_gpus,
    get_gang_addrs,
    get_gang_addrs2,
    get_rank,
    get_trial_seed,
    make_metrics,
    Trial,
)
from pedl.util import pairs

IMPOSSIBLY_LARGE_EPOCHS = 9999999999999

session_config = tp.tfutils.get_default_sess_config()


def decorates(obj: Any, attr: str) -> Callable:
    orig = getattr(obj, attr)

    def wrap(f):  # type: ignore
        @functools.wraps(f)
        def inner(*args, **kwargs):  # type: ignore
            return f(orig, *args, **kwargs)

        setattr(obj, attr, inner)

    return wrap


def is_determined_ai_tensorpack() -> bool:
    return hasattr(tp, "__is_determined_ai__")


@decorates(SessionManager, "__init__")
def set_default_recovery(orig_func, *args, **kwargs):  # type: ignore
    """
    Tensorpack instantiates a SessionManager for each worker. If a non-chief worker starts before
    the chief, it waits a certain amount of time before trying to contact the chief again. That time
    is 30 seconds by default, which is quite long; we override it to 1 second here.
    """
    kwargs.setdefault("recovery_wait_secs", 1)
    return orig_func(*args, **kwargs)


@decorates(tp.Trainer, "register_callback")
def replace_old_step_callback(orig_func, self, cb):  # type: ignore
    """
    Avoid the use of the MaintainStepCounter callback for distributed training due
    to issues with restoring the correct step value, so we maintain the step
    value ourselves.
    """
    if isinstance(cb, MaintainStepCounter):
        return
    orig_func(self, cb)


def run_ps(ready_event: multiprocessing.synchronize.Event) -> None:
    """
    Run the TF parameter server task to accommodates DistributedTrainerReplicated.
    This is intended to be run in its own process.
    """
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s:%(levelname)s [%(process)s]: %(message)s"
    )
    os.environ["CUDA_VISIBLE_DEVICES"] = ""

    logging.info(
        "Running PS, rank: {}, addrs: {}, addrs2: {}".format(
            get_rank(), get_gang_addrs(), get_gang_addrs2()
        )
    )

    cluster = tf.train.ClusterSpec({"ps": get_gang_addrs(), "worker": get_gang_addrs2()})
    server = tf.train.Server(cluster, job_name="ps", task_index=get_rank(), config=session_config)

    ready_event.set()

    # The trainer's constructor will enter the PS run loop and never return.
    if is_determined_ai_tensorpack():
        tp.DistributedTrainerReplicated([], server, 1)
    else:
        tp.DistributedTrainerReplicated([], server)


class Evaluator:
    """
    A class that defines how to compute validation metrics for a model. This can run arbitrary
    Python code for each validation.
    """

    @abstractmethod
    def set_up_graph(self, trainer: tp.Trainer) -> None:
        pass

    @abstractmethod
    def compute_validation_metrics(self) -> Dict[str, Any]:
        pass


class NamedTensorsEvaluator(Evaluator):
    """
    A class that specifies that the values of tensors with certain names should be returned as
    validation metrics.
    """

    def __init__(self, names: List[str]):
        self.names = names

    def set_up_graph(self, trainer: tp.Trainer) -> None:
        raise NotImplementedError()

    def compute_validation_metrics(self) -> Dict[str, Any]:
        raise NotImplementedError()


class ManagerCallback(tp.callbacks.Callback):  # type: ignore
    """
    ManagerCallback contains the logic for running workloads in the subordinate process.

    `_trigger_epoch` runs at the end of each Tensorpack epoch (corresponding to a PEDL step). It
    sends the batch metrics back to the main process and blocks until the main process sends
    information about the next workload to run.

    `_before_run` and `_after_run` extract the metrics from the graph.
    """

    _chief_only = False

    def __init__(
        self,
        conn: multiprocessing.connection.Connection,
        metric_names: List[str],
        evaluator: Optional[Evaluator],
        validation_metrics_names: Optional[List[str]],
    ) -> None:
        self.conn = conn
        self.metric_names = metric_names
        self.batch_metrics = []  # type: List[Dict[str, Any]]
        self.evaluator = evaluator
        self.validation_metrics_names = validation_metrics_names

    def get_tensor(self, name: str) -> Any:
        """
        Attempt to turn a name into a sensible value from the graph.
        """
        # Look for the output of an operation with the given name.
        g = tf.get_default_graph()
        try:
            x = g.get_operation_by_name(name)
            if len(x.outputs) != 1:
                raise ValueError(f"Operation {name} does not have exactly one output")
            return x.outputs[0]
        except (KeyError, ValueError):
            pass

        # Look for a tensor with the name.
        try:
            return g.get_tensor_by_name(name)
        except (KeyError, ValueError):
            pass

        # Look for an existing variable with the name.
        with tf.variable_scope("", reuse=True):
            try:
                return tf.get_variable(name)
            except (KeyError, ValueError):
                pass

        # Look in the first tower for the tensor.
        if isinstance(self.trainer, TowerTrainer):
            try:
                return self.trainer.towers.training()[0][name]
            except KeyError:
                pass

        raise ValueError("Tensor not found: {}".format(name))

    # _setup_graph, _before_run, and _after_run gather batch metrics from each
    # run (adapted from tp.callbacks.ProcessTensors).
    def _setup_graph(self) -> None:
        if self.evaluator:
            self.evaluator.set_up_graph(self.trainer)

        # Fetch the requested metrics, along with the global step for debugging.
        fetches = (
            {n: self.get_tensor(n) for n in self.metric_names},
            tf.train.get_or_create_global_step(),
        )
        self._fetch = tf.train.SessionRunArgs(fetches=fetches)

        # Set up model saving logic (taken from tp.callbacks.ModelSaver).
        self.saver = tf.train.Saver(
            max_to_keep=None, write_version=tf.train.SaverDef.V2, save_relative_paths=True
        )
        tf.add_to_collection(tf.GraphKeys.SAVERS, self.saver)

        with tf.name_scope(None):
            self.gs_val = tf.placeholder(tf.int64, shape=())
            self.gs_set_op = tf.assign(
                get_global_step_var(), self.gs_val, name="PEDL_SET_GLOBAL_STEP"
            ).op

    def _before_run(self, _: Any) -> tf.train.SessionRunArgs:
        self.before_time = time.time()
        return self._fetch

    def _after_run(self, _: Any, rv: tf.train.SessionRunValues) -> None:
        metrics, _ = rv.results
        dt = time.time() - self.before_time
        logging.info(
            f"after_run rank={get_rank()}, local step={self.trainer.local_step,}, "
            f"gs={self.trainer.global_step}, dt={dt:.6f}"
        )
        self.trainer.loop._global_step += 1
        # The results are already in dict form, since we constructed the SessionRunArgs as one.
        self.batch_metrics.append(metrics)

    def _compute_validation_metrics(self) -> Any:
        """
        Computes validation metrics using either Evaluator() or CustomInferenceRunner().
        """
        if get_rank() != 0:
            return {}

        if self.evaluator:
            check_none(self.validation_metrics_names)
            metrics = self.evaluator.compute_validation_metrics()
        else:
            assert self.validation_metrics_names
            check_not_none(self.validation_metrics_names)
            # Find our custom Inference callback.
            custom_inference_callback = None  # type: Optional[CustomInferenceRunner]
            for callback in self.trainer._callbacks.cbs:
                if isinstance(callback, CustomInferenceRunner):
                    custom_inference_callback = callback
                    break
            assert custom_inference_callback
            metrics = custom_inference_callback.trigger_on_validation_step(
                self.validation_metrics_names
            )

        return {"validation_metrics": metrics}

    def _trigger_epoch(self) -> None:
        """
        This runs at the end of each training step, sends the metrics back to the main process, and
        decides what to do next.
        """
        self.send_result(Workload.Kind.RUN_STEP, self.batch_metrics)
        self.batch_metrics = []

        while True:
            kind, args = self.recv_workload()
            if kind == Workload.Kind.RUN_STEP:
                # Move on to the next step.
                break
            elif kind == Workload.Kind.COMPUTE_VALIDATION_METRICS:
                metrics = self._compute_validation_metrics()
                self.send_result(Workload.Kind.COMPUTE_VALIDATION_METRICS, metrics)
            elif kind == Workload.Kind.CHECKPOINT_MODEL:
                assert isinstance(args, str)
                self.save_checkpoint(args)
                self.send_result(Workload.Kind.CHECKPOINT_MODEL, None)

    def save_checkpoint(self, path: str) -> None:
        # save() interprets its argument as a string prefix rather than a directory name; this tells
        # it to save everything into files inside the given directory with filenames starting with
        # "model".
        prefix = os.path.join(path, "model")
        self.trainer.sess.run(self.gs_set_op, feed_dict={self.gs_val: self.trainer.global_step})
        self.saver.save(self.trainer.sess, prefix, global_step=self.trainer.global_step)

    def send_result(self, kind: Workload.Kind, result: Any) -> None:
        self.conn.send((kind, result))

    def recv_workload(self) -> Tuple[Workload.Kind, Any]:
        return cast(Tuple[Workload.Kind, Any], self.conn.recv())


class CustomInferenceRunner(tp.InferenceRunner):  # type: ignore
    """
    CustomInferenceRunner is the callback that is used when users
    specify validation metrics rather than using Evaluator().
    Unlike `tp.InferenceRunner` this callback will run on every
    RUN_VALIDATION. `tp.InferenceRunner` would run after every RUN_STEP.
    """

    def _trigger(self) -> None:
        """
        Overwrites the `tp.InferenceRunner._trigger()` for `trigger_on_validation_step()`.
        """
        pass

    def trigger_on_validation_step(self, validation_metrics_names: List[str]) -> Any:
        """
        Called by `ManagerCallback` for each RUN_VALIDATION step.
        """

        super()._trigger()

        validation_metrics = {}
        for validation_metrics_name in validation_metrics_names:
            validation_metrics[validation_metrics_name] = self.trainer.monitors.get_latest(
                validation_metrics_name
            )
        return validation_metrics


class CustomScalarStats(tp.ScalarStats):  # type: ignore
    """
    CustomScalarStats is the callback used for monitoring stats when
    users specify validation metrics rather than using Evaluator().
    """

    def names_with_prefix(self) -> List[str]:
        names = []
        for name in self.names:
            names.append(f"{self.prefix}_{name}")
        return names


class InterProcessArgs(object):
    def __init__(
        self,
        rendezvous_info: Dict[str, Any],
        hparams: Dict[str, Any],
        trial_type: Type,
        load_path: Optional[str],
        step_id: StepID,
        batches_per_step: int,
    ):
        self.rendezvous_info = rendezvous_info
        self.hparams = hparams
        self.trial_type = trial_type
        self.load_path = load_path
        self.step_id = step_id
        self.batches_per_step = batches_per_step


class TensorPackTrialController(CoordinatingTrialController):
    def __init__(self, *args: Any) -> None:
        self.conn, conn2 = multiprocessing.Pipe(duplex=True)
        super().__init__(*args, conn2)

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        args = None

        if self._is_first_step:
            self._is_first_step = False

            args = InterProcessArgs(
                _get_rendezvous_info(),
                self.hparams,
                self.trial_class,
                self._load_path,
                step_id,
                batches_per_step,
            )

        batch_metrics = self._run_workload(Workload.Kind.RUN_STEP, args)

        if get_rank() != 0:
            raise SkipWorkloadException()

        return make_metrics(None, batch_metrics)

    def _run_workload(self, kind: Workload.Kind, args: Any = None) -> Any:
        """
        The primary method for communicating with the subordinate process. It sends the given
        workload to the subprocess and waits for a response containing the result.
        """
        self.conn.send((kind, args))
        kind2, ret = self.conn.recv()
        if kind2 is None:
            logging.info(f"Train process exited")
            exit()
        logging.info(f"Main process got result for kind {kind}: {ret}")
        check_eq(kind2, kind, f"args: {args}, return value: {ret}")
        return ret

    def set_random_seed(self, seed: int) -> None:
        # For distributed training each machine needs to use a unique
        # random seed so that the dataset is processed in a unique order.
        # TODO(DET-1124): Re-enable random seeds.
        # rank_random_seed = seed + get_rank()
        # random.seed(rank_random_seed)
        # np.random.seed(rank_random_seed)
        # tf.set_random_seed(rank_random_seed)
        # tp.utils.fix_rng_seed(rank_random_seed)
        pass

    @staticmethod
    def make_subprocess(*subprocess_args: Any) -> "TensorpackTrainProcess":
        return TensorpackTrainProcess(*subprocess_args)

    @staticmethod
    def supports_distributed_training() -> bool:
        return True

    def load_framework_checkpoint(self, path: str) -> None:
        super().load_framework_checkpoint(path)
        assert self._load_path
        self._load_path = os.path.join(self._load_path, "checkpoint")


class TensorpackTrial(Trial):
    trial_controller_class = TensorPackTrialController

    @abstractmethod
    def build_model(self, hparams: Dict[str, Any]) -> tp.ModelDesc:
        """Returns the Tensorpack ModelDesc describing the model."""
        pass

    def training_metrics(self) -> List[str]:
        """Returns a list of names of tensors to use as training metrics in addition te the loss."""
        return []

    @abstractmethod
    def validation_metrics(self) -> Union[List[str], Evaluator]:
        """
        Returns either an Evaluator object that computes the validation metrics or a list of tensor
        names to use.
        """
        pass

    def tensorpack_callbacks(self) -> List[tp.Callback]:
        """Returns a list of Tensorpack callbacks to use during training."""
        return []

    @abstractmethod
    def train_dataflow(self, hparams: Dict[str, Any]) -> tp.DataFlow:
        """Returns the DataFlow to use for training data."""
        pass

    def validation_dataflow(self, hparams: Dict[str, Any]) -> tp.DataFlow:
        """Returns the DataFlow to use for validation data."""
        pass

    def load_backbone_weights(self) -> Optional[str]:
        """Returns the path to backbone weights"""
        return None


class TensorpackTrainProcess(multiprocessing.context.SpawnProcess):
    """
    The subordinate process that actually runs Tensorpack training. After doing some setup, it
    spends the rest of its life in a call to Tensorpack's `train_with_defaults` function.
    """

    def __init__(self, conn: multiprocessing.connection.Connection) -> None:
        super().__init__(name="tensorpack-training-process")
        self.conn = conn

        # These will be set by the initial connection message.
        self.hparams = None  # type: Optional[Dict[str, Any]]
        self.trial_class = None  # type: Optional[Type]
        self.first_step = None  # type: Optional[int]
        self.batches_per_step = None  # type: Optional[int]
        self.session_init = None  # type: Optional[Any]
        self.load_path = None  # type: Optional[str]

    def set_random_seed(self, seed: int) -> None:
        # For distributed training each machine needs to use a unique
        # random seed so that the dataset is processed in a unique order.
        # TODO(DET-1124): Re-enable random seeds.
        # rank_random_seed = seed + get_rank()
        # random.seed(rank_random_seed)
        # np.random.seed(rank_random_seed)
        # tf.set_random_seed(rank_random_seed)
        # tp.utils.fix_rng_seed(rank_random_seed)
        pass

    def config(self, args: InterProcessArgs) -> None:
        os.environ["PEDL_RENDEZVOUS_INFO"] = json.dumps(args.rendezvous_info)
        self.hparams = args.hparams
        self.trial_class = args.trial_type
        self.first_step = args.step_id
        self.batches_per_step = args.batches_per_step
        self.load_path = args.load_path

    def run(self) -> None:
        logging.basicConfig(
            level=logging.INFO, format="%(asctime)s:%(levelname)s [%(process)s]: %(message)s"
        )

        try:
            self._run()
        except Exception:
            logging.exception(f"Tensorpack training process exception")
        finally:
            logging.info(f"Train process exiting")
            self.conn.send((None, None))

    def _run(self) -> None:
        # Wait for setup information from the main process.
        kind, args = self.conn.recv()

        check_eq(kind, Workload.Kind.RUN_STEP)
        check_not_none(args)

        logging.info(f"Training process got config arguments {args}")
        self.config(args)

        assert self.hparams
        assert self.trial_class
        assert self.first_step
        assert issubclass(self.trial_class, TensorpackTrial)
        trial = self.trial_class(self.hparams)  # type: TensorpackTrial

        if self.load_path is None:
            # If not loading from checkpoint check if backbone weights are specified.
            self.load_path = trial.load_backbone_weights()

        if self.load_path is None:
            logging.info(f"Not loading model")
            self.session_init = None
        else:
            logging.info(f"Loading model from {self.load_path}")
            self.session_init = tp.get_model_loader(self.load_path)

        self.set_random_seed(get_trial_seed())
        logging.info(f"Calling build_model")
        model = trial.build_model(self.hparams)
        logging.info(f"Finished build_model")

        aggregation_frequency = self.hparams.get("aggregation_frequency", 1)
        determined_ai_tensorpack = is_determined_ai_tensorpack()

        if not determined_ai_tensorpack and aggregation_frequency > 1:
            logging.critical(
                f"Gradient aggregation is only supported for custom DAI version of tensorpack"
            )
            sys.exit(1)

        num_gpus = len(get_container_gpus())
        if len(get_gang_addrs()) > 1:
            logging.info(
                f"Starting distributed training, rank {get_rank()}, "
                f"addrs {get_gang_addrs()}, addrs2 {get_gang_addrs2()}"
            )
            cluster = tf.train.ClusterSpec({"ps": get_gang_addrs(), "worker": get_gang_addrs2()})
            server = tf.train.Server(
                cluster, job_name="worker", task_index=get_rank(), config=session_config
            )

            ready_event = multiprocessing.Event()
            ps_proc = multiprocessing.get_context("spawn").Process(
                target=run_ps, args=(ready_event,)
            )
            ps_proc.start()
            logging.info(
                f"Started PS rank {get_rank()} with PID {ps_proc.pid}, "
                f"waiting for it to be ready"
            )

            # The PS needs to start gRPC before the workers, or else the connection from this end
            # fails, raising a very unhelpful error ("OS Error"); this waits for the PS process to
            # signal that it is ready. It sets `ready_event` as late as possible before entering
            # TF/gRPC code, but it's sometimes not early enough, so wait a bit more even after that.
            ready_event.wait()
            time.sleep(2)
            logging.info(f"Done waiting for PS rank {get_rank()}")

            @atexit.register
            def end() -> None:
                logging.info(f"Train process killing and joining PS process")
                ps_proc.terminate()
                ps_proc.join()
                logging.info(f"Train process exiting")

            # TODO: Be able to set average mode.
            if determined_ai_tensorpack:
                trainer = tp.DistributedTrainerReplicated(num_gpus, server, aggregation_frequency)
            else:
                trainer = tp.DistributedTrainerReplicated(num_gpus, server)
        else:
            # TODO: Allow specifying the value of average.
            trainer = tp.SyncMultiGPUTrainerReplicated(num_gpus, average=False, mode="nccl")

        train_df = trial.train_dataflow(self.hparams)
        inp = tp.QueueInput(train_df)

        # StagingInput causes deadlocks in some code, so allow it to be disabled. TODO: Figure out
        # why.
        if not self.hparams.get("disable_staging_area"):
            inp = tp.StagingInput(inp, 1)

        logging.info(f"Calling setup_graph")
        trainer.setup_graph(
            model.get_input_signature(), inp, model.build_graph, model.get_optimizer
        )
        logging.info(f"Finished setup_graph")

        # For validation we support users specifying an Evaluator(), or passing in
        # the validation metrics they want to track. If they pass in validation
        # metrics, we create a custom InferenceRunner() callback. FasterRCNN uses the
        # Evaluator(), while all other Tensorpack example models use InferenceRunner.
        evaluator = None  # type: Optional[Evaluator]
        validation_metrics_names = None  # type: Optional[List[str]]
        inference_runner_callback = None  # type: Optional[CustomInferenceRunner]
        evaluator_or_validation_metrics = trial.validation_metrics()
        if isinstance(evaluator_or_validation_metrics, list):
            check_true(hasattr(trial, "validation_dataflow"))
            validation_dataflow = trial.validation_dataflow(self.hparams)
            validation_scalar_stats = CustomScalarStats(
                evaluator_or_validation_metrics, prefix="val"
            )
            validation_metrics_names = validation_scalar_stats.names_with_prefix()
            inference_runner_callback = CustomInferenceRunner(
                validation_dataflow, validation_scalar_stats
            )
        else:
            evaluator = evaluator_or_validation_metrics

        metrics = ["loss", *trial.training_metrics()]

        if self.hparams.get("include_summary_metrics"):
            metrics.extend(t.op.inputs[1].name for t in tf.get_collection(tf.GraphKeys.SUMMARIES))

        manager_cb = ManagerCallback(self.conn, metrics, evaluator, validation_metrics_names)

        # TODO: check to make sure users don't pass in InferenceRunner
        # because that will run validation after every RUN_STEP.
        cbs = [manager_cb, *trial.tensorpack_callbacks()]
        if inference_runner_callback:
            cbs.append(inference_runner_callback)

        logging.info(f"Rank {get_rank()} calling train_with_defaults")

        trainer.train_with_defaults(
            callbacks=cbs,
            steps_per_epoch=self.batches_per_step,
            starting_epoch=self.first_step,
            max_epoch=self.first_step + IMPOSSIBLY_LARGE_EPOCHS,
            session_init=self.session_init,
        )


class SchedulePoint:
    def __init__(self, point: int, value: float, interp: Optional[str] = None) -> None:
        self.point = point
        self.value = value
        self.interp = interp

    def __repr__(self) -> str:
        return f"SchedulePoint(point={self.point}, value={self.value}, interp={self.interp})"


class ScheduleSetter(tp.callbacks.HyperParamSetter):  # type: ignore
    """
    Hyperparameter setter callback for step-based points that (1) does the right
    thing when resuming training from the middle by computing the value on
    every step and (2) can handle different interpolations.
    """

    def __init__(self, param: Any, schedule: List[SchedulePoint]) -> None:
        super().__init__(param)
        self.schedule = schedule
        logging.info(f"ScheduleSetter created with schedule {schedule}")

    def _get_value_to_set(self) -> float:
        v = self._real_get_value_to_set()
        logging.info(f"Param setter: step={self.global_step} value={v}")
        return v

    def _real_get_value_to_set(self) -> float:
        step = self.global_step  # type: int
        for p0, p1 in pairs(self.schedule):
            if p0.point <= step < p1.point:
                if p0.interp is None:
                    return p0.value
                elif p0.interp == "linear":
                    t = (step - p0.point) / (p1.point - p0.point)
                    return p0.value + (p1.value - p0.value) * t

                raise ValueError(f"Unknown interpolation type: {p0.interp}")
        return self.schedule[-1].value

    def _trigger_step(self) -> None:
        self._trigger()

    def _trigger_epoch(self) -> None:
        pass
