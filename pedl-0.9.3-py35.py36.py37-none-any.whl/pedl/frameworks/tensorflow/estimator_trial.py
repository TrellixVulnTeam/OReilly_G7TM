"""
The TF Estimator API has issues around multiple invocations:

- In order to take advantage of the TF Estimator API's built-in distributed
  training, we need to use the `train_and_evaluate` method of an Estimator;
  `train` doesn't support it. However, `train_and_estimator` has the issue that
  workers enter an event loop and do not return.
- When serializing functions, `tf.data.Dataset.map` appends a unique identifier
  to function names. The identifier counter is maintained per process. The
  `input_fn` of an estimator is called per `train` call. This creates an
  inconsistency between function names and the checkpointed function names when
  `train` is called multiple times in the same process.

While it is possible to add even more monkey patching to make it work, it
ultimately seems more elegant to give the TensorFlow API what it wants: we
spawn a subprocess to run each workload, passing results back to the parent via
IPC.

This overall approach has a measurable performance impact. Spawning new
processes incurs re-initialization costs in TensorFlow and its dependencies,
and `train_and_evaluate` itself loads and saves checkpoints each invocation.
"""

import logging
import os
import random
import shutil
import tempfile
from abc import abstractmethod
from typing import Any, Callable, Dict, List, Union

import numpy as np
import tensorflow
from packaging import version

from pedl._types import StepID
from pedl.check import check_isinstance
from pedl.harness import SkipWorkloadException
from pedl.multiprocessing import run_in_process
from pedl.trial import make_metrics, Trial, TrialController
from pedl.util import get_experiment_config

from .mirrored_strategy import (
    _supports_distributed_training,
    is_chief,
    is_local,
    prepare_estimator_subprocess,
)
from .util import (
    delete_all_checkpoints_except_most_recent,
    delete_tf_events,
    update_checkpoint_path_in_state_file,
)

# TODO(ryan): remove this check after removing support for TensorFlow 1.13.1.
if version.parse(tensorflow.__version__) >= version.parse("1.14.0"):
    import tensorflow.compat.v1 as tf
else:
    import tensorflow as tf


# The optional interface for specifying serving input receiver functions to
# export SavedModels expects the following function type.
ServingInputReceiverFn = Callable[
    ...,
    Union[tf.estimator.export.ServingInputReceiver, tf.estimator.export.TensorServingInputReceiver],
]


class _MetricsSessionRunHook(tf.train.SessionRunHook):  # type: ignore
    def __init__(self) -> None:
        self._metrics = []  # type: List[Dict[str, Any]]

    def begin(self) -> None:
        self._summary_op = tf.summary.merge_all()

    def before_run(self, run_context: tf.train.SessionRunContext) -> tf.train.SessionRunArgs:
        return tf.train.SessionRunArgs({"summary": self._summary_op})

    def after_run(
        self, run_context: tf.train.SessionRunContext, run_values: tf.train.SessionRunValues
    ) -> None:
        assert "summary" in run_values.results
        summary = tf.summary.Summary()
        summary.ParseFromString(run_values.results["summary"])
        batch_metrics = {}  # type: Dict[str, Any]
        for val in summary.value:
            if val.HasField("simple_value"):
                batch_metrics[val.tag] = val.simple_value
            elif val.HasField("tensor"):
                batch_metrics[val.tag] = tf.make_ndarray(val.tensor)

        self._metrics.append(batch_metrics)

    def batch_metrics(self) -> List[Dict[str, Any]]:
        return self._metrics


class EstimatorControllerBase(TrialController):
    @staticmethod
    def supports_distributed_training() -> bool:
        return _supports_distributed_training()

    def set_random_seed(self, seed: int) -> None:
        # TODO(ryan): since we are setting random seeds before every step, the seed should probably
        # be something like `trial_seed + num_workers*step_id + worker_id`.
        random.seed(seed)
        np.random.seed(seed)
        # N.B., this seed value will be overwritten by
        # tf.estimator.RunConfig.tf_random_seed.
        tf.set_random_seed(seed)


class EstimatorTrialController(EstimatorControllerBase):
    """
    A class which implements the TrialController interface, but which mostly launches subprocesses.
    Estimators really want to be run in their own process for every invocation, and we appease them
    by doing exactly that.

    To support the widest range of user code possible, EstimatorTrialController does not have to
    be serializable, and the instance of the user's EstimatorTrial does not either; in every child
    process a new EstimatorSubprocessController and a new user's EstimatorTrial are instantiated.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        # TrialController.__init__() will correctly order setting random seeds, instantiating user
        # classes, etc.
        super().__init__(*args, **kwargs)

        assert isinstance(self.trial, EstimatorTrial)
        self.trial = self.trial  # type: EstimatorTrial

        self.model_dir = tempfile.mkdtemp()

        self.trampoline = EstimatorTrampoline(self.model_dir, args, kwargs)

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        metrics = self.trampoline.train_for_step(step_id, batches_per_step)

        # We rely on chief to update trial state.
        if not (is_local() or is_chief()):
            raise SkipWorkloadException()
        return metrics

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        if not (is_local() or is_chief()):
            raise SkipWorkloadException()
        return self.trampoline.compute_validation_metrics(step_id)

    def save_framework_checkpoint(self, path: str) -> None:
        """
        The TensorFlow Estimator instance will control the saving of
        checkpoints during the train() call to a model directory specified in
        the constructor (a temporary directory by default). train_for_step()
        will ensure that all but the most recent checkpoint will be deleted
        from this directory.

        To save a checkpoint, we copy the state of the model directory to the
        checkpoint directory and ensure the CheckpointState metadata file is
        calibrated to the new location.
        """
        if not (is_local() or is_chief()):
            raise SkipWorkloadException()
        return self.trampoline.save_framework_checkpoint(path)

    def load_framework_checkpoint(self, path: str) -> None:
        """
        HACK: To "restore" the checkpoint, replace the Estimator model
        directory with the PEDL checkpoint directory. There will only be a
        single checkpoint in the PEDL checkpoint directory. We also ensure the
        CheckpointState metadata file is calibrated to the new directory
        location.
        """
        # If the Estimator has not been trained, the existing model directory
        # might not yet exist -- in this case it does not need to be removed.
        if os.path.exists(self.model_dir):
            shutil.rmtree(self.model_dir)
        shutil.copytree(path, self.model_dir)

        # Calibrate the CheckpointState metadata file to the new location.
        update_checkpoint_path_in_state_file(self.model_dir)

    @staticmethod
    def supports_distributed_training() -> bool:
        return _supports_distributed_training()


class EstimatorTrampoline:
    """
    A class to separate the parts of EstimatorController which must be serializable so that they
    may be pased into a child process. Presently, those parts are the arguments used to create
    the EstimatorSubprocessController and the arguments to each method.
    """

    def __init__(self, model_dir: str, args: Any, kwargs: Any):
        self.model_dir = model_dir
        self.args = args
        self.kwargs = kwargs

    @run_in_process
    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        prepare_estimator_subprocess(self.model_dir)
        controller = EstimatorSubprocessController(self.model_dir, *self.args, **self.kwargs)
        return controller.train_for_step(step_id, batches_per_step)

    @run_in_process
    def save_framework_checkpoint(self, path: str) -> None:
        prepare_estimator_subprocess(self.model_dir)
        controller = EstimatorSubprocessController(self.model_dir, *self.args, **self.kwargs)
        return controller.save_framework_checkpoint(path)

    @run_in_process
    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        prepare_estimator_subprocess(self.model_dir)
        controller = EstimatorSubprocessController(self.model_dir, *self.args, **self.kwargs)
        return controller.compute_validation_metrics(step_id)


class EstimatorSubprocessController(EstimatorControllerBase):
    def __init__(self, model_dir: str, *args: Any, **kwargs: Any) -> None:
        # TrialController.__init__() will correctly order setting random seeds, instantiating user
        # classes, etc.
        super().__init__(*args, **kwargs)

        assert isinstance(self.trial, EstimatorTrial)
        self.trial = self.trial

        self.model_dir = model_dir

        self.estimator = self.trial.build_estimator(self.hparams)
        check_isinstance(
            self.estimator,
            tf.estimator.Estimator,
            "Please modify your model definition's build_estimator() implementation",
        )

        self.train_spec = self.trial.build_train_spec(self.hparams)
        check_isinstance(
            self.train_spec,
            tf.estimator.TrainSpec,
            "Please modify your model definition's build_train_spec() implementation",
        )

        self.val_spec = self.trial.build_validation_spec(self.hparams)
        check_isinstance(
            self.val_spec,
            tf.estimator.EvalSpec,
            "Please modify your model definition's build_validation_spec() implementation",
        )

        self.serving_input_receiver_fns = self.trial.build_serving_input_receiver_fns(self.hparams)

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        metrics_hook = _MetricsSessionRunHook()
        all_hooks = [*self.train_spec.hooks, metrics_hook]

        # The follwoing skip_checkpointing_input flag is a workaround for
        # stateful datasets in TF 1.14. Stateful input pipeline functions
        # cannot be serialized and therefore checkpointing them should be
        # skipped.
        config = get_experiment_config()
        skip_checkpointing_input = config.get("data", {}).get("skip_checkpointing_input", False)

        if not skip_checkpointing_input:
            all_hooks.append(tf.data.experimental.CheckpointInputPipelineHook(self.estimator))

        # Until we fix DET-376 (reliably skipping evaluation in
        # `train_and_evaluate`), we are maintaining a separate codepath for
        # training non-distributed trials.
        if is_local():
            self.estimator.train(
                input_fn=self.train_spec.input_fn, steps=batches_per_step, hooks=all_hooks
            )
        else:
            train_spec = tf.estimator.TrainSpec(
                input_fn=self.train_spec.input_fn,
                max_steps=step_id * batches_per_step,
                hooks=all_hooks,
            )

            # With a single worker and multiple devices, `train_and_evaluate`
            # attempts to execute `eval_spec` even if `input_fn` is None, which
            # causes an error evaluating the model function. Until we can find
            # an easy way to skip it, just evaluate for one step.
            eval_spec = tf.estimator.EvalSpec(self.val_spec.input_fn, steps=1)

            tf.estimator.train_and_evaluate(self.estimator, train_spec, eval_spec)

            self.collect_worker_checkpoints_from_subdirectories(self.estimator._model_dir)

        metrics = metrics_hook.batch_metrics()

        # By default the Estimator API is configured to accumulate checkpoints
        # in the model directory after every train() invocation. To avoid
        # wasting disk space, we delete all but the most recent checkpoint at
        # the end of each training step. A checkpoint is always computed at the
        # end of the train() invocation, so this checkpoint is guaranteed to be
        # the most recent state of the model.
        delete_all_checkpoints_except_most_recent(self.estimator._model_dir)

        # Likewise, the Estimator API writes event logs every checkpoint (or
        # more). There doesn't appear to be a direct way to avoid writing them,
        # so delete them after the fact.
        delete_tf_events(self.estimator._model_dir)

        # TODO(yoavz): Figure out a way to retrieve num_inputs.
        # - 16-Jan-2019: Input is defined
        #   implicitly. Intercepting this information from
        #   self.train_spec.input_fn may be too much trouble right now since no
        #   one depends on num_inputs.
        num_inputs = None
        return make_metrics(num_inputs, metrics)

    def collect_worker_checkpoints_from_subdirectories(self, model_dir: str) -> None:
        """
        To avoid a possible deadlock due to a collective operation during checkpoint,
        the `tf.estimator` code executes checkpoint operations on the
        chief and all workers, and to avoid workers clobbering checkpoints due to
        a shared model directory, workers are configured to write their checkpoints
        to a junk subdirectory of the model directory (e.g., `tmp_worker_1").

        Since, (1) these checkpoints contain the global step number, which is required
        to resume a trial, and (2) for distributed training, the model directory is
        certainly not shared, we simply move the contents of the junk directory, if
        present, back into the model directory.
        """
        subdirs = [f.path for f in os.scandir(model_dir) if f.is_dir()]
        for d in subdirs:
            for f in os.scandir(d):
                dst = os.path.join(model_dir, os.path.basename(f.name))
                if os.path.exists(dst):
                    logging.info("Replacing %s in %s", f.path, model_dir)
                    os.remove(dst)
                shutil.move(f.path, dst)
            os.rmdir(d)

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        metrics = self.estimator.evaluate(
            input_fn=self.val_spec.input_fn, steps=self.val_spec.steps, hooks=self.val_spec.hooks
        )
        logging.info("Validation metrics: %s", metrics)
        return {"validation_metrics": metrics}

    def save_framework_checkpoint(self, path: str) -> None:
        checkpoint_dir = os.path.dirname(self.estimator.latest_checkpoint())
        shutil.copytree(checkpoint_dir, path)

        for name, fn in self.serving_input_receiver_fns.items():
            logging.info(
                "Found a serving input receiver function '{}'"
                ", exporting as a SavedModel".format(name)
            )
            self.estimator.export_savedmodel(os.path.join(path, name), fn)

        # Calibrate the CheckpointState metadata file to the new location.
        update_checkpoint_path_in_state_file(path)

    def load_framework_checkpoint(self, path: str) -> None:
        # Checkpoint loading is accomplished by the EstimatorController passing the checkpoint in
        # via the model_dir.
        pass


class EstimatorTrial(Trial):
    trial_controller_class = EstimatorTrialController

    @abstractmethod
    def build_estimator(self, hparams: Dict[str, Any]) -> tf.estimator.Estimator:
        pass

    @abstractmethod
    def build_train_spec(self, hparams: Dict[str, Any]) -> tf.estimator.TrainSpec:
        pass

    @abstractmethod
    def build_validation_spec(self, hparams: Dict[str, Any]) -> tf.estimator.EvalSpec:
        pass

    def build_serving_input_receiver_fns(
        self, hparams: Dict[str, Any]
    ) -> Dict[str, ServingInputReceiverFn]:
        return {}
