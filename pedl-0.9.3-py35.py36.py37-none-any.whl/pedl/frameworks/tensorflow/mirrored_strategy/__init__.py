import tensorflow as tf
from packaging import version

from .util import is_chief, is_local, monkey_patch_run_config

if version.parse(tf.__version__) < version.parse("1.14.0"):
    from .mirrored_strategy_unsupported import (
        prepare_estimator_subprocess,
        _supports_distributed_training,
    )
else:
    from .mirrored_strategy import prepare_estimator_subprocess, _supports_distributed_training
