import os
from typing import Dict, List

import simplejson as json
import tensorflow as tf

from pedl.trial import get_gang_addrs, get_rank, get_trial_seed

from .util import is_local, monkey_patch_run_config


def _supports_distributed_training() -> bool:
    return True


def prepare_estimator_subprocess(model_dir: str) -> None:
    rank = get_rank()
    addrs = get_gang_addrs()

    strategy = None
    if not is_local():
        strategy = tf.distribute.experimental.MultiWorkerMirroredStrategy()

    os.environ.update(make_environ(rank, addrs))

    monkey_patch_run_config(model_dir, strategy, get_trial_seed(), rank)


def make_environ(rank: int, addrs: List[str]) -> Dict[str, str]:
    # In TF 1.13, setting TF_CONFIG when training on a single node makes
    # tf.distribute.MirroredStrategy follow its distributed training code
    # path, which causes internal invariants in reduction code to fail.
    if len(addrs) <= 1:
        return {}

    cluster = {"chief": addrs[:1], "worker": addrs[1:]}
    if rank == 0:
        task = {"type": "chief", "index": 0}
    else:
        task = {"type": "worker", "index": rank - 1}

    return {"TF_CONFIG": json.dumps({"cluster": cluster, "task": task})}
