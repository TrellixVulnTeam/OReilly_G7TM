import tensorflow as tf

from pedl.trial import get_trial_seed

from .util import is_local, monkey_patch_run_config


def _supports_distributed_training() -> bool:
    raise NotImplementedError(
        "Distributed Training is not supported for TensorFlow {}.  Please set slots_per_task = 1 "
        "or distributed = false.".format(tf.__version__)
    )


def prepare_estimator_subprocess(model_dir: str) -> None:
    if not is_local():
        raise NotImplementedError(
            "Distributed Training is not supported for TensorFlow {}.  Please set slots_per_task "
            "= 1 or distributed = false.".format(tf.__version__)
        )

    monkey_patch_run_config(model_dir, None, get_trial_seed(), 0)
