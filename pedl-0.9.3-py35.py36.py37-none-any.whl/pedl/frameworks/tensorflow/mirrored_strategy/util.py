from typing import Any, Callable

import tensorflow as tf

from pedl.trial import get_container_gpus, get_gang_addrs, get_rank
from pedl.util import decorate


def is_local() -> bool:
    return len(get_container_gpus()) <= 1 and len(get_gang_addrs()) <= 1


def is_chief() -> bool:
    return get_rank() == 0 and not is_local()


def monkey_patch_run_config(model_dir: str, strategy: Any, trial_seed: int, rank: int) -> None:
    """
    When constructing the TF Estimator RunConfig object, we need to pass
    in the distribution strategy and model directory immediately -- we can't
    modify the estimator later, since things get set up differently depending
    on the distribution strategy -- but the construction happens in the user
    model code. Here, we patch the RunConfig constructor to always use the
    arguments we need.
    """

    # TODO(ryan): since we are setting random seeds before every step, the seed should probably
    # be something like `trial_seed + num_workers*step_id + worker_id`.
    def add_args(f: Callable[..., Any]) -> Callable[..., Any]:
        def w(*args: Any, **kwargs: Any) -> Any:
            new_kwargs = {
                **kwargs,
                "model_dir": model_dir,
                "train_distribute": strategy,
                "tf_random_seed": trial_seed + rank,
            }
            return f(*args, **new_kwargs)

        return w

    decorate(tf.estimator.RunConfig, "__init__", add_args)
