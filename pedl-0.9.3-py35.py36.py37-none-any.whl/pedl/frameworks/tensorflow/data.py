import math
from abc import ABCMeta, abstractmethod
from typing import Any, Dict, Iterable, Optional, Union

import numpy as np
import tensorflow as tf
from tensorflow.data import Dataset, Iterator

import pedl.frameworks.tensorflow.patch_saver_restore  # noqa: F401
from pedl.check import check_not_none
from pedl.data import BatchLoader


# TensorFlowDataLoader is a union of possible return values for a
# make_data_loaders that feeds a TensorFlowTrial
TensorFlowDataLoader = Union[Dataset, BatchLoader, "TensorFlowDatasetAdapter"]


# anazyle_tf_type does recursive type checking, useful for wrapping a generator
# with a tf.data.Dataset. Note that it does not accept Tensor handles because
# analyze_tf_type should only be called on evaluated tensors.
def analyze_tf_type(val: Any) -> tf.DType:
    if isinstance(val, dict):
        return {k: analyze_tf_type(v) for k, v in val.items()}
    if isinstance(val, list):
        return [analyze_tf_type(v) for v in val]
    if isinstance(val, tuple):
        return tuple(analyze_tf_type(v) for v in val)
    if isinstance(val, np.ndarray):
        return val.dtype
    raise ValueError(
        "unable to determine type of {} for tf.data.Dataset.from_generator()".format(val)
    )


def analyze_tf_shape(val: Any) -> tf.DType:
    if isinstance(val, dict):
        return {k: analyze_tf_shape(v) for k, v in val.items()}
    if isinstance(val, list):
        return [analyze_tf_shape(v) for v in val]
    if isinstance(val, tuple):
        return tuple(analyze_tf_shape(v) for v in val)
    if isinstance(val, np.ndarray):
        # Treat the first dimension as a batch dimension
        return tf.TensorShape([None] + [i for i in val.shape[1:]])
    raise ValueError(
        "unable to determine type of {} for tf.data.Dataset.from_generator()".format(val)
    )


class TensorFlowDatasetAdapter(metaclass=ABCMeta):
    """A class to assist with restoring and saving iterators for a dataset.
    This class may be subclassed for users with very customized data
    pipelines.

    Arguments:
        dataset:
            The tf.data.Dataset object from which data should be fetched.
    """

    @abstractmethod
    def get_iterator(self, repeat: bool = False, skip_batches: int = 0) -> Iterator:
        """Return a TensorFlow tf.data.Dataset, or restore one from the files
        of a checkpoint. The first element the returned Dataset produces should
        be `skip_batches` number of batches into the Dataset.

        Arguments:
            repeat:
                Indicate if dataset should be pre-transformed with a repeat().
            skip_batches:
                Indicate how many batches should be skipped from the beginning
                of the dataset before starting. With normal tf.data.Datasets,
                `skip_batches` is ignored; the iterator is created but its
                state is restored during restore_iterator(). Adapters which
                wrap non-Dataset generators using from_generator() should use
                `skip_batches` and ignore the call to restore_iterator().
        """
        pass

    def save_iterator(
        self, iterator: tf.data.Iterator, save_path: str, save_session: tf.Session
    ) -> None:
        """Save an iterator to a checkpoint.

        Arguments:
            iterator:
                The iterator to be saved.
            save_path:
                The path to a checkpoint used for restoring an iterator.
            save_session:
                The TensorFlow session which should be used for restoring an
                iterator from a checkpoint.
        """
        pass

    def restore_iterator(
        self,
        iterator: tf.data.Iterator,
        restore_path: str,
        restore_session: tf.Session,
        run_options: tf.RunOptions = None,
    ) -> Iterator:
        """Restore an iterator from a checkpoint.

        Arguments:
            iterator:
                The iterator to be restored.
            restore_path:
                The path to a checkpoint used for restoring an iterator.
            restore_session:
                The TensorFlow session which should be used for restoring an
                iterator from a checkpoint.
            run_options:
                The tf.RunOptions to pass to the tf.Session during
                tf.Saver.restore().
        """
        return iterator


class DatasetToTensorFlowDatasetAdapter(TensorFlowDatasetAdapter):
    def __init__(self, dataset: Dataset, prefetch_buffer: int = 1) -> None:
        self.dataset = dataset
        self.prefetch_buffer = prefetch_buffer

    def get_iterator(self, repeat: bool = False, skip_batches: int = 0) -> Iterator:
        # Ignore the skip_batches argument; instead of skipping batches at
        # startup, this iterator will restore its old state from a checkpoint.

        temp = self.dataset
        if repeat:
            # Having an extra repeat should be ok, so we don't need to check if
            # the dataset already has one.
            temp = temp.repeat()

        if self.prefetch_buffer > 0:
            temp = temp.prefetch(self.prefetch_buffer)

        return temp.make_one_shot_iterator()

    def save_iterator(
        self, iterator: tf.data.Iterator, save_path: str, save_session: tf.Session
    ) -> None:
        saveable = tf.data.experimental.make_saveable_from_iterator(iterator)
        saver = tf.train.Saver({"iterator": saveable})
        saver.save(save_session, save_path)

    def restore_iterator(
        self,
        iterator: tf.data.Iterator,
        restore_path: str,
        restore_session: tf.Session,
        run_options: tf.RunOptions = None,
    ) -> Iterator:
        saveable = tf.data.experimental.make_saveable_from_iterator(iterator)
        restorer = tf.train.Saver({"iterator": saveable})
        restorer.restore(restore_session, restore_path, options=run_options)
        return iterator


class BatchLoaderToTensorFlowDatasetAdapter(TensorFlowDatasetAdapter):
    def __init__(
        self,
        batch_loader: BatchLoader,
        batch_size: int,
        drop_leftovers: bool = False,
        prefetch_buffer: int = 1,
    ) -> None:
        self.batch_loader = batch_loader
        self.batch_size = batch_size
        self.drop_leftovers = drop_leftovers
        self.prefetch_buffer = prefetch_buffer

    # _make_batch_iterator_factory returns a closure which returns iterators
    # over the batches. The iterator starts `skip_batches` into the dataset
    # and continues either forever (if repeat == True) or until the end of
    # the dataset. Essentially this is an efficient way to implement what
    # tf.data.Dataset.skip() does, and it is necessary because a
    # tf.data.Dataset created with from_generator() does not produce
    # tf.data.Iterators which can be saved and restored.
    def _make_batch_iterator_factory(self, skip_batches: int, repeat: bool) -> Any:
        if self.drop_leftovers:
            num_batches = int(math.floor(len(self.batch_loader) / self.batch_size))
        else:
            num_batches = int(math.ceil(len(self.batch_loader) / self.batch_size))

        batch_idx = skip_batches

        def batch_iterator_factory() -> Iterable[Dict[str, Dict[str, np.array]]]:
            nonlocal batch_idx
            # Since get_batch_by_index() can wrap indices, we don't ever have
            # to reset batch_idx.
            while repeat or batch_idx < num_batches:
                batch = self.batch_loader.get_batch_by_index(
                    self.batch_size, batch_idx, wrap=repeat, drop_leftovers=self.drop_leftovers
                )
                yield {"data": batch.data, "labels": batch.labels}
                batch_idx += 1

        return batch_iterator_factory

    def get_iterator(self, repeat: bool = False, skip_batches: int = 0) -> Iterator:

        # get one batch in order to identify the types
        batch = self.batch_loader.get_batch(0, self.batch_size)

        output_types = {
            "data": analyze_tf_type(batch.data),
            "labels": analyze_tf_type(batch.labels),
        }

        output_shapes = {
            "data": analyze_tf_shape(batch.data),
            "labels": analyze_tf_shape(batch.labels),
        }

        dataset = Dataset.from_generator(
            self._make_batch_iterator_factory(skip_batches, repeat),
            output_types=output_types,
            output_shapes=output_shapes,
        )

        if self.prefetch_buffer > 0:
            dataset = dataset.prefetch(self.prefetch_buffer)

        return dataset.make_one_shot_iterator()


def make_tensorflow_dataset_adapter(
    data_loader: TensorFlowDataLoader, batch_size: Optional[int]
) -> TensorFlowDatasetAdapter:
    if isinstance(data_loader, TensorFlowDatasetAdapter):
        return data_loader
    if isinstance(data_loader, Dataset):
        return DatasetToTensorFlowDatasetAdapter(data_loader)
    if isinstance(data_loader, BatchLoader):
        check_not_none(
            batch_size,
            "you must implement batch_size() in your TensorFlowTrial "
            "subclass if you wish to return BatchLoaders via make_data_loaders()",
        )
        assert batch_size is not None
        return BatchLoaderToTensorFlowDatasetAdapter(data_loader, batch_size)
    raise ValueError(
        "Unable to treat data loader of type {} as a TensorFlow Dataset.".format(
            type(data_loader).__name__
        )
    )
