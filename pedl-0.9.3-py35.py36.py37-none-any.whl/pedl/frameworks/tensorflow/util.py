import logging
import os
from typing import Any

import tensorflow as tf

from pedl.check import check_len

# TODO: DET-175 direct checkpoint file manipulation is deprecated in TF 1.13.


def delete_tf_events(model_dir: str) -> None:
    for f in os.listdir(model_dir):
        full_path = os.path.join(model_dir, f)
        if f.startswith("events.out.tfevents"):
            os.remove(full_path)


def delete_all_checkpoints_except_most_recent(model_dir: str) -> None:
    """
    Given a TensorFlow Estimator model directory, delete all of the checkpoints
    except the most recent. This involves not only removing the checkpoint
    files themselves, but also updating the CheckpointState file that tracks
    metadata about the state of the model directory.
    """

    # When the `tf.data.experimental.CheckpointInputPipeline` hook is used,
    # the step number saved in the checkpoint file sometimes is different than
    # the filename actually used. Find stale checkpoint data directly by
    # looking at the directory listing.
    checkpoint_indexes = []
    checkpoints = []
    for f in os.scandir(model_dir):
        if not f.is_file():
            continue
        if f.name.startswith("checkpoint"):
            checkpoint_indexes.append(f.name)
            continue
        # Checkpoint data is stored in files like "model.ckpt-20.index".
        parts = f.name.split(".")
        if len(parts) < 3:
            continue
        if parts[-2].startswith("ckpt-"):
            stem = ".".join(parts[:-1])
            checkpoints.append((f.path, stem))

    latest_checkpoints = {
        os.path.basename(
            tf.train.get_checkpoint_state(
                model_dir, latest_filename=latest_filename
            ).model_checkpoint_path
        )
        for latest_filename in checkpoint_indexes
    }

    for path, stem in checkpoints:
        if stem in latest_checkpoints:
            continue
        logging.debug("Deleting non-recent checkpoint file %s", path)
        os.remove(path)

    for latest_filename in checkpoint_indexes:
        checkpoint_state = tf.train.get_checkpoint_state(model_dir, latest_filename=latest_filename)
        tf.train.update_checkpoint_state(
            model_dir,
            model_checkpoint_path=checkpoint_state.model_checkpoint_path,
            all_model_checkpoint_paths=None,
            latest_filename=latest_filename,
        )


def update_checkpoint_path_in_state_file(model_dir: str) -> None:
    """
    Given a TensorFlow Estimator model directory, modify the CheckpointState
    metadata file to point to the correct checkpoint path. This is useful when
    copying a Estimator model directory. This function requires that only a
    single checkpoint exists in the model directory.

    Example:
    1) Model directory is in /storage/A. Filesystem state is:
        /storage/A/checkpoint-100
            weights file (large)
        /storage/A/checkpoint
            CheckpointState protobuffer file with a reference to
            '/storage/A/checkpoint-100'

    2) Process copies /storage/A to /storage/B
        /storage/B/checkpoint-100
            weights file (large)
        /storage/B/checkpoint
            CheckpointState protobuffer file with a reference to
            '/storage/A/checkpoint-100' (incorrect)

    3) update_checkpoint_path_in_state_file("/storage/B") is invocated
        /storage/B/checkpoint-100
            weights file (large)
        /storage/B/checkpoint
            CheckpointState protobuffer file with a reference to
            '/storage/B/checkpoint-100' (correct)
    """
    # The model directory may contain checkpoints for the model itself
    # (latest_filename = "checkpoint") and input pipeline
    # (latest_filename = "checkpoint_input").
    checkpoint_filenames = [
        f.name for f in os.scandir(model_dir) if f.is_file() and f.name.startswith("checkpoint")
    ]
    for latest_filename in checkpoint_filenames:
        checkpoint_state = tf.train.get_checkpoint_state(model_dir, latest_filename=latest_filename)
        check_len(checkpoint_state.all_model_checkpoint_paths, 1)

        checkpoint_file_name = os.path.basename(checkpoint_state.model_checkpoint_path)
        new_checkpoint_path = os.path.join(model_dir, checkpoint_file_name)
        tf.train.update_checkpoint_state(
            model_dir, new_checkpoint_path, latest_filename=latest_filename
        )


def slice_tensor(x: Any, begin: int, end: int) -> Any:
    try:
        return x[begin:end]
    except TypeError as exc:
        # Sparse tensors do not implement the slice operator.
        original_exc = exc

    try:
        slice_fn = tf.sparse.slice
    except AttributeError:
        raise original_exc
    else:
        shape = tf.shape(x, out_type=tf.int64)
        start = tf.concat([tf.constant([begin], dtype=tf.int64), tf.zeros_like(shape[1:])], axis=0)
        size = tf.concat([tf.constant([end - begin], dtype=tf.int64), shape[1:]], axis=0)
        return slice_fn(x, start=start, size=size)
