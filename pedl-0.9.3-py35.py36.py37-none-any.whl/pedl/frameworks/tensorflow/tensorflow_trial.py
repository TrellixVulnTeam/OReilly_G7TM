import itertools
import logging
import os
import random
from abc import abstractmethod
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import tensorflow
from packaging import version
from tensorflow.core.framework import node_def_pb2

from pedl._types import StepID
from pedl.check import (
    check_eq,
    check_gt,
    check_in,
    check_isinstance,
    check_len,
    check_lt_eq,
    check_not_none,
)
from pedl.frameworks.tensorflow.data import (
    make_tensorflow_dataset_adapter,
    TensorFlowDataLoader,
    TensorFlowDatasetAdapter,
)
from pedl.frameworks.tensorflow.patch_saver_restore import patch_config_and_get_runopts
from pedl.frameworks.tensorflow.util import slice_tensor
from pedl.harness import EnvContext
from pedl.trial import get_container_gpus, make_metrics, Trial, TrialController

# TODO(ryan): remove this check after removing support for TensorFlow 1.13.1.
if version.parse(tensorflow.__version__) >= version.parse("1.14.0"):
    import tensorflow.compat.v1 as tf
    from tensorflow.saved_model import TRAINING
    import tensorflow.nest as nest
else:
    import tensorflow as tf
    from tensorflow.saved_model.tag_constants import TRAINING
    from tensorflow.contrib.framework import nest


TensorSpec = Dict[str, tf.Tensor]


class TensorFlowTrialController(TrialController):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

        assert isinstance(self.trial, TensorFlowTrial)
        self.trial = self.trial  # type: TensorFlowTrial

        # The default TensorFlow graph is thread local, so we save a reference
        # to it here in case we want to use in other threads.
        self.graph = tf.get_default_graph()

        # The TensorFlow session is created lazily on the trial's first
        # workload (see initialize_session).
        self.tf_session = None  # type: Optional[tf.Session]

        available_gpus = get_container_gpus()
        self.num_gpus = len(available_gpus)

        with tf.variable_scope("TensorFlowTrial", reuse=tf.AUTO_REUSE):
            with tf.device("/cpu:0"):
                self.training_counter = tf.get_variable(
                    "training_counter",
                    initializer=tf.zeros_like(0.0),
                    dtype=tf.float32,
                    trainable=False,
                )

                # This boolean Tensor toggles whether the graph runs in
                # inference or training mode. It is set to False by default,
                # so that models restored from checkpoint outside of PEDL
                # will run in inference mode by default.
                self._is_training = tf.placeholder_with_default(False, [], name="is_training")

                # We are going to use a feedable iterator, where you set which
                # Iterator is used for each call to session.run() via a
                # feed_dict. This makes it easy for us to use one graph but
                # switch between training and validation Iterators without the
                # complexities of saving/restoring Iterators.
                self.iterator_handle = tf.placeholder(tf.string, shape=[])

        # These will be set when the harness calls set_data_loaders().
        self.training_loader = None  # type: Optional[TensorFlowDatasetAdapter]
        self.validation_loader = None  # type: Optional[TensorFlowDatasetAdapter]

        self.training_iterator = None  # type: tf.data.Iterator
        self.training_iterator_handle = None  # type: tf.placeholder
        self.validation_iterator_handle = None  # type: tf.placeholder
        self.next_training_record = None  # type: tf.Tensor

        self.restore_runopts = None  # type: tf.RunOptions

        # _batch_size is a tensorflow operator that counts the size of the
        # batch dimension of inputs at runtime.
        self._batch_size = None  # type: Optional[tf.Tensor]

        # only prepare the graph once.
        self.prepared = False

        # TODO(ryan): Remove this compatibility layer with the old Trial API.
        super().initialize(self.env)
        self.set_data_loaders(self.data_loaders)

    def prepare_graph(self) -> None:
        if self.prepared is True:
            return
        self.prepared = True

        # _set_env_context and set_data_loaders must have already been called.
        assert self.env is not None
        assert self.training_loader is not None
        assert self.validation_loader is not None

        # We need to have already created the session
        assert self.tf_session is not None

        # TODO: This should *NOT* be extracted from the environment with a
        # default value here. When the trial manager is separated from the
        # trial interface, this should be set in trial_manager.__init__().
        batches_per_step = self.env.experiment_config.get("batches_per_step", 100)

        # First get the iterators from the dataset.
        first_step_id = self.env.initial_workload.step_id
        skip_batches = (first_step_id - 1) * batches_per_step

        # Prepare the training iterator.
        self.training_iterator = self.training_loader.get_iterator(
            repeat=True, skip_batches=skip_batches
        )

        with self.graph.as_default():
            self.training_iterator_handle = self.tf_session.run(
                self.training_iterator.string_handle()
            )

        assert self.training_iterator is not None

        # Use the training iterator to build the feedable iterator
        feedable_iterator = tf.data.Iterator.from_string_handle(
            self.iterator_handle,
            self.training_iterator.output_types,
            output_shapes=self.training_iterator.output_shapes,
        )

        self.next_training_record = feedable_iterator.get_next()

        self._batch_size = self.get_batch_size(self.next_training_record)

        if self.num_gpus > 1:
            self.build_multi_slot_graph(self.next_training_record)
        else:
            self.build_single_slot_graph(self.next_training_record)

        with self.graph.as_default():
            self.tf_session.run(tf.global_variables_initializer())

    def get_batch_size(self, record: Any) -> tf.Tensor:
        """Returns a scalar Tensor which evaluates to the batch length during
        each run of the graph. The default implementation will descend a nested
        structure of Tensors and return the length of the first dimension of
        the first Tensor it finds.

        Arguments:
            record: A record from the tf.data.Dataset for the trial.
        """
        if isinstance(record, dict):
            return self.get_batch_size(next(iter(record.values())))
        if isinstance(record, (list, tuple)):
            return self.get_batch_size(record[0])
        if isinstance(record, tf.Tensor):
            return tf.shape(record)[0]
        raise ValueError(
            "unable to identify the batch dimension of the dataset; descended "
            "structure and found type {}".format(type(record))
        )

    def set_random_seed(self, seed: int) -> None:
        random.seed(seed)
        np.random.seed(seed)
        tf.set_random_seed(seed)

    def initialize_session(self, initialize_global_vars: bool = False) -> None:
        assert self.tf_session is None

        with self.graph.as_default():
            # A session is coupled to a graph and is responsible for running
            # operations through the graph.

            # Due to a TensorFlow bug, we have to be careful to always run iterator restore
            # functions from greater-than-one-sized thread pools. This means patching the
            # ConfigProto and using a RunOptions when we restore a session. See
            # patch_saver_restore.py for details.
            config, self.restore_runopts = patch_config_and_get_runopts(self.trial.session_config())

            self.tf_session = tf.Session(config=config)
            self.tf_session.run(tf.local_variables_initializer())
            if initialize_global_vars:
                self.tf_session.run(tf.global_variables_initializer())

    def build_single_slot_graph(self, record: Any) -> None:
        check_lt_eq(self.num_gpus, 1)

        # Retrieve all the tensors by name.
        tensor_map = self.trial.build_graph(record, self._is_training)

        check_in("loss", tensor_map, "build_graph() must return a Tensor labeled 'loss'.")
        self.loss = tensor_map["loss"]

        for name in self.trial.training_metrics():
            check_in(
                name,
                tensor_map,
                "'{}' (returned by "
                "training_metrics()) is not a valid tensor "
                "returned by build_graph()".format(name),
            )
        self.t_metrics_vars = [self.loss] + [
            tensor_map[name] for name in self.trial.training_metrics()
        ]

        optimizer = self.trial.optimizer()
        self.minimizer = optimizer.minimize(self.loss, global_step=self.training_counter)

        for name in self.trial.validation_metrics():
            check_in(
                name,
                tensor_map,
                "'{}' (returned by "
                "validation_metrics()) is not a valid tensor "
                "returned by build_graph()".format(name),
            )
        self.v_metrics_vars = [tensor_map[name] for name in self.trial.validation_metrics()]

    # build_multi_slot_graph is based on some obscure behaviors of TensorFlow. Relevant links:
    # TensorFlow's multi-GPU model guide:
    #     http://web.archive.org/web/20180220113609/https://www.tensorflow.org/tutorials/deep_cnn/
    # Some guy's highly instructive TensorFlow multi-GPU guide:
    #     http://blog.s-schoener.com/2017-12-15-parallel-tensorflow-intro/
    # TensorFlow guide to Variables:
    #     https://www.tensorflow.org/guide/variables
    # More info on VariableScopes and NameScopes:
    #     https://stackoverflow.com/q/35919020
    #     https://stackoverflow.com/a/43580096
    def build_multi_slot_graph(self, record: Any) -> None:
        check_gt(self.num_gpus, 1)

        # Helper to place variables on the CPU, ops on the GPUs.
        def make_device_chooser(worker: str) -> Any:
            def device_chooser(op: Any) -> str:
                node_def = op if isinstance(op, node_def_pb2.NodeDef) else op.node_def
                if node_def.op in ["Variable", "VariableV2", "VarHandleOp"]:
                    return "/cpu:0"
                else:
                    return worker

            return device_chooser

        # TODO(ryan) replace this with a run-time warning. This is slightly tricky because it it is
        # sometimes allowable; a small partial batch at the end of an epoch should not crash an
        # experiment or even show a warning. Having a batch size of 1 might be grounds for raising
        # an error but it likely shouldn't crash a whole experiment if batch_size is a
        # hyperparameter that comes out to 1 in a single experiment.
        # check_gt_eq(self.batch_size(), self.num_gpus,
        #             "batch_size() must be greater than 'slots_per_trial'.")

        # From the TensorFlow docs: "The first abstraction we require is a
        # function for computing inference and gradients for a single model
        # replica. In the code we term this abstraction a 'tower'."
        # `tower_losses` and `tower_gradvars` collects the losses and gradients
        # / model params for each replica.
        tower_gradvars = []
        # Each tower is given a weight during metric reduction according to
        # how large its sub-batch is. The weight may change per input record
        # if partial batches are allowed.
        v_metrics_vals = defaultdict(list)  # type: Dict[str, List[tf.Tensor]]
        t_metrics_vals = defaultdict(list)  # type: Dict[str, List[tf.Tensor]]

        # To avoid NaN's on partial batches, we create a subbatch mask to
        # ignore towers whose subbatches are empty.
        active_subbatches = tf.minimum(self._batch_size, self.num_gpus)
        active_subbatches_mask = tf.sequence_mask(active_subbatches, maxlen=self.num_gpus)

        # The subbatch size we would like to give to each worker.
        assert self._batch_size is not None
        subbatch_size = tf.cast(tf.ceil(self._batch_size / self.num_gpus), tf.int32)

        for device_idx in range(self.num_gpus):
            with tf.variable_scope("TensorFlowTrial", reuse=tf.AUTO_REUSE):
                with tf.name_scope("tower_{}".format(device_idx)):

                    # Do the record slicing in the CPU, to reduce data that
                    # needs to be passed to each GPU.
                    with tf.device("/cpu:0"):
                        # Start and end indicies for this device's subbatch.
                        # This device's subbatch might be smaller than the
                        # normal subbatch if a batch is not evenly divisble by
                        # the number of GPUs.
                        start = tf.minimum(self._batch_size, subbatch_size * device_idx)
                        end = tf.minimum(self._batch_size, subbatch_size * (device_idx + 1))

                        # tower_weight is the weight in a weighted average
                        # reduction. It is used for all metrics and gradients.
                        tower_weight = tf.divide(end - start, self._batch_size)

                        # Get the subbatch for this device.
                        sub_record = nest.map_structure(
                            lambda x: slice_tensor(x, start, end), record
                        )

                    with tf.device(make_device_chooser("/gpu:{}".format(device_idx))):
                        tensor_map = self.trial.build_graph(sub_record, self._is_training)

                        # Append the training metric and validation metric
                        # values, if any. Metrics are scaled by the
                        # tower_weight now so that the reduction is just a sum.
                        for name in self.trial.training_metrics():
                            t = tensor_map[name]
                            t_metrics_vals[name].append(
                                tf.scalar_mul(tf.cast(tower_weight, t.dtype), t)
                            )
                        for name in self.trial.validation_metrics():
                            t = tensor_map[name]
                            v_metrics_vals[name].append(
                                tf.scalar_mul(tf.cast(tower_weight, t.dtype), t)
                            )

                        tower_loss = tensor_map["loss"] * tf.cast(
                            tower_weight, tensor_map["loss"].dtype
                        )
                        t_metrics_vals["loss"].append(tower_loss)

                        # Since variables are shared by all replicas, gradients
                        # for each replica are counted by each variable.
                        model_params = tf.trainable_variables()

                        # Calculate this tower's gradient. Since the tower_loss
                        # is already scaled, there is no need to also scale the
                        # gradient. Gradient reduction is still just a sum.
                        grads = tf.gradients(tower_loss, model_params)
                        tower_gradvars.append([i for i in zip(grads, model_params)])

        def reduce_metric(metric_vals: List[tf.Tensor]) -> tf.Tensor:
            # Given a list of metric value tensors, return their mean. Each
            # tower's metric value is weighted according to how large it's
            # subbatch was.
            vals_tensor = tf.stack(metric_vals)
            # Zero-sized subbatches may have resulted in NaN's.
            masked_vals = tf.boolean_mask(vals_tensor, active_subbatches_mask)
            return tf.reduce_sum(masked_vals, axis=0)

        with tf.device("/cpu:0"):
            optimizer = self.trial.optimizer()

            # Compute average gradients.
            gradvars = []
            with tf.name_scope("gradient_averaging"):
                all_grads = {}  # type: Dict[Any, Any]
                for grad, var in itertools.chain(*tower_gradvars):
                    if grad is not None:
                        all_grads.setdefault(var, []).append(grad)
                for var, grads in all_grads.items():
                    # Average gradients on the same device as the variables
                    # to which they apply.
                    with tf.device(var.device):
                        if len(grads) == 1:
                            avg_grad = grads[0]
                        else:
                            avg_grad = tf.add_n(grads)
                    gradvars.append((avg_grad, var))

            # TODO(yoavz): Does it make sense to only collect scalar training
            # metrics in multi GPU mode?
            self.loss = reduce_metric(t_metrics_vals["loss"])
            self.t_metrics_vars = [self.loss] + [
                reduce_metric(t_metrics_vals[name]) for name in self.trial.training_metrics()
            ]
            self.v_metrics_vars = [
                reduce_metric(v_metrics_vals[name]) for name in self.trial.validation_metrics()
            ]

            # Apply the gradients to adjust the shared variables.
            self.minimizer = optimizer.apply_gradients(gradvars, global_step=self.training_counter)

    def train_for_step(self, step_id: StepID, batches_per_step: int) -> Dict[str, Any]:
        """
        Runs a trial for one step.
        """
        assert self.training_loader is not None
        if self.tf_session is None:
            self.initialize_session(initialize_global_vars=True)
            assert self.tf_session is not None

        self.prepare_graph()

        metrics = []
        total_inputs = 0
        for _ in range(batches_per_step):
            with self.graph.as_default():
                try:
                    num_inputs, run_output = self.tf_session.run(
                        (self._batch_size, [self.minimizer] + self.t_metrics_vars),
                        feed_dict={
                            self._is_training: True,
                            self.iterator_handle: self.training_iterator_handle,
                        },
                    )

                except tf.errors.OutOfRangeError as e:
                    raise ValueError(
                        "got an OutOfRangeError reading from the training "
                        "dataset (which has a .repeat()), please make sure "
                        "dataset is not empty"
                    ) from e

                total_inputs += num_inputs

            check_eq(len(run_output), 1 + len(self.t_metrics_vars))
            metrics_values = run_output[1:]
            batch_metrics = dict(zip(["loss"] + self.trial.training_metrics(), metrics_values))
            metrics.append(batch_metrics)

        logging.info(
            "Done training step: {} records in {} batches".format(total_inputs, batches_per_step)
        )

        return make_metrics(total_inputs, metrics)

    def compute_validation_metrics(self, step_id: StepID) -> Dict[str, Any]:
        assert self.validation_loader is not None
        if self.tf_session is None:
            self.initialize_session(initialize_global_vars=True)
            assert self.tf_session is not None

        self.prepare_graph()

        # We can choose the batch size freely when evaluating the
        # validation set. For now, we use the same batch size as this
        # trial uses for training, but this could be improved.

        # Create a new iterator for computing validation metrics
        validation_iterator = self.validation_loader.get_iterator(repeat=False)

        with self.graph.as_default():
            validation_iterator_handle = self.tf_session.run(validation_iterator.string_handle())

        metrics = []
        total_inputs = 0

        while True:
            with self.graph.as_default():
                try:
                    num_inputs, val_output = self.tf_session.run(
                        (self._batch_size, self.v_metrics_vars),
                        feed_dict={
                            self._is_training: False,
                            self.iterator_handle: validation_iterator_handle,
                        },
                    )

                    check_eq(len(val_output), len(self.v_metrics_vars))
                    metrics.append(val_output)

                    total_inputs += num_inputs

                except tf.errors.OutOfRangeError:
                    break

        check_gt(len(metrics), 0)

        def elementwise_mean(values: List[np.ndarray]) -> np.ndarray:
            return np.mean(np.stack(values), axis=0)

        step_metrics = {
            name: elementwise_mean([b[idx] for b in metrics])
            for idx, name in enumerate(self.trial.validation_metrics())
        }

        return {"num_inputs": total_inputs, "validation_metrics": step_metrics}

    def save_framework_checkpoint(self, path: str) -> None:
        assert self.tf_session is not None

        with self.tf_session.graph.as_default():
            # SavedModelBuilder creates the directory on save().
            builder = tf.saved_model.builder.SavedModelBuilder(path)
            builder.add_meta_graph_and_variables(self.tf_session, [TRAINING])
            builder.save()

            self.training_loader.save_iterator(  # type: ignore
                self.training_iterator,
                os.path.join(path, "tensorflow_trial_iterator/iterator"),
                self.tf_session,
            )

    def load_framework_checkpoint(self, path: str) -> None:
        if self.tf_session is None:
            self.initialize_session(initialize_global_vars=False)
            assert self.tf_session is not None

        self.prepare_graph()

        # To load a checkpoint, we only need the "variables" portion of
        # SavedModel. Directly use the tf.train.Saver API to do this.
        variables_path = os.path.join(
            path,
            tf.saved_model.constants.VARIABLES_DIRECTORY,
            tf.saved_model.constants.VARIABLES_FILENAME,
        )
        with self.tf_session.graph.as_default():
            saver = tf.train.Saver()
            saver.restore(self.tf_session, variables_path)

        # Restore the iterator from the TensorFlowDatasetAdapter.
        assert self.training_loader is not None
        assert self.training_iterator is not None
        self.training_iterator = self.training_loader.restore_iterator(
            self.training_iterator,
            os.path.join(path, "tensorflow_trial_iterator/iterator"),
            self.tf_session,
            run_options=self.restore_runopts,
        )

    def set_data_loaders(
        self, data_loaders: Optional[Tuple[TensorFlowDataLoader, TensorFlowDataLoader]]
    ) -> None:
        check_not_none(
            data_loaders,
            "TensorFlowTrial requires a `make_data_loaders` function in the model definition",
        )
        assert data_loaders is not None

        check_isinstance(  # type: ignore
            data_loaders,
            (tuple, list),
            "`make_data_loaders` must return a tuple of two BatchLoader objects",
        )
        check_len(
            data_loaders, 2, "`make_data_loaders` must return a tuple of two BatchLoader objects"
        )

        self.training_loader = make_tensorflow_dataset_adapter(
            data_loaders[0], self.trial.batch_size()
        )
        self.validation_loader = make_tensorflow_dataset_adapter(
            data_loaders[1], self.trial.batch_size()
        )

    def _set_env_context(self, env: EnvContext) -> None:
        self.env = env


class TensorFlowTrial(Trial):
    trial_controller_class = TensorFlowTrialController

    @abstractmethod
    def build_graph(self, record: Any, is_training: tf.Tensor) -> TensorSpec:
        """
        Builds the TensorFlow graph to be used for training and validation.
        `is_training` is a boolean Tensor that is True during training
        and False during validation at graph runtime.

        Returns a dictionary mapping string names to tf.Tensor output nodes.
        These output tensors will be referenced by name in
        :func:`validation_metrics` and :func:`training_metrics`.
        """
        pass

    # TODO(ryan): remove batch_size from the API entirely.
    def batch_size(self) -> Optional[int]:
        """Returns the batch size to be used for training, only used for
        compatibility with old-style BatchLoader-based trials."""
        return None

    @abstractmethod
    def optimizer(self) -> tf.train.Optimizer:
        """
        Builds the optimizer to use for training.

        Returns the optimizer.
        """
        pass

    @abstractmethod
    def validation_metrics(self) -> List[str]:
        """
        Returns a list of metric string names that will be evaluated on the
        validation data. Each of these names must correspond to a `tf.Tensor`
        value returned by :func:`build_graph`.
        """
        pass

    def training_metrics(self) -> List[str]:
        """
        Returns a list of metric string names that will be evaluated on the
        training data, in addition to "loss". Each of these names must
        correspond to a `tf.Tensor` value returned by :func:`build_graph`.
        """
        return []

    def session_config(self) -> tf.ConfigProto:
        """
        Returns the tf.ConfigProto used to configure the TensorFlow session.
        """
        return tf.ConfigProto(allow_soft_placement=True)

    def training_counter(self) -> tf.Variable:
        with tf.variable_scope("TensorFlowTrial", reuse=True):
            with tf.device("/cpu:0"):
                return tf.get_variable("training_counter")
