import os
from typing import Any, Dict, List

import numpy as np
import tensorflow as tf

import pedl
from pedl.callback import Callback


# TODO(yoavz): Write unit tests for TensorBoard callback.
class TensorBoard(Callback):
    def __init__(self, log_directory: str) -> None:
        self._training_writer = tf.summary.FileWriter(
            os.path.join(log_directory, str(pedl.get_trial_id()), "training"), None
        )
        self._validation_writer = tf.summary.FileWriter(
            os.path.join(log_directory, str(pedl.get_trial_id()), "validation"), None
        )

    def _batches_per_step(self) -> int:
        return pedl.get_experiment_config().get("batches_per_step", 100)

    def _maybe_write_metric(self, metric_key: str, metric_val: Any, step: int, writer: Any) -> None:
        # For now, we only log scalar metrics.
        if not isinstance(metric_val, (float, int, np.number)):
            return

        summary = tf.Summary()
        summary_value = summary.value.add()
        summary_value.tag = metric_key
        summary_value.simple_value = metric_val
        writer.add_summary(summary, step)

    def on_train_step_end(self, step_id: int, metrics: List[Dict[str, Any]]) -> None:
        assert step_id > 0
        first_batch_in_step = (step_id - 1) * self._batches_per_step()
        for batch_idx, batch_metrics in enumerate(metrics):
            batches_seen = first_batch_in_step + batch_idx
            for tag, value in batch_metrics.items():
                self._maybe_write_metric(tag, value, batches_seen, self._training_writer)

        # Flush after every training step so that metrics are viewable
        # in real-time on TensorBoard.
        self._training_writer.flush()

    def on_validation_step_end(self, step_id: int, metrics: Dict[str, Any]) -> None:
        batches_seen = step_id * self._batches_per_step()
        for metric_name, metric_value in metrics.items():
            self._maybe_write_metric(
                metric_name, metric_value, batches_seen, self._validation_writer
            )

        # Flush after every validation step so that metrics are viewable
        # in real-time on TensorBoard.
        self._validation_writer.flush()
