from typing import Any, Dict, List, Tuple

import numpy as np

from pedl.check import check_eq, check_eq_len, check_in, check_len


def sparse_multiclass_error_rate(predictions: np.ndarray, labels: np.ndarray) -> np.float64:
    """Return the error rate based on dense predictions and sparse labels."""
    check_eq(predictions.shape, labels.shape)

    return 1.0 - (np.sum(np.argmax(predictions, 1) == np.argmax(labels, 1)) / predictions.shape[0])


def error_rate(predictions: np.ndarray, labels: np.ndarray) -> np.float64:
    """Return the error rate based on dense predictions and dense labels."""
    check_eq_len(predictions, labels)
    check_len(labels.shape, 1, "Labels must be a column vector")

    return 1.0 - (np.sum(np.argmax(predictions, 1) == labels) / predictions.shape[0])


def error_rate_batched(predictions: np.ndarray, labels: np.ndarray) -> Tuple[np.float64, int]:
    """Batched version of `error_rate`; use with `error_rate_reducer`."""
    check_eq_len(predictions, labels)
    check_len(labels.shape, 1, "Labels must be a column vector")

    return (np.sum(np.argmax(predictions, 1) == labels), predictions.shape[0])


def error_rate_reducer(batches: List[Tuple[np.float64, int]]) -> np.float64:
    """Reducer for `error_rate_batched`."""
    count = sum(bsize for _, bsize in batches)
    return 1 - sum(err for err, _ in batches) / count


def binary_error_rate(predictions: np.ndarray, labels: np.ndarray) -> float:
    """Return the classification error rate for binary classification."""
    check_eq(predictions.shape[0], labels.shape[0])
    check_in(len(predictions.shape), [1, 2])
    if len(predictions.shape) == 2:
        check_eq(predictions.shape[1], 1)
    check_len(labels.shape, 1, "Labels must be a column vector")

    if len(predictions.shape) > 1:
        predictions = np.squeeze(np.asarray(predictions))

    errors = np.sum(np.not_equal(labels, np.round(predictions)))
    result = float(errors) / predictions.shape[0]  # type: float
    return result


def binary_error_rate_batched(predictions: np.ndarray, labels: np.ndarray) -> Tuple[float, int]:
    """Batched version of `binary_error_rate`; use with `mean_reducer`."""
    check_eq(predictions.shape[0], labels.shape[0])
    check_in(len(predictions.shape), [1, 2])
    if len(predictions.shape) == 2:
        check_eq(predictions.shape[1], 1)
    check_len(labels.shape, 1, "Labels must be a column vector")

    if len(predictions.shape) > 1:
        predictions = np.squeeze(np.asarray(predictions))

    errors = np.sum(np.not_equal(labels, np.round(predictions)))
    return (errors, predictions.shape[0])


def mean_reducer(batches: List[Tuple[float, int]]) -> float:
    """Reducer that constructs a mean; see `binary_error_rate_batched`."""
    return sum(err for err, _ in batches) / sum(bsize for _, bsize in batches)


def elementwise_mean(batches: List[np.ndarray]) -> np.ndarray:
    return np.mean(np.stack(batches), axis=0)


def predicted_class_frequencies(
    predictions: np.ndarray, true_labels: np.ndarray
) -> List[Dict[str, Any]]:
    """Given an ndarray containing predicted class probabilities, returns
       the number of times each class was predicted with the highest
       probability. The return value is a list of two-element
       dictionaries: `[{"label": n_0, "count": c_0}, ...]`, meaning that
       the `n_0`'th class was predicted `c_0` times. If a class is never
       predicted, it is omitted from the return value.

       NOTE: `true_labels` are ignored.
    """
    predicted_labels = np.argmax(predictions, 1)
    unique_labels, label_counts = np.unique(predicted_labels, return_counts=True)

    check_eq_len(predicted_labels, predictions)
    check_eq_len(unique_labels, label_counts)
    check_len(predictions, sum(label_counts))

    # We represent predicted label counts as a list of two-element maps as
    # follows: [{"label": n_0, "count": c_0}, ...].
    frequency_map = [{"label": key, "count": val} for key, val in zip(unique_labels, label_counts)]

    return frequency_map
