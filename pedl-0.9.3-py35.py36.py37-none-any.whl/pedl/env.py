import collections
from enum import Enum, unique
from typing import Any, Dict, List


@unique
class RuntimeEnv(Enum):
    """
    The runtime environment of the trial runner.
    """

    CPU = "cpu"
    GPU = "gpu"

    def __str__(self) -> str:
        return str(self.value)

    @staticmethod
    def values() -> List[str]:
        return [env.value for env in RuntimeEnv]


EnvTuple = collections.namedtuple(
    "EnvTuple",
    [
        "os",
        "cuda",
        "python",
        "tensorflow",
        "pytorch",
        "keras",
        "debug",
        "custom_image",
        "runtime_commands",
        "runtime_packages",
        "environment_variables",
        "registry_auth",
        "force_pull_image",
        "ports",
        "internal",
    ],
)


VersionNone = "none"


# Environment mirrors model/environment.go.
class Environment(EnvTuple):
    # PEP-563 will postpone evaluation of annotations so Environment does not
    # need to be quoted. The future behavior can be enabled starting with
    # Python 3.7.
    @classmethod
    def from_dict(self, d: Dict[str, Any]) -> "Environment":
        return Environment(**d)
