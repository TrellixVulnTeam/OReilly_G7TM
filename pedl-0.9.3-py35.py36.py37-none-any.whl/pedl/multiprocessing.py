import logging
import multiprocessing
import threading
from functools import wraps
from multiprocessing.connection import Connection
from queue import Queue
from typing import Any, Callable, Dict, Tuple, TypeVar, Union


T = TypeVar("T")


class Error:
    """
    Error wraps errors to help distinguish them from typical values.
    """

    def __init__(self, exc: Any):
        self.exc = exc


class _RunArgs:
    """
    RunArgs is the final target for spawned calls.
    """

    def __init__(self, conn: Connection, args: Tuple[Any, ...], kwargs: Dict[str, Any]):
        self.conn = conn
        self.args = args
        self.kwargs = kwargs

    def run(self, fn: Callable[..., T]) -> None:
        try:
            self.conn.send(fn(*self.args, **self.kwargs))
        except BaseException as exc:
            # A pickled exception loses its stack trace, so print it here.
            logging.exception("exception %s raised in subprocess for %s", exc, fn.__name__)
            self.conn.send(Error(exc))


def run_in_process(fn: Callable[..., T]) -> Callable[..., T]:
    """
    Wrap a function with one that runs in a separate process that does not
    share any state except that which is explicitly sent and received.
    """

    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Use `_RunArgs` to distinguish between the initial wrapped call
        # executed by the receiving process, and the spawned call executed by
        # the sending process.
        if args and isinstance(args[0], _RunArgs):
            args[0].run(fn)
            return

        ctx = multiprocessing.get_context("spawn")
        recv, send = ctx.Pipe(duplex=False)

        q = Queue(1)  # type: Queue

        def receive_target() -> None:
            try:
                ret = recv.recv()
            except BaseException as exc:
                ret = Error(exc)
            q.put(ret)

        def join_target() -> None:
            run_args = _RunArgs(send, args, kwargs)

            # We must send `wrapper` as pickle checks if the target is the same
            # as `sys.modules[fn_module][fn_name]`. The latter will be set to
            # `wrapper` when `run_in_process` is used as a decorator.
            #
            # This still doesn't let us send `fn` directly, so we rely on `fn`
            # being defined the same on the sending and receiving process.
            proc = ctx.Process(target=wrapper, args=(run_args,))
            try:
                proc.start()
                proc.join()
            finally:
                send.close()

        t1 = threading.Thread(target=join_target)
        t1.start()
        t2 = threading.Thread(target=receive_target)
        t2.start()

        t1.join()
        t2.join()

        ret = q.get()  # type: Union[Error, T]

        if isinstance(ret, Error):
            raise ret.exc
        return ret

    return wrapper
